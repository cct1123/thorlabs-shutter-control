import json
from pathlib import Path
from dataclasses import asdict
from datetime import datetime, timezone
from thorlabs_shutter_control import KCubeShutter
path=Path("records/stage6-post-shutdown-2026-10-20.json")
if path.exists():
    raise RuntimeError("Preserve prior run")
c=KCubeShutter("68800777")
r={"utc":datetime.now(timezone.utc).isoformat(),"scope":"Fresh independent passive USB owner after normal GUI Ctrl+C", "errors":[]}
try:
    r["connected"]=asdict(c.connect())
    r["identity"]=c.identify_device()
    r["status"]=asdict(c.get_status())
    if r["identity"]["serial_number"] != "68800777" or (
        r["status"]["connection"],r["status"]["shutter_state"],
        r["status"]["operating_state"],r["status"]["operating_mode"]
       ) != ("connected","closed","inactive","manual"):
        raise RuntimeError("Unexpected post-shutdown feedback")
except BaseException as exc:
    r["errors"].append(f"{type(exc).__name__}: {exc}")
finally:
    try:
        c.disconnect(close_shutter=False)
        r["release"]="COMPLETED"
    except BaseException as exc:
        r["errors"].append(f"release: {exc}")
    r["retained_handle"]=c._device is not None
    r["result"]="READBACK_PASS" if not r["errors"] and not r["retained_handle"] else "ERROR"
    path.write_text(json.dumps(r,indent=2)+"\n")
    print(json.dumps(r,indent=2),flush=True)
