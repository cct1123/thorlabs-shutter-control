"""Single passive post-update identity/readback diagnostic; no output setters."""
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from thorlabs_shutter_control.controller import _load_sdk

path = Path('records/firmware-post-usb-2026-10-20.json')
if path.exists():
    raise RuntimeError('Do not overwrite or repeat')
sdk = _load_sdk(None)
sdk.manager.BuildDeviceList()
report = {'time_utc': datetime.now(timezone.utc).isoformat(), 'errors': [],
          'scope': 'passive USB after authorized firmware update',
          'discovered': [str(s) for s in sdk.manager.GetDeviceList(68)]}
if '68800777' not in report['discovered']:
    raise RuntimeError('Expected cube not discovered')
transport = sdk.manager.GetTransportInfo('68800777')
report['provider'] = str(transport.GetProvider())
if report['provider'] != 'FTDI':
    raise RuntimeError('Not USB FTDI')
d = sdk.device_type.CreateKCubeSolenoid('68800777')
try:
    d.Connect('68800777')
    if not d.IsSettingsInitialized():
        d.WaitForSettingsInitialized(5000)
    d.StartPolling(250)
    time.sleep(0.5)
    info = d.GetDeviceInfo()
    report['identity'] = {p.Name: str(p.GetValue(info, None))
                          for p in info.GetType().GetProperties()}
    report['selected_serial'] = str(d.SerialNo)
    d.RequestStatus()
    d.RequestOperatingMode()
    d.RequestOperatingState()
    time.sleep(0.25)
    report['feedback'] = {'state': str(d.GetSolenoidState()),
                          'operation': str(d.GetOperatingState()),
                          'mode': str(d.GetOperatingMode()),
                          'status_bits': int(d.GetStatusBits()),
                          'key_enabled': bool(d.Status.KeyEnabled),
                          'comms': str(d.CommsStatus)}
    report['firmware_identity_pass'] = (
        report['identity']['FirmwareVersion'] == '1.0.7'
        and report['identity']['SerialNumberText'] == '68800777'
        and report['selected_serial'] == '68800777')
except Exception as exc:
    report['errors'].append(str(exc))
finally:
    try:
        d.StopPolling()
        d.Disconnect()
        d = None
        report['passive_release'] = 'COMPLETED'
    except Exception as exc:
        report['errors'].append('Release: ' + str(exc))
        report['passive_release'] = 'UNCONFIRMED; retain d'
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
