"""Authorized SDK reads and Close-only test. No Enable, Active or Open calls."""
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from thorlabs_shutter_control.controller import _load_sdk

path = Path('records/sdk-other-commands-close-2026-10-20.json')
if path.exists():
    raise RuntimeError('Do not overwrite/repeat')
sdk = _load_sdk(None)
sdk.manager.BuildDeviceList()
report = {'time_utc': datetime.now(timezone.utc).isoformat(), 'errors': [],
          'authority': 'User asks test other commands; prior Stage3 Close/Manual authority retained',
          'scope': 'Official SDK diagnostic separate from production acceptance',
          'physical_status': 'UNTESTED'}
if '68800777' not in [str(s) for s in sdk.manager.GetDeviceList(68)]:
    raise RuntimeError('Expected target absent')
if str(sdk.manager.GetTransportInfo('68800777').GetProvider()) != 'FTDI':
    raise RuntimeError('USB required')
d = sdk.device_type.CreateKCubeSolenoid('68800777')
close_attempted = False

def properties(obj):
    return {p.Name: str(p.GetValue(obj, None)) for p in obj.GetType().GetProperties()}

def status():
    d.RequestStatus()
    d.RequestOperatingMode()
    d.RequestOperatingState()
    time.sleep(0.25)
    return {'bits': int(d.GetStatusBits()), 'status': properties(d.Status),
            'mode': str(d.GetOperatingMode()), 'operation': str(d.GetOperatingState()),
            'shutter': str(d.GetSolenoidState()), 'IsConnected': bool(d.IsConnected),
            'CommsStatus': str(d.CommsStatus)}

def wait_closed(manual=False):
    deadline = time.monotonic() + 5
    while True:
        value = status()
        if not value['IsConnected'] or value['CommsStatus'] != 'OK':
            raise RuntimeError('Communication lost')
        if (value['shutter'] == 'Closed' and value['operation'] == 'Inactive'
            and (not manual or value['mode'] == 'Manual')):
            return value
        if time.monotonic() >= deadline:
            raise RuntimeError('Required Closed/Inactive feedback not received: '+str(value))

try:
    d.Connect('68800777')
    if not d.IsSettingsInitialized():
        d.WaitForSettingsInitialized(5000)
    if not d.IsSettingsInitialized():
        raise RuntimeError('Settings uninitialized')
    d.StartPolling(250)
    time.sleep(0.5)
    report['identity'] = properties(d.GetDeviceInfo())
    if report['identity']['SerialNumberText'] != '68800777' or report['identity']['Name'] != 'KSC101':
        raise RuntimeError('Target identity mismatch')
    report['before'] = status()
    print('PRE-COMMAND STATUS:', json.dumps(report['before']), flush=True)
    if not report['before']['IsConnected'] or report['before']['CommsStatus'] != 'OK':
        raise RuntimeError('Communication not ready')
    # Independent parameter reads never apply or persist the values.
    d.RequestCycleParams()
    time.sleep(0.25)
    report['cycle_params'] = properties(d.GetCycleParams())
    d.RequestTriggerConfigParams()
    time.sleep(0.25)
    report['trigger_params'] = properties(d.GetTriggerConfigParams())
    # Explicit Close establishes Inactive; prior raw 0 is never relabeled.
    close_attempted = True
    d.SetOperatingState(sdk.enums.OperatingStates.Inactive)
    report['closed_feedback'] = wait_closed()
    d.SetOperatingMode(sdk.enums.OperatingModes.Manual)
    report['final'] = wait_closed(manual=True)
    report['result'] = 'READS_AND_CLOSE_READBACK_PASS; physical confirmation pending'
except BaseException as exc:
    report['errors'].append(f'{type(exc).__name__}: {exc}')
    report['result'] = 'FAIL; no automatic test retry'
    if close_attempted:
        try:
            d.SetOperatingState(sdk.enums.OperatingStates.Inactive)
            report['cleanup_close_feedback'] = wait_closed()
        except BaseException as cleanup:
            report['errors'].append('cleanup Close: '+str(cleanup))
finally:
    try:
        d.StopPolling()
        d.Disconnect()
        d = None
        report['release'] = 'COMPLETED'
    except BaseException as exc:
        report['errors'].append('release: '+str(exc))
        report['release'] = 'UNCONFIRMED'
    report['retained_handle'] = d is not None
    path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
