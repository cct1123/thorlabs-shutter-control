"""Read-only identity-layer diagnostic. No Enable, mode, state or TTL setter."""
import ctypes as ct
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from thorlabs_shutter_control.controller import _load_sdk

sdk = _load_sdk(None)
sdk.manager.BuildDeviceList()
serials = [str(s) for s in sdk.manager.GetDeviceList(68)]
if "68800777" not in serials:
    raise RuntimeError(f"Target unavailable: {serials}; do not connect another identity")

class HardwareInfo(ct.Structure):
    _pack_ = 1
    _fields_ = [('serial',ct.c_uint32),('model',ct.c_char*8),('type',ct.c_uint16),
                ('firmware',ct.c_uint32),('notes',ct.c_char*48),('device_data',ct.c_ubyte*12),
                ('hardware',ct.c_uint16),('modification',ct.c_uint16),('channels',ct.c_int16)]

native = ct.CDLL(str(sdk.directory / 'Thorlabs.MotionControl.KCube.Solenoid.dll'))
native.SC_GetHardwareInfoBlock.argtypes = [ct.c_char_p,ct.POINTER(HardwareInfo)]
native.SC_GetHardwareInfoBlock.restype = ct.c_int16
d = sdk.device_type.CreateKCubeSolenoid('68800777')
report = {'recorded_at':datetime.now(timezone.utc).isoformat(), 'discovered_serials':serials,
          'scope':'passive identity diagnostic; production guard unchanged', 'errors':[]}
polling = False
try:
    d.Connect('68800777')
    if not d.IsSettingsInitialized():
        d.WaitForSettingsInitialized(5000)
    d.StartPolling(250)
    polling = True
    time.sleep(0.5)
    hw = HardwareInfo()
    rc = native.SC_GetHardwareInfoBlock(b'68800777', ct.byref(hw))
    report['native_hardware_info'] = {'return':rc, 'serial':hw.serial,'model':hw.model.decode(),
        'firmware_raw':hw.firmware,'hardware':hw.hardware,'channels':hw.channels,'notes':hw.notes.decode()}
    info = d.GetDeviceInfo()
    report['dotnet_info'] = {p.Name:str(p.GetValue(info,None)) for p in info.GetType().GetProperties()}
    report['selected_identity'] = {'SerialNo':str(d.SerialNo),'DeviceID':str(d.DeviceID)}
    d.RequestHubBay()
    d.RequestStatus()
    time.sleep(0.25)
    report['reported_feedback'] = {'hub_bay':d.GetHubBay(),'mode':str(d.GetOperatingMode()),
        'operation':str(d.GetOperatingState()),'shutter':str(d.GetSolenoidState()),
        'key_enabled':bool(d.Status.KeyEnabled),'status_bits':int(d.GetStatusBits()),'comms':str(d.CommsStatus)}
except BaseException as exc:
    report['errors'].append(f'Read: {type(exc).__name__}: {exc}')
finally:
    if polling:
        try:
            d.StopPolling()
        except BaseException as exc:
            report['errors'].append(f'StopPolling: {type(exc).__name__}: {exc}')
    try:
        d.Disconnect()
        report['passive_release'] = 'COMPLETED'
    except BaseException as exc:
        report['errors'].append(f'Disconnect: {type(exc).__name__}: {exc}')
        report['passive_release'] = 'UNCONFIRMED; retain d'
    Path('records/usb-identity-detail-2026-10-20.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2),flush=True)
