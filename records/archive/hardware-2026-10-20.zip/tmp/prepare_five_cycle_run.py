from pathlib import Path
import ast

s = Path('tmp/sdk_stage34_run.py').read_text()
s = s.replace('sdk-stage34-run-2026-10-20.json', 'sdk-five-cycles-2s-2026-10-20.json')
s = s.replace('one SDK Close/Open/10s/Close bench sequence', 'five SDK Open/2s/Close/2s cycles')
s = s.replace('prior 10s hold approval', 'latest explicit 2s Open/2s Closed hold for five cycles')
s = s.replace("'added_open_hold_s': 10", "'added_open_hold_s': 2, 'added_closed_hold_s': 2, 'requested_cycles': 5, 'cycles': []")
begin = s.index("    phase = 'Stage4 pre-Open check'")
end = s.index('except BaseException as exc:', begin)
s = s[:begin] + '''    phase = 'sequence preparation'
    report['pre_open'] = read()
    if not report['pre_open']['key_enabled'] or (
        report['pre_open']['shutter'], report['pre_open']['operation'], report['pre_open']['mode']
    ) != ('Closed', 'Inactive', 'Manual'):
        raise RuntimeError('Open preparation not verified')
    command('EnableDevice', d.EnableDevice)
    for cycle_no in range(1, 6):
        phase = f'cycle {cycle_no} pre-Open status'
        current = read()
        if not current['key_enabled'] or (
            current['shutter'], current['operation'], current['mode']
        ) != ('Closed', 'Inactive', 'Manual'):
            raise RuntimeError('Cycle readiness not verified')
        cycle = {'cycle': cycle_no, 'status': 'IN_PROGRESS', 'pre_open': current}
        report['cycles'].append(cycle)
        phase = f'cycle {cycle_no} Open'
        command(f'cycle {cycle_no} SetOperatingState Active',
                lambda: d.SetOperatingState(sdk.enums.OperatingStates.Active))
        cycle['open'] = wait_for('Open', 'Active', manual=True)
        cycle['open_feedback_at_utc'] = datetime.now(timezone.utc).isoformat()
        opened_at = time.monotonic()
        save()
        print(f'CYCLE {cycle_no}/5: Open feedback; hold 2 s', flush=True)
        phase = f'cycle {cycle_no} Open hold'
        time.sleep(2)
        cycle['open_feedback_to_close_request_s'] = time.monotonic() - opened_at
        phase = f'cycle {cycle_no} Close'
        command(f'cycle {cycle_no} SetOperatingState Inactive',
                lambda: d.SetOperatingState(sdk.enums.OperatingStates.Inactive))
        cycle['closed'] = wait_for('Closed', 'Inactive', manual=True)
        cycle['closed_feedback_at_utc'] = datetime.now(timezone.utc).isoformat()
        closed_at = time.monotonic()
        phase = f'cycle {cycle_no} Closed hold'
        time.sleep(2)
        cycle['closed_hold_observed_s'] = time.monotonic() - closed_at
        cycle['status'] = 'READBACK_PASS'
        save()
        print(f'CYCLE {cycle_no}/5: Closed feedback and 2 s hold complete', flush=True)
    report['completed_cycles'] = 5
    report['stage4'] = 'READBACK_PASS'
''' + s[end:]
s = s.replace('SDK_STAGE3_4_READBACK_PASS', 'SDK_FIVE_CYCLE_READBACK_PASS')
ast.parse(s)
Path('tmp/sdk_five_cycle_run.py').write_text(s)
print('Corrected five-cycle procedure parses')
