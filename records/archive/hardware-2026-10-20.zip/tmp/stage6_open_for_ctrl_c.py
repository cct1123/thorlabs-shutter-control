import json
import sys
import time
import urllib.request
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0,str(Path("docs/hardware_tests").resolve()))
from stage_6 import callback_payload
base="http://127.0.0.1:8050"
path=Path("records/stage6-before-ctrl-c-2026-10-20.json")
if path.exists():
    raise RuntimeError("Do not repeat existing run")
with urllib.request.urlopen(base+"/_dash-dependencies",timeout=10) as r:
    dependency=json.load(r)[0]
# Keep counts above the prior lifecycle counts. Only changedPropIds invokes actions.
counters={"open-1.n_clicks":1,"close-1.n_clicks":3,"connect-1.n_clicks":2,
          "disconnect-1.n_clicks":1,"refresh.n_intervals":20}
def call(action):
    req=urllib.request.Request(base+"/_dash-update-component",data=json.dumps(
       callback_payload(dependency,action,"68800777",counters)).encode(),
       headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=30) as response:
        return json.load(response)["response"]
report={"utc":datetime.now(timezone.utc).isoformat(),"physical_status":"UNTESTED"}
try:
    ready=call("refresh")
    if ready["shutter-state-1"]["children"] != "Closed" or ready["open-1"]["disabled"]:
        raise RuntimeError("GUI is not ready for approved Open")
    report["before"]=ready
    report["open"]=call("open-1")
    if report["open"]["shutter-state-1"]["children"] != "Open":
        raise RuntimeError("Open feedback missing")
    start=time.monotonic()
    time.sleep(2)
    report["added_hold_s"]=time.monotonic()-start
    report["ready_for_terminal_ctrl_c_monotonic_s"]=time.monotonic()
    report["status"]="OPEN_READBACK_READY_FOR_CTRL_C"
    path.write_text(json.dumps(report,indent=2)+"\n")
    print(report["status"],flush=True)
except BaseException as exc:
    report["error"]=str(exc)
    try:
        report["error_cleanup"]=call("shutdown-all")
    finally:
        path.write_text(json.dumps(report,indent=2)+"\n")
    raise
