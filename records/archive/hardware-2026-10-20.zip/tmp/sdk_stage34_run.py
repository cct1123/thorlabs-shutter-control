"""Explicitly authorized one SDK Close/Open/10s/Close bench sequence."""
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from thorlabs_shutter_control.controller import _load_sdk

path = Path('records/sdk-stage34-run-2026-10-20.json')
if path.exists():
    raise RuntimeError('No overwrite or automatic repeat')
report = {
    'time_utc': datetime.now(timezone.utc).isoformat(),
    'authority': 'User requests Stage3/4 after reviewing E074 Close results, then control the shutter; prior 10s hold approval',
    'interlock_basis': 'Human explicitly confirms installed normal jack / physical interlock enabled; SDK bit unverified',
    'protection': 'Previously confirmed independent source block remains an operating condition',
    'scope': 'Direct official SDK bench sequence; not production guard qualification',
    'added_open_hold_s': 10, 'physical_status': 'PENDING_OBSERVATION',
    'errors': [], 'commands': [], 'stage3': 'UNTESTED', 'stage4': 'UNTESTED',
}
sdk = _load_sdk(None)
sdk.manager.BuildDeviceList()
if '68800777' not in [str(s) for s in sdk.manager.GetDeviceList(68)]:
    raise RuntimeError('Expected target absent')
if str(sdk.manager.GetTransportInfo('68800777').GetProvider()) != 'FTDI':
    raise RuntimeError('USB required')
d = sdk.device_type.CreateKCubeSolenoid('68800777')
verified = False
phase = 'connect'
interrupted = None

def save():
    path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')

def command(label, call):
    report['commands'].append({'command': label, 'at_utc': datetime.now(timezone.utc).isoformat()})
    save()  # durable intent before output
    call()

def read():
    d.RequestStatus()
    d.RequestOperatingMode()
    d.RequestOperatingState()
    time.sleep(0.25)
    value = {'bits': int(d.GetStatusBits()), 'mode': str(d.GetOperatingMode()),
             'operation': str(d.GetOperatingState()), 'shutter': str(d.GetSolenoidState()),
             'key_enabled': bool(d.Status.KeyEnabled),
             'connected': bool(d.IsConnected), 'comms': str(d.CommsStatus)}
    if not value['connected'] or value['comms'] != 'OK':
        raise RuntimeError('Communication not ready: '+str(value))
    return value

def wait_for(shutter, operation, manual=False):
    deadline = time.monotonic() + 5
    while True:
        value = read()
        if (value['shutter'] == shutter and value['operation'] == operation
            and (not manual or value['mode'] == 'Manual')
            and (shutter != 'Open' or value['key_enabled'])):
            return value
        if time.monotonic() >= deadline:
            raise RuntimeError('Feedback timeout: '+str(value))

save()
try:
    d.Connect('68800777')
    if not d.IsSettingsInitialized():
        d.WaitForSettingsInitialized(5000)
    if not d.IsSettingsInitialized():
        raise RuntimeError('Settings uninitialized')
    d.StartPolling(250)
    time.sleep(0.5)
    info = d.GetDeviceInfo()
    report['identity'] = {'serial': str(info.SerialNumberText), 'name': str(info.Name),
                          'firmware': str(info.FirmwareVersion), 'hardware': str(info.HardwareVersion)}
    if report['identity'] != {'serial': '68800777', 'name': 'KSC101', 'firmware': '1.0.7', 'hardware': '3'}:
        raise RuntimeError('Unexpected target/version')
    phase = 'fresh status before output'
    report['before'] = read()
    print('PRE-COMMAND:', json.dumps(report['before']), flush=True)
    if report['before']['shutter'] not in ('Open', 'Closed') or report['before']['mode'] not in (
        'Manual', 'SingleToggle', 'AutoToggle', 'Triggered'
    ):
        raise RuntimeError('Unknown shutter/mode feedback')
    if not report['before']['key_enabled']:
        raise RuntimeError('Key is disabled; no sequence output')
    verified = True
    phase = 'Stage3 Close'
    command('SetOperatingState Inactive', lambda: d.SetOperatingState(sdk.enums.OperatingStates.Inactive))
    report['stage3_closed'] = wait_for('Closed', 'Inactive')
    command('SetOperatingMode Manual', lambda: d.SetOperatingMode(sdk.enums.OperatingModes.Manual))
    report['stage3_final'] = wait_for('Closed', 'Inactive', manual=True)
    report['stage3'] = 'READBACK_PASS'
    save()
    phase = 'Stage4 pre-Open check'
    report['pre_open'] = read()
    if not report['pre_open']['key_enabled'] or (
        report['pre_open']['shutter'], report['pre_open']['operation'], report['pre_open']['mode']
    ) != ('Closed', 'Inactive', 'Manual'):
        raise RuntimeError('Open preparation not verified')
    phase = 'Stage4 Enable/Open'
    command('EnableDevice', d.EnableDevice)
    command('SetOperatingState Active', lambda: d.SetOperatingState(sdk.enums.OperatingStates.Active))
    report['open'] = wait_for('Open', 'Active', manual=True)
    report['open_feedback_at_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print('OPEN FEEDBACK; approved 10-second added hold', flush=True)
    phase = 'Stage4 added hold'
    time.sleep(10)
    phase = 'Stage4 Close'
    command('SetOperatingState Inactive', lambda: d.SetOperatingState(sdk.enums.OperatingStates.Inactive))
    report['closed'] = wait_for('Closed', 'Inactive', manual=True)
    report['stage4'] = 'READBACK_PASS'
except BaseException as exc:
    report['errors'].append(f'{phase}: {type(exc).__name__}: {exc}')
    report['failed_phase'] = phase
    if not isinstance(exc, Exception):
        interrupted = exc
finally:
    if verified:
        try:
            command('cleanup SetOperatingState Inactive', lambda: d.SetOperatingState(sdk.enums.OperatingStates.Inactive))
            report['cleanup_closed'] = wait_for('Closed', 'Inactive')
        except BaseException as exc:
            report['errors'].append('cleanup Close: '+str(exc))
            if interrupted is None and not isinstance(exc, Exception):
                interrupted = exc
    try:
        d.StopPolling()
    except BaseException as exc:
        report['errors'].append('StopPolling: '+str(exc))
    try:
        d.Disconnect()
        d = None
        report['release'] = 'COMPLETED'
    except BaseException as exc:
        report['errors'].append('Disconnect: '+str(exc))
        report['release'] = 'UNCONFIRMED'
    report['retained_handle'] = d is not None
    report['result'] = 'ERROR' if report['errors'] else 'SDK_STAGE3_4_READBACK_PASS'
    save()
    print(json.dumps(report, indent=2), flush=True)
if interrupted is not None:
    interrupted.add_note(json.dumps(report))
    raise interrupted
