"""Authorized passive USB probe. Retain c in the interactive process for recovery."""
import json
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from thorlabs_shutter_control import KCubeShutter

c = KCubeShutter("68800777")
results = []
evidence = Path("records/passive-usb-2026-10-20.json")
if evidence.exists():
    raise RuntimeError("Evidence already exists; do not overwrite or repeat automatically")


def run_cycle():
    if results and results[-1]["errors"]:
        raise RuntimeError("Previous cycle failed; resolve on this object before repeating")
    result = {
        "cycle": len(results) + 1,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "serial": c.serial_number,
        "transport": "USB",
        "authority": "User requested USB then Ethernet communication and confirmed safe to test",
        "independent_physical_observation": "PENDING HUMAN REPORT",
        "errors": [],
    }
    start = time.monotonic()
    try:
        result["connect_status"] = asdict(c.connect())
        result["identity"] = c.identify_device()
        result["read_status"] = asdict(c.get_status())
        if result["identity"]["serial_number"] != "68800777":
            raise RuntimeError("Unexpected identity")
        if result["read_status"]["connection"] != "connected":
            raise RuntimeError("Unhealthy readback")
    except BaseException as exc:
        result["errors"].append(f"Read: {type(exc).__name__}: {exc}")
    finally:
        try:
            c.disconnect(close_shutter=False)
            result["passive_release"] = "COMPLETED"
        except BaseException as exc:
            result["errors"].append(f"Release: {type(exc).__name__}: {exc}")
            result["passive_release"] = "UNCONFIRMED; retain c for diagnosis"
    result["elapsed_s"] = time.monotonic() - start
    results.append(result)
    evidence.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)
    return result


run_cycle()
