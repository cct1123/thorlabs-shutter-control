"""Passive comparison of SDK status requests; no output/configuration calls."""
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from thorlabs_shutter_control import KCubeShutter

path = Path('records/interlock-ab-closed-2026-10-20.json')
if path.exists():
    raise RuntimeError('Do not overwrite evidence')
c = KCubeShutter('68800777')
report = {'time_utc': datetime.now(timezone.utc).isoformat(), 'errors': [], 'samples': [], 'human_reported_condition': 'Interlock circuit closed; 3.5 mm jack plugged in (human reported)'}

def sample(label):
    d = c._device
    bits = int(d.GetStatusBits())
    report['samples'].append({
        'request': label, 'bits': bits, 'hex': hex(bits),
        'header_interlock_0x1000': bool(bits & 0x1000),
        'status': {p.Name: str(p.GetValue(d.Status, None))
                   for p in d.Status.GetType().GetProperties()},
        'IsConnected': bool(d.IsConnected), 'CommsStatus': str(d.CommsStatus),
    })

try:
    c.discover()
    if str(c._sdk.manager.GetTransportInfo(c.serial_number).GetProvider()) != 'FTDI':
        raise RuntimeError('USB required')
    c.connect()
    report['identity'] = c.identify_device()
    sample('production RequestStatus with polling')
    c._device.StopPolling()
    c._device.RequestStatusBits()
    time.sleep(0.5)
    sample('explicit RequestStatusBits; polling stopped; wait 0.5 s')
    c._device.RequestStatus()
    time.sleep(0.5)
    sample('explicit RequestStatus; polling stopped; wait 0.5 s')
except BaseException as exc:
    report['errors'].append(f'{type(exc).__name__}: {exc}')
finally:
    try:
        c.disconnect(close_shutter=False)
        report['release'] = 'COMPLETED'
    except BaseException as exc:
        report['errors'].append('release: '+str(exc))
        report['release'] = 'UNCONFIRMED'
    report['retained_handle'] = c._device is not None
    path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
