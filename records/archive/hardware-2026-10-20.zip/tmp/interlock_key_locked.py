"""Read raw status despite unknown operating state; never output/configure."""
import json
import time
from pathlib import Path
from datetime import datetime, timezone
from thorlabs_shutter_control.controller import _load_sdk

path = Path('records/interlock-key-locked-2026-10-20.json')
if path.exists():
    raise RuntimeError('Do not overwrite evidence')
sdk = _load_sdk(None)
sdk.manager.BuildDeviceList()
if '68800777' not in [str(s) for s in sdk.manager.GetDeviceList(68)]:
    raise RuntimeError('Target not found')
if str(sdk.manager.GetTransportInfo('68800777').GetProvider()) != 'FTDI':
    raise RuntimeError('USB required')
d = sdk.device_type.CreateKCubeSolenoid('68800777')
report = {'time_utc': datetime.now(timezone.utc).isoformat(), 'samples': [], 'errors': [],
          'human_reported_condition': '3.5 mm jack installed; key locked (human reported); continuity not measured',
          'scope': 'Raw readback only; unknown operating state is not motion-ready'}

def sample(label):
    bits = int(d.GetStatusBits())
    report['samples'].append({'request': label, 'bits': bits, 'hex': hex(bits),
        'header_interlock_0x1000': bool(bits & 0x1000),
        'status': {p.Name: str(p.GetValue(d.Status, None))
                   for p in d.Status.GetType().GetProperties()},
        'IsConnected': bool(d.IsConnected), 'CommsStatus': str(d.CommsStatus)})

try:
    d.Connect('68800777')
    if not d.IsSettingsInitialized():
        d.WaitForSettingsInitialized(5000)
    d.StartPolling(250)
    time.sleep(0.5)
    info = d.GetDeviceInfo()
    report['identity'] = {'serial_number': str(info.SerialNumberText),
                           'firmware': str(info.FirmwareVersion),
                           'hardware': str(info.HardwareVersion)}
    if report['identity']['serial_number'] != '68800777':
        raise RuntimeError('Identity mismatch')
    d.RequestStatus()
    d.RequestOperatingMode()
    d.RequestOperatingState()
    time.sleep(0.25)
    sample('RequestStatus with polling; raw unknown feedback allowed for diagnosis')
    d.StopPolling()
    d.RequestStatusBits()
    time.sleep(0.5)
    sample('explicit RequestStatusBits; polling stopped; wait 0.5 s')
    d.RequestStatus()
    time.sleep(0.5)
    sample('explicit RequestStatus; polling stopped; wait 0.5 s')
except BaseException as exc:
    report['errors'].append(f'{type(exc).__name__}: {exc}')
finally:
    try:
        d.StopPolling()
        d.Disconnect()
        d = None
        report['release'] = 'COMPLETED'
    except BaseException as exc:
        report['errors'].append('release: '+str(exc))
        report['release'] = 'UNCONFIRMED'
    report['retained_handle'] = d is not None
    path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
