from pathlib import Path
import ast

s = Path('tmp/compare_status_requests.py').read_text()
s = s.replace('status-request-comparison-2026-10-20.json', 'interlock-ab-open-2026-10-20.json')
s = s.replace("'samples': []", "'samples': [], 'human_reported_condition': 'Interlock circuit open; 3.5 mm jack removed'")
ast.parse(s)
Path('tmp/interlock_ab_open.py').write_text(s)
