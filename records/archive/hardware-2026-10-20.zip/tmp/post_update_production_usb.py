"""One USB passive cycle; no output/configuration or updater calls."""
import hashlib
import json
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from thorlabs_shutter_control import KCubeShutter, ShutterError
from thorlabs_shutter_control import controller as module

report = {
    'recorded_at': datetime.now(timezone.utc).isoformat(),
    'authority': 'User authorized KSC101 firmware update; post-update passive USB validation; actuation held',
    'serial': '68800777',
    'transport': 'USB',
    'module_path': module.__file__,
    'controller_sha256': hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),
    'independent_physical_observation': 'Not supplied for this cycle',
    'errors': [],
}
c = KCubeShutter(report['serial'])
start = time.monotonic()
phase = 'discovery'
try:
    report['discovered'] = c.discover()
    if report['serial'] not in report['discovered']:
        raise ShutterError('Selected controller not discovered; stop before Connect')
    info = c._sdk.manager.GetTransportInfo(report['serial'])
    report['provider'] = str(info.GetProvider())
    report['com_spec'] = str(info.GetComSpec())
    if report['provider'] != 'FTDI':
        raise ShutterError('Expected USB FTDI transport; refusing another transport')
    phase = 'connect_identity_status'
    report['initial_status'] = asdict(c.connect())
    report['identity'] = c.identify_device()
    hardware = c._device.GetDeviceInfo()
    report['firmware'] = str(hardware.FirmwareVersion)
    report['hardware_version'] = str(hardware.HardwareVersion)
    report['reported_status'] = asdict(c.get_status())
    if report['reported_status']['connection'] != 'connected':
        raise ShutterError(report['reported_status']['error'] or 'Status read fault')
    fields = ('shutter_state', 'operating_state', 'operating_mode',
              'key_enabled', 'interlock_enabled', 'trigger_config')
    for sample in (report['initial_status'], report['reported_status']):
        if (sample['serial_number'] != report['serial']
            or sample['shutter_state'] not in ('open', 'closed')
            or sample['operating_state'] not in ('active', 'inactive')
            or sample['operating_mode'] not in ('manual', 'single', 'auto', 'triggered')
            or type(sample['key_enabled']) is not bool
            or type(sample['interlock_enabled']) is not bool
            or sample['trigger_config'] is None):
            raise ShutterError('Unknown/incomplete passive feedback')
    if any(report['initial_status'][f] != report['reported_status'][f] for f in fields):
        raise ShutterError('Feedback changed during passive cycle')
    report['result'] = 'READBACK_CAPTURED; physical acceptance pending independent observation'
except Exception as exc:
    report['errors'].append(f'{phase}: {type(exc).__name__}: {exc}')
    report['result'] = 'FAIL; stop for review, no automatic repeat'
finally:
    try:
        c.disconnect(close_shutter=False)
        report['passive_release'] = 'COMPLETED'
    except Exception as exc:
        report['errors'].append(f'passive release: {type(exc).__name__}: {exc}')
        report['passive_release'] = 'UNCONFIRMED'
        report['result'] = 'FAIL; retain owner for diagnosis'
    report['has_device_after_release'] = c._device is not None
    report['elapsed_s'] = round(time.monotonic() - start, 3)
    Path('records/firmware-post-production-usb-2026-10-20.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
