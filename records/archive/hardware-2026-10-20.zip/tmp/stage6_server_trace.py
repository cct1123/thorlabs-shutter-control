import json
import logging
import time
from dataclasses import asdict
from pathlib import Path
from datetime import datetime, timezone
from thorlabs_shutter_control import KCubeShutter, ShutterHub
from thorlabs_shutter_control.__main__ import main

path = Path("records/stage6-confirmed-server-2026-10-20.json")
if path.exists():
    raise RuntimeError("Preserve existing run")
report = {"utc":datetime.now(timezone.utc).isoformat(), "events":[],
          "scope":"Production CLI and hardware methods; wrappers only log calls/results",
          "normal_terminal_ctrl_c":"PENDING"}
def save():
    path.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
original_close = KCubeShutter.close_shutter
original_open = KCubeShutter.open_shutter
original_shutdown = ShutterHub.safe_shutdown
in_shutdown = False
def traced_close(self):
    result = original_close(self)
    report["events"].append({"method":"close_shutter", "during_hub_shutdown":in_shutdown,
                            "status":asdict(result), "monotonic_s":time.monotonic()})
    save()
    return result
def traced_open(self):
    result = original_open(self)
    report["events"].append({"method":"open_shutter", "status":asdict(result),
                            "monotonic_s":time.monotonic()})
    save()
    return result
def traced_shutdown(self):
    global in_shutdown
    in_shutdown = True
    event = {"method":"hub.safe_shutdown", "started_utc":datetime.now(timezone.utc).isoformat()}
    report["events"].append(event)
    save()
    started = time.monotonic()
    try:
        original_shutdown(self)
        event["status"] = "COMPLETED"
    except BaseException as exc:
        event["status"] = "ERROR"
        event["error"] = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        event["elapsed_s"] = time.monotonic()-started
        event["retained_handles"] = [c._device is not None for c in self.controllers]
        in_shutdown = False
        save()
KCubeShutter.close_shutter = traced_close
KCubeShutter.open_shutter = traced_open
ShutterHub.safe_shutdown = traced_shutdown
logging.getLogger("werkzeug").setLevel(logging.WARNING)
save()
try:
    report["main_result"] = main()
finally:
    report["main_finally_utc"] = datetime.now(timezone.utc).isoformat()
    save()
