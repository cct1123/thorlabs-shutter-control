"""One authorized Stage-3 Close using the reviewed protected REPL procedure."""
import hashlib
import json
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from thorlabs_shutter_control import KCubeShutter, ShutterError
from thorlabs_shutter_control import controller as module

path = Path('records/stage3-hardware-2026-10-20.json')
if path.exists():
    raise RuntimeError('Do not overwrite or automatically repeat Stage 3')
c = KCubeShutter('68800777')
verified = False
interrupted = None
result = {'stage': 3, 'recorded_at': datetime.now(timezone.utc).isoformat(),
          'authority': 'User: do hardware run; Stage 3 status then Close only',
          'serial': c.serial_number, 'physical_test_status': 'UNTESTED',
          'scope': 'Single authorized Close/readback via reviewed REPL procedure; incomplete bench record prevents full physical acceptance',
          'controller_sha256': hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),
          'errors': []}
start = time.monotonic()
phase = 'discovery'
try:
    result['discovered'] = c.discover()
    if c.serial_number not in result['discovered']:
        raise ShutterError('Expected target not found')
    if str(c._sdk.manager.GetTransportInfo(c.serial_number).GetProvider()) != 'FTDI':
        raise ShutterError('Refusing non-USB transport')
    phase = 'connect'
    result['connected'] = asdict(c.connect())
    phase = 'identity'
    result['identity'] = c.identify_device()
    result['firmware'] = str(c._device.GetDeviceInfo().FirmwareVersion)
    phase = 'pre-motion status'
    status = c.get_status()
    result['pre_motion'] = asdict(status)
    print('STATUS BEFORE MOTION:', json.dumps(result['pre_motion']), flush=True)
    if (result['identity']['serial_number'] != '68800777'
        or result['firmware'] != '1.0.7'
        or status.serial_number != '68800777'
        or status.connection != 'connected' or not status.has_device
        or status.shutter_state not in ('open', 'closed')
        or status.operating_state not in ('active', 'inactive')
        or status.operating_mode not in ('manual', 'single', 'auto', 'triggered')
        or type(status.key_enabled) is not bool
        or type(status.interlock_enabled) is not bool
        or status.trigger_config is None):
        raise ShutterError('Target/current feedback not verified; no output permitted')
    verified = True
    phase = 'Close'
    result['close'] = asdict(c.close_shutter())
    phase = 'final status'
    final = c.get_status()
    result['final'] = asdict(final)
    if final.connection != 'connected' or (
        final.shutter_state, final.operating_state, final.operating_mode
    ) != ('closed', 'inactive', 'manual'):
        raise ShutterError(final.error or 'Final Closed/Inactive/Manual missing')
except BaseException as exc:
    result['errors'].append(f'{phase}: {type(exc).__name__}: {exc}')
    if not isinstance(exc, Exception):
        interrupted = exc
finally:
    result['cleanup_close_authorized'] = verified
    try:
        c.disconnect(close_shutter=verified)
        result['communication_release'] = 'COMPLETED'
    except BaseException as exc:
        result['errors'].append(f'cleanup: {type(exc).__name__}: {exc}')
        result['communication_release'] = 'UNCONFIRMED'
        if interrupted is None and not isinstance(exc, Exception):
            interrupted = exc
    result['has_device_after_release'] = c._device is not None
    result['status'] = 'ERROR' if result['errors'] else 'CLOSE_READBACK_CAPTURED'
    result['elapsed_s'] = round(time.monotonic() - start, 3)
    path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2), flush=True)
if interrupted is not None:
    interrupted.add_note(json.dumps(result))
    raise interrupted
