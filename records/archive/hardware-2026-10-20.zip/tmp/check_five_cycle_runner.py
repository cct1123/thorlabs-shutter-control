"""Software-only checks of the exact pending bench script."""
import json
import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path('tests').resolve()))
from conftest import FakeDevice

source = Path('tmp/sdk_five_cycle_run.py').read_text()

class Device(FakeDevice):
    def GetDeviceInfo(self):
        return SimpleNamespace(SerialNumberText='68800777', Name='KSC101',
                               FirmwareVersion='1.0.7', HardwareVersion='3')

for case in ('healthy', 'open_feedback_failure', 'interrupt_hold'):
    d = Device('68800777')
    if case == 'open_feedback_failure':
        d.GetSolenoidState = lambda: 'Closed'
    clock = [0.0]
    sleeps = []
    def sleep(seconds):
        sleeps.append(seconds)
        if case == 'interrupt_hold' and seconds == 2:
            raise KeyboardInterrupt('FAKE HOLD INTERRUPTION')
        clock[0] += seconds
    fake_time = SimpleNamespace(sleep=sleep, monotonic=lambda: clock[0])
    fake_sdk = SimpleNamespace(
        manager=SimpleNamespace(BuildDeviceList=lambda: None,
            GetDeviceList=lambda _: ['68800777'],
            GetTransportInfo=lambda _: SimpleNamespace(GetProvider=lambda: 'FTDI')),
        device_type=SimpleNamespace(CreateKCubeSolenoid=lambda _: d),
        enums=SimpleNamespace(OperatingStates=SimpleNamespace(Active='Active', Inactive='Inactive'),
                               OperatingModes=SimpleNamespace(Manual='Manual')))
    target = f'tmp/five-cycle-fake-{case}.json'
    Path(target).unlink(missing_ok=True)  # only this known generated fake output
    program = source.replace('import time', 'time = fake_time').replace(
        'from thorlabs_shutter_control.controller import _load_sdk',
        '_load_sdk = lambda _: fake_sdk').replace(
        'records/sdk-five-cycles-2s-2026-10-20.json', target)
    try:
        exec(compile(program, '<FAKE BENCH SCRIPT>', 'exec'),
             {'fake_time': fake_time, 'fake_sdk': fake_sdk})
    except KeyboardInterrupt:
        assert case == 'interrupt_hold'
    result = json.loads(Path(target).read_text())
    active = d.calls.count(('set_state', 'Active'))
    assert result['release'] == 'COMPLETED' and not d.IsConnected and d.state == 'Closed'
    if case == 'healthy':
        assert result['completed_cycles'] == 5 and active == 5
        assert sleeps.count(2) == 10
        assert result['errors'] == []
    else:
        assert active == 1 and result['errors'] and 'completed_cycles' not in result
    print('SOFTWARE CASE PASS:', case)
