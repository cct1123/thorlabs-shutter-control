"""Local single-operator Dash UI for up to three independently owned shutters."""

from dash import Dash, Input, Output, State, ctx, dcc, html, no_update

from .controller import KCubeShutter, ShutterError, ShutterHub


def create_app(controller: KCubeShutter | ShutterHub | None = None) -> Dash:
    """Build a passive three-slot GUI, or use injected controller(s) for integration."""
    hub = (
        controller
        if isinstance(controller, ShutterHub)
        else ShutterHub(controllers=[controller] if controller is not None else None)
    )
    single = len(hub.controllers) == 1

    def component(name, slot):
        return name if single else f"{name}-{slot + 1}"

    def readout(label, value):
        return html.Div([html.Span(label, className="label"), value])

    cards = []
    initial_serials = [c.serial_number for c in hub.controllers if c.serial_number]
    for slot, shutter in enumerate(hub.controllers):

        def cid(name, slot=slot):
            return component(name, slot)

        cards.append(
            html.Section(
                [
                    html.H2(f"Shutter {slot + 1}"),
                    html.Label("Device serial number", htmlFor=cid("serial")),
                    dcc.Dropdown(
                        id=cid("serial"),
                        options=initial_serials,
                        value=shutter.serial_number,
                        placeholder="Discover and select this shutter's serial",
                    ),
                    html.Div(
                        [
                            html.Button("Connect", id=cid("connect"), n_clicks=0),
                            html.Button(
                                "Close & disconnect",
                                id=cid("disconnect"),
                                n_clicks=0,
                                disabled=True,
                            ),
                        ],
                        className="connection-actions",
                    ),
                    readout("Connection", html.Strong("Disconnected", id=cid("connection"))),
                    readout("Device identity", html.Span("Unknown", id=cid("identity"))),
                    readout(
                        "Shutter state · controller reported",
                        html.Strong("Unknown", id=cid("shutter-state"), className="shutter-state"),
                    ),
                    html.P("Key / interlock: unknown", id=cid("safeguards"), className="note"),
                    html.Div(
                        [
                            html.Button(
                                "Open",
                                id=cid("open"),
                                n_clicks=0,
                                disabled=True,
                                className="primary",
                            ),
                            html.Button("Close", id=cid("close"), n_clicks=0, disabled=True),
                        ],
                        className="shutter-actions",
                    ),
                    html.Div(
                        "Select a device to begin.",
                        id=cid("message"),
                        role="status",
                        className="message",
                        **{"aria-live": "polite"},
                    ),
                ],
                className="panel status-panel",
            )
        )

    app = Dash(__name__)
    app.title = "Shutter control"
    app.layout = html.Main(
        [
            html.Header(
                [
                    html.P("LAB CONTROL", className="eyebrow"),
                    html.H1("Shutter control"),
                    html.P("KSC101 · up to three shutters through KEH3 USB", className="subtitle"),
                ]
            ),
            html.Div(
                [
                    html.Button("Discover", id="discover", n_clicks=0),
                    html.Button("Close & disconnect all", id="shutdown-all", n_clicks=0),
                ],
                className="connection-actions",
            ),
            html.Div(
                "Discovery and connection start only when requested.",
                id="hub-message",
                role="status",
                className="message",
                **{"aria-live": "polite"},
            ),
            html.Div(cards, className="shutter-grid"),
            html.P(
                "Reported state does not independently verify optical shutter operation. "
                "Closing this browser tab does not shut down any controller. "
                "Close & disconnect all attempts cleanup for every connected shutter; "
                "verify physical closure independently.",
                className="note",
            ),
            dcc.Interval(id="refresh", interval=1000, n_intervals=0),
        ],
        className="app" if single else "app multi-app",
    )

    fields = [
        ("connection", "children"),
        ("identity", "children"),
        ("shutter-state", "children"),
        ("safeguards", "children"),
        ("message", "children"),
        ("serial", "options"),
        ("serial", "value"),
        ("serial", "disabled"),
        ("connect", "disabled"),
        ("disconnect", "disabled"),
        ("open", "disabled"),
        ("close", "disabled"),
    ]
    actions = {
        component(action, slot): (slot, action)
        for slot in range(len(hub.controllers))
        for action in ("connect", "disconnect", "open", "close")
    }

    @app.callback(
        [Output("hub-message", "children")]
        + [
            Output(component(name, slot), prop)
            for slot in range(len(hub.controllers))
            for name, prop in fields
        ],
        [
            Input("discover", "n_clicks"),
            Input("shutdown-all", "n_clicks"),
            Input("refresh", "n_intervals"),
        ]
        + [Input(name, "n_clicks") for name in actions],
        [State(component("serial", slot), "value") for slot in range(len(hub.controllers))],
        running=[(Output("refresh", "disabled"), True, False)],
    )
    def update(*values):
        with hub.lock:
            selections = list(values[-len(hub.controllers) :])
            messages = [no_update] * len(hub.controllers)
            options = [no_update] * len(hub.controllers)
            selected = [no_update] * len(hub.controllers)
            hub_message = no_update
            action = ctx.triggered_id
            slot = None
            try:
                if action == "discover":
                    serials = hub.discover()
                    for index, shutter in enumerate(hub.controllers):
                        options[index] = serials
                        if shutter.get_status().has_device:
                            # A discovery snapshot may omit a retained/lost device. Keep
                            # its identity visible until cleanup actually releases it.
                            selected[index] = shutter.serial_number
                            options[index] = sorted(set(serials + [shutter.serial_number]))
                            continue
                        # Never assign the same sole device to all three slots automatically.
                        selected[index] = (
                            selections[index]
                            if selections[index] in serials
                            else (serials[0] if single and len(serials) == 1 else None)
                        )
                    hub_message = (
                        f"Found {len(serials)} device(s). Select a distinct serial per shutter."
                    )
                elif action == "shutdown-all":
                    had_devices = [c.get_status().has_device for c in hub.controllers]
                    hub.safe_shutdown()
                    hub_message = "Shutdown attempts completed. Check each shutter's status."
                    messages = [
                        "Close completed with controller feedback; disconnected."
                        if had_device
                        else no_update
                        for had_device in had_devices
                    ]
                elif action in actions:
                    slot, command = actions[action]
                    shutter = hub.controllers[slot]
                    if command == "connect":
                        status = (
                            shutter.connect(selections[slot])
                            if single
                            else hub.connect(slot, selections[slot])
                        )
                        selected[slot] = status.serial_number
                        messages[slot] = "Connected."
                    elif command == "disconnect":
                        shutter.safe_shutdown()
                        messages[slot] = "Close completed with controller feedback; disconnected."
                    elif command == "open":
                        shutter.open_shutter()
                        messages[slot] = "Open completed with controller feedback."
                    elif command == "close":
                        shutter.close_shutter()
                        messages[slot] = "Close completed with controller feedback."
            except ShutterError as exc:
                if slot is None:
                    hub_message = str(exc)
                else:
                    messages[slot] = str(exc)

            result = [hub_message]
            for index, shutter in enumerate(hub.controllers):
                status = shutter.get_status()
                if status.error:
                    messages[index] = status.error
                connected, active = status.connection == "connected", status.has_device
                identity = (
                    " / ".join(v for v in (status.description, status.serial_number) if v)
                    or "Unknown"
                )

                def enabled(value):
                    return "unknown" if value is None else ("enabled" if value else "not enabled")

                result.extend(
                    [
                        status.connection.title(),
                        identity,
                        status.shutter_state.title(),
                        f"Key: {enabled(status.key_enabled)} · "
                        f"Interlock: {enabled(status.interlock_enabled)}",
                        messages[index],
                        options[index],
                        selected[index],
                        active,
                        active,
                        not active,
                        not (connected and status.key_enabled and status.interlock_enabled),
                        not active,
                    ]
                )
            return result

    return app
