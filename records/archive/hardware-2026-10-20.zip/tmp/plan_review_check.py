import contextlib,io,re,sys,textwrap
from pathlib import Path
from types import SimpleNamespace
import pytest
sys.path.insert(0,str(Path.cwd()/'tests'))
from conftest import rig as make_rig
plan=Path('docs/HARDWARE_VALIDATION.md').read_text(encoding='utf-8')
blocks=re.findall(r'```python\n(.*?)```',plan,re.S)
for i,block in enumerate(blocks): compile(textwrap.dedent(block),str(i),'exec')
close=next(b for b in blocks if 'verified = False' in b)
pair=close.replace('    print("Close:", c.close_shutter())\n',next(b for b in blocks if 'print("Initial Close:"' in b),1)
for case in ['identity','retained-identity','unknown','double-failure','interrupt','open-failure','pair','close']:
 with pytest.MonkeyPatch.context() as mp:
  rig=make_rig.__wrapped__(mp)
  mp.setenv('KSC101_SERIAL','68000001')
  if case in ('identity','retained-identity'):
   mp.setattr(rig.device,'GetDeviceInfo',lambda:SimpleNamespace(SerialNumberText='26000000',Description='wrong'))
   if case=='retained-identity': rig.device.fail.add('disconnect')
  if case=='unknown': rig.device.operation='0'
  if case=='double-failure': rig.device.fail.update(['set_state','disconnect'])
  if case in ('open-failure','interrupt'):
   original=rig.device.SetOperatingState
   def failing(state):
    original(state)
    if state=='Active':
     if case=='interrupt': raise KeyboardInterrupt('software interruption')
     raise RuntimeError('software Open failure')
   mp.setattr(rig.device,'SetOperatingState',failing)
  ns={'open_seconds':0.1,'time':SimpleNamespace(sleep=lambda s:None)}
  caught=None
  try:
   with contextlib.redirect_stdout(io.StringIO()): exec(pair if case in ('pair','open-failure','interrupt') else close,ns)
  except BaseException as exc: caught=exc
  if case in ('identity','retained-identity','unknown'):
   assert caught and not any(c[0] in ('set_state','set_mode','enable') for c in rig.device.calls)
  elif case=='double-failure': assert caught and getattr(caught,'__notes__',[])
  elif case in ('open-failure','interrupt'): assert caught and rig.device.state=='Closed' and not rig.device.IsConnected
  else: assert caught is None and rig.device.state=='Closed' and not rig.device.IsConnected
print('PASS: 5 Python blocks compile; 8 software-only motion procedure cases')
