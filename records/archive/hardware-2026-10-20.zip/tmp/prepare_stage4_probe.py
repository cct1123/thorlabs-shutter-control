from pathlib import Path
import ast

s = Path('tmp/stage3_hardware_run.py').read_text()
s = s.replace('stage3-hardware-2026-10-20.json', 'stage4-hardware-2026-10-20.json')
s = s.replace('Stage 3', 'Stage 4').replace('Stage-3', 'Stage-4')
s = s.replace("'stage': 3", "'stage': 4, 'added_open_hold_s': 10")
s = s.replace('status then Close only', 'status then one Open/10s/Close')
s = s.replace('Single authorized Close/readback', 'Single authorized Open/10s/Close readback')
s = s.replace('    verified = True', '''    if not status.key_enabled or not status.interlock_enabled:
        raise ShutterError('Open blocked: key or interlock not enabled; no output')
    verified = True''')
s = s.replace("    phase = 'final status'", '''    phase = 'Open'
    result['open'] = asdict(c.open_shutter())
    phase = 'approved 10 s hold'
    time.sleep(10)
    phase = 'final Close'
    result['final_close'] = asdict(c.close_shutter())
    phase = 'final status' ''')
s = s.replace('CLOSE_READBACK_CAPTURED', 'OPEN_CLOSE_READBACK_CAPTURED')
ast.parse(s)
Path('tmp/stage4_hardware_run.py').write_text(s)
print('Protected sequence parses')
