"""Targeted KEH3 discovery only. No configuration or controller connection."""
import json
from datetime import datetime, timezone
from pathlib import Path
from thorlabs_shutter_control.controller import _load_sdk

sdk = _load_sdk(None)
manager = sdk.manager
before = [{'com_spec':str(e.GetComSpec()),'display':str(e.GetDisplayText()),
           'provider':str(e.GetProvider())} for e in manager.GetManualDeviceEntries()]
print(json.dumps({'existing_manual_entries':before},indent=2),flush=True)
report = {'recorded_at':datetime.now(timezone.utc).isoformat(),
          'ip':'192.168.1.19','port':40303,'scope':'targeted discovery only',
          'usb_disconnected':'human-confirmed','existing_manual_entries':before}
try:
    found = [str(s) for s in manager.ScanEthernetRange('192.168.1.19','192.168.1.19',40303,1000)]
    report['discovered_specs'] = found
except Exception as exc:
    report['error'] = f'{type(exc).__name__}: {exc}'
Path('records/ethernet-discovery-2026-10-20.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2),flush=True)
