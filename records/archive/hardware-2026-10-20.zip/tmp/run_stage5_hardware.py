import json
import sys
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path('docs/hardware_tests').resolve()))
from stage_5 import shutdown_case
from thorlabs_shutter_control import KCubeShutter

path = Path('records/stage5-production-hardware-2026-10-20.json')
if path.exists():
    raise RuntimeError('Do not overwrite/repeat')
c = KCubeShutter('68800777')
report = {'time_utc': datetime.now(timezone.utc).isoformat(),
          'authority': 'User requests Stage5/6 hardware with no human involvement; prior 2s added Open hold retained',
          'scope': 'Production controller, no guard override; electronic readback only', 'cases': []}
for name, hold in [('closed_shutdown', None), ('reconnect_shutdown', None), ('open_shutdown', 2)]:
    result = shutdown_case(c, '68800777', open_seconds=hold)
    result['case'] = name
    report['cases'].append(result)
    path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2), flush=True)
    if result['status'] != 'READBACK_PASS':
        report['stopped_after'] = name
        break
report['retained_handle'] = c._device is not None
report['result'] = 'ALL_CASES_PASS' if len(report['cases']) == 3 and all(
    r['status'] == 'READBACK_PASS' for r in report['cases']) else 'PARTIAL; remaining case blocked or failed'
path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print('STAGE5:', report['result'], 'retained_handle:', report['retained_handle'], flush=True)
