import json
import logging
import time
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from thorlabs_shutter_control import KCubeShutter
from thorlabs_shutter_control.__main__ import main

path=Path("records/gui-ux-hardware-2026-10-20.json")
stop=Path("tmp/ux-recording-complete.flag")
if path.exists() or stop.exists():
    raise RuntimeError("Do not overwrite prior UX run")
r={"started_utc":datetime.now(timezone.utc).isoformat(),
   "scope":"Actual GUI browser actions with USB68800777; wrappers log only, unchanged driver",
   "events":[]}
def save():
    try:
        path.write_text(json.dumps(r,indent=2,default=str)+"\n",encoding="utf-8")
    except OSError as exc:
        print("UX log error: "+str(exc),flush=True)
def instrument(name):
    original=getattr(KCubeShutter,name)
    @wraps(original)
    def call(self,*args,**kwargs):
        if stop.exists():
            return original(self,*args,**kwargs)
        event={"method":name,"serial":self.serial_number,
               "started_utc":datetime.now(timezone.utc).isoformat(),
               "started_monotonic_s":time.monotonic(),"result":"RUNNING"}
        r["events"].append(event)
        save()
        try:
            result=original(self,*args,**kwargs)
            event["result"]="OK"
            event["feedback"]=asdict(result) if is_dataclass(result) else result
            return result
        except BaseException as exc:
            event["result"]="ERROR"
            event["error"]=f"{type(exc).__name__}: {exc}"
            raise
        finally:
            event["elapsed_s"]=time.monotonic()-event["started_monotonic_s"]
            event["has_device_after"]=self._device is not None
            save()
    setattr(KCubeShutter,name,call)
for name in ("discover","connect","open_shutter","close_shutter","get_trigger_config",
             "disconnect","safe_shutdown","configure_triggers","arm_triggers"):
    instrument(name)
logging.getLogger("werkzeug").setLevel(logging.WARNING)
save()
try:
    r["main_result"]=main()
finally:
    r["main_finally_utc"]=datetime.now(timezone.utc).isoformat()
    if not stop.exists():
        save()
