import contextlib,io,re,sys,textwrap
from pathlib import Path
from types import SimpleNamespace
import pytest
sys.path.insert(0,str(Path.cwd()/'tests'))
from conftest import rig as make_rig
from test_ethernet import ethernet as make_ethernet
plan=Path('docs/KSC101_FIRMWARE_UPDATE_REVIEW.md').read_text(encoding='utf-8')
blocks=re.findall(r'```python\n(.*?)```',plan,re.S)
for i,b in enumerate(blocks):compile(textwrap.dedent(b),f'firmware-plan-{i}','exec')
# Substitute only the bench serial for the fixture fictional identity.
blocks=[b.replace('68800777','68000001') for b in blocks]
cycle=next(b for b in blocks if 'operation_error = None' in b)
results=[]
for transport in ['USB','Ethernet']:
 for case in ['healthy','old-firmware','identity-mismatch','unknown','changed-feedback','request-failure','release-failure','combined-failure']:
  with pytest.MonkeyPatch.context() as mp:
   rig=make_rig.__wrapped__(mp)
   if transport=='Ethernet': make_ethernet.__wrapped__(rig,mp)
   identity=rig.device.GetDeviceInfo
   def info():
    value=identity()
    value.FirmwareVersion='1.0.6' if case=='old-firmware' else '1.0.7'
    if case=='identity-mismatch':value.SerialNumberText='26000000'
    return value
   mp.setattr(rig.device,'GetDeviceInfo',info)
   if case=='unknown':rig.device.operation='0'
   if case=='changed-feedback':
    reads=[0]
    def changed():
     reads[0]+=1
     return 'Closed' if reads[0]==1 else 'Open'
    mp.setattr(rig.device,'GetSolenoidState',changed)
   if case in ('request-failure','combined-failure'):rig.device.fail.add('request_operation')
   if case in ('release-failure','combined-failure'):rig.device.fail.add('disconnect')
   ns={}
   exec(blocks[0],ns)
   if transport=='Ethernet':exec(blocks[2],ns)
   caught=None
   try:
    with contextlib.redirect_stdout(io.StringIO()):exec(cycle,ns)
   except Exception as exc:caught=exc
   assert (caught is None)==(case=='healthy'),(transport,case,caught)
   assert not any(c[0] in {'enable','set_state','set_mode','set_triggers'} for c in rig.device.calls)
   if case=='combined-failure':assert any('Passive release also failed' in n for n in getattr(caught,'__notes__',[]))
   if case not in ('release-failure','combined-failure'):assert ns['c']._device is None
   results.append(transport+': '+case)
print(f'{len(blocks)} Python blocks compile; {len(results)} passive software cases PASS; no output writes')
