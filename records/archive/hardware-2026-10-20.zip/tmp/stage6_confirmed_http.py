import json
import sys
import urllib.request
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path('docs/hardware_tests').resolve()))
from stage_6 import callback_payload, closed_gui_lifecycle, open_close_gui

path = Path('records/stage6-confirmed-gui-2026-10-20.json')
if path.exists():
    raise RuntimeError('Do not overwrite/repeat')
base = 'http://127.0.0.1:8050'
counters = {}
def get(route):
    with urllib.request.urlopen(base+route, timeout=15) as response:
        return json.load(response)
deps = get('/_dash-dependencies')
if len(deps) != 1:
    raise RuntimeError('Unexpected GUI dependencies')
def call(action):
    data = callback_payload(deps[0], action, '68800777', counters)
    request = urllib.request.Request(base+'/_dash-update-component',
        data=json.dumps(data).encode(), headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.load(response)['response']

report = {'time_utc': datetime.now(timezone.utc).isoformat(),
          'scope': 'Real running production Dash HTTP callbacks with actual USB; no forged disabled Open action',
          'errors': []}
try:
    layout = get('/_dash-layout')
    report['layout_received'] = isinstance(layout, dict)
    report.update(closed_gui_lifecycle(call, '68800777'))
    report['open_close'] = open_close_gui(call, open_seconds=2)
    report['open_subcases'] = 'OPEN_CLOSE_READBACK_PASS'
    report['sigint_subcase'] = 'PENDING_OPEN_AND_NORMAL_CTRL_C'
except BaseException as exc:
    report['errors'].append(f'{type(exc).__name__}: {exc}')
    try:
        report['error_cleanup'] = call('shutdown-all')
    except BaseException as cleanup:
        report['errors'].append('GUI cleanup: '+str(cleanup))
finally:
    path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k != 'steps'}, indent=2), flush=True)
    print('HTTP STEPS:', len(report.get('steps', [])), flush=True)
