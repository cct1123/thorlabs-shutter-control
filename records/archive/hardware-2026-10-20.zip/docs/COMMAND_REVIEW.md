# KSC101 command and interpretation review

2026-10-20, E070 / TEST-079. Review and software correction only; no hardware
operation or firmware change. Latest known device: KSC101 68800777, hardware3,
firmware1.0.7, KEH3 USB, SH05R. This review does not pass physical stages.

## Findings and corrections

| Finding | Evidence and revision |
| --- | --- |
| Clear bit was overstated as physical interlock Disabled | SDK documents0x1000 as interlock, but four-state measurements never changed it with jack presence. Return unknown/None when clear; retain raw status_bits. Open/Arm remain blocked. |
| Key and interlock were conflated in troubleshooting | Manual describes separate key enable and current-carrying interlock circuit. SDK KeyEnabled tracks the key in the controlled matrix. It is not jack continuity or permission to bypass interlock. |
| SDK bit table is inconsistent with bench correlation | SDK calls0x2000 unused; it followed key state in both jack conditions. Preserve evidence without relabeling it interlock or claiming a verified firmware defect. |
| Repeating the same request did not resolve the discrepancy | RequestStatus/polling and stopped-polling RequestStatusBits/RequestStatus all agree. No supported change to request commands. Explicit waits do not prove every cached field fresh. |
| Auto operating0 is not documented Inactive | SDK/protocol define Active1/Inactive2; preserve unknown error. A failed feedback gate is not proof of failed USB transport. Mode change must not be disguised as a passive diagnostic. |
| Manual sequence needs verified preparation | Close requests Inactive, verifies Closed/Inactive, then Manual and verifies again. Only subsequent explicit Open enables/requests Active. Preserve that sequence and guarded cleanup. |
| Stage3 baseline was not a closing-transition measurement | It began reported Closed and ended Closed. Command/readback/release succeeded; independent blade confirmation and full bench acceptance remain absent. |
| Software hold is not bounded physical exposure | Approved10s would begin after Open feedback; vendor calls and cleanup can extend it. No Open cycle has run. |

The positive0x1000 bit is still treated as a documented reported indication, not
independent circuit measurement. Unknown/negative safeguards cannot enable Open
or TTL Arm. No raw-bit override, state-forcing API, inferred0-to-Inactive alias,
automatic enable experiment or removal of the physical interlock is introduced.

## Sources actually inspected

- [Official KSC101 manual](https://media.thorlabs.com/contentassets/e92d618c92c94cea9096b3f231859611/etn017648-d02.pdf), HA0368T RevD June2023, 45PDF pages. Sections3.3.1 and3.4.2 (pages13/17): no powered jack changes; contact carries solenoid drive current. Section4.2 (page19): key enable;4.3 (page20): mode behavior. Hardware context only: its APT/ActiveX software material is legacy.
- Installed official Kinesis1.14.60.27990 DotNet_API.chm: KCube SolenoidStatus (`a08484.html`), GetStatusBits, RequestStatus, RequestStatusBits (`a08488` member pages), key/state/mode enums; IGenericCoreDeviceCLI health definitions. SolenoidStatus exposes KeyEnabled but no separate interlock property.
- Installed `Thorlabs.MotionControl.KCube.Solenoid.h`, status table lines633–644: documented0x1000 and unused0x2000. Header SHA256 `528c5e92604710c258e5e67326ddeb7a8c9add2b297bd1d903e60ff02ef60445`.
- [Official Python.NET example](https://github.com/Thorlabs/Motion_Control_Examples/blob/main/Python/Kinesis/KCube/KSC101/KSC101_pythonnet.py), downloaded/read, never executed. Confirms factory/Connect/settings/polling/Enable/Manual/Active/Inactive API names. Its direct Enable and unconditional example operations do not establish safeguards or bench permission.
- [Official protocol reference](https://www.thorlabs.com/Software/Motion%20Control/APT_Communications_Protocol.pdf): full download currently returns HTML; relevant vendor-indexed SOL_STATE excerpt defines On1/Off2. Full protocol/status mapping was not independently read or packet-verified. This is a limitation, not evidence of a mapping fix.
- [Four-state bench evidence](../records/interlock-four-state-comparison-2026-10-20.json) and [request comparison](../records/status-request-comparison-2026-10-20.json): human-labelled physical conditions, not electrical continuity measurements.

Manual downloaded to ignored tmp/command-review/ksc101-manual.pdf; SHA256
`b51ac9ca1aa53b02b554dfd5b1c0bd4b99d73e4ba092e47170a64a3f4bab34f5`.
SDK documentation does not guarantee that accepting headless Connecting detects
physical USB loss with a bounded delay; that remains a separate bench test.

## Validation and next boundary

Software regressions cover0/0x2000 as unknown, raw-bit preservation, key not
substituting for interlock, Open/Arm refusal without output and GUI unknown with
both controls disabled. Positive documented bit reporting is retained. Unknown
operating feedback still faults; Close/preparation/error cleanup unchanged.

No hardware retest occurs in this review. Before motion, establish a supported
interlock-reporting contract (vendor clarification or independently validated
measurement) and known operating feedback; repeat affected passive checks on
the revised source. No more identical read cycles are proposed as a diagnosis.
