# Shutter controller package: review and development plan

Review date: 2026-10-20. Scope: architecture, controller contract, three-shutter
GUI, TTL, diagnostics, testing, documentation and release readiness.
Evidence: E035 / TEST-045 in [records](../records/RECORDS.md#e035).
This is a development proposal, not implementation or hardware launch authority.

## Assessment

The package is a useful, compact foundation for a local laboratory controller.
It is not yet a bench-qualified comprehensive controller. The largest gaps are
command ordering, feedback provenance, responsiveness during vendor calls and
physical evidence. Adding more modes before resolving those gaps would increase
the number of behaviors that cannot yet be demonstrated reliably.

Keep the present target: Windows, official Kinesis .NET through Python.NET,
one to three KSC101/SH05R pairs through KEH3 USB, a reusable Python interface and
one local Dash GUI. The reported topology is human-supplied; actual installed
count, identity, firmware, SDK and operating conditions remain unverified.
The backend follows the vendor's
[KSC101 Python.NET example](https://github.com/Thorlabs/Motion_Control_Examples/blob/main/Python/Kinesis/KCube/KSC101/KSC101_pythonnet.py).
That reference supports the API choice, not this package's physical performance
or error-recovery claims.

“Comprehensive” should mean the supported use cases have reproducible setup,
explicit operating states, reliable feedback interpretation, understandable
failures, recovery procedures and measured acceptance. It need not mean every
Thorlabs controller, transport or SDK.

## Preserve

- Passive imports, construction and GUI startup; connection does not configure
  TTL, arm or explicitly request motion.
- Actual serial verification at connection, atomic process-local ownership and
  retained ownership after failed release.
- Three independent controllers and panels; validated TTL settings, separate
  drafts/readback, explicit Apply/Arm and Manual Open refusal while Triggered.
- Fault latching; Inactive and reported Closed before selecting Manual; attempts
  to release handles and clean every slot after ordinary errors or interruptions.
- The simple structure: driver and `ShutterHub` in `controller.py`, GUI in
  `gui.py`, CLI lifecycle in `__main__.py`. No generic device framework is needed.
- Five beginner hardware tutorials, reproducible software devices and the staged
  physical-validation procedure. Keep simulated evidence distinct from bench proof.

## Findings, ordered by consequence

| ID / priority | Evidence and consequence | Recommended change |
| --- | --- | --- |
| F01 / P1 | `gui.py:210–217,263–267` dispatches by `ctx.triggered_id`; it does not validate a command identity or ordering token. A software-only HTTP probe sent Open(1), Close(1), then the same Open(1); reported states were Open, Closed, Open. A stale request can therefore defeat a later Close. Ordinary Dash retries were not observed. | Define server-side command identity and ordering. Close/Disarm/shutdown must invalidate older queued actuation requests; reject duplicate or stale Open/Arm requests. Include browser reload, reconnect and multiple-tab semantics. Client button disabling alone is insufficient. |
| F02 / P1 | `gui.py:239–241` performs full `get_status()` on all controllers before starting global shutdown. A slow or blocked status/settings call can prevent the first closure attempt. | Start cleanup without fresh preflight reads. Return a per-slot shutdown result or use a passive inventory snapshot for messages. Test that the first action is not a status request. |
| F03 / P1 | `controller.py:287–314` requests status/settings and reads SDK getters, including one polling-period sleep for TTL. There is no response generation, sample age or acknowledgment provenance. Immediate software devices cannot establish real cache freshness. | Establish documented SDK response semantics. Distinguish getter observation time from fresh device response and physical position. Represent unknown freshness explicitly; never manufacture a fresh timestamp merely because a getter returned. |
| F04 / P1 | `__main__.py:44` runs a single-threaded server; `gui.py:211` holds the hub lock across vendor calls. Three full status reads include at least 750 ms of deliberate TTL waits at defaults, plus SDK latency. A blocked call can stall every control and sequential cleanup. | Move GUI reads to normalized snapshots and separate routine polling from command execution. Investigate SDK thread ownership before introducing workers. Give Close priority over queued actuation. A Python timeout cannot interrupt an arbitrary native call. |
| F05 / P2 | Public `serial_number`, timeout and polling configuration remain writable after constructor validation (`controller.py:168–171`). Changing serial while connected made `get_status()` name 68000002 while `identify_device()` still returned 68000001 in the software probe. The normal `connect(other_serial)` path already refuses this change. | Separate requested selection from verified connected identity; make identity read-only and configuration immutable or revalidate changes while disconnected. This is defensive API hardening; the current GUI does not mutate the serial this way. |
| F06 / P2 | Errors and hub cleanup results are chiefly strings/exceptions; shutdown returns no structured per-slot evidence. Process-local ownership cannot exclude another Python process or vendor GUI. | Add small typed command/shutdown results with serial, attempted steps, reported closure, release, error and duration. Consider a Windows process ownership guard for package clients if unattended/multiple-client use is required; it cannot control third-party tools. |
| F07 / P2 | `tests/test_sdk.py:13–16` loads real DLLs and enumerates USB whenever an ambient environment variable is set. No checked-in CI workflow, license file or changelog was found. The declared Python range exceeds the one currently evidenced environment. | Make live tests explicitly opt-in even with that environment variable present. Separate DLL contract inspection from enumeration. Add software CI, clean-install checks, a tested compatibility matrix, release notes and an owner-selected license before external distribution. |
| F08 / P2 | Physical discovery, cache behavior, closure, USB loss and three-pair TTL remain blocked. Some interface wording still calls the shutter model unknown although SH05R is now human-reported. Stage-0 record completeness is deliberately not physical verification. | Reconcile documentation with evidence labels, reuse the existing bench record and execute only separately approved stages. Do not turn a filled form into permission to arm or a physical PASS. |

P1 means address before relying on unattended or fault-tolerant operation; it is
not a claim that a physical failure was observed. Existing shutdown is best
effort. Power loss, forced termination and hung SDK calls can defeat closure;
the optical-source protection and any finite-exposure guarantee must be provided
by independently qualified hardware/procedures.

## Target contract and architecture

Retain `KCubeShutter`, `ShutterHub`, `ShutterStatus` and `TriggerConfig`. Do not
reintroduce the removed public aliases. Extend only where a concrete contract
requires it:

- **Identity/configuration:** verified serial is stable for the handle lifetime;
  slot labels and desired settings are separate from observed state.
- **Command lifecycle:** accepted, executing, completed, rejected or failed;
  each command belongs to a connection generation and serial. A completed Close
  invalidates earlier queued requests to Open/Arm that have not executed.
- **State:** connection/retained handle, operating mode, priming, reported shutter
  position, safeguards, settings, fault and observation provenance are distinct.
  Unknown feedback must not be presented as Closed or a live electrical reading.
- **Shutdown:** report each attempted closure/release separately. Continue to
  the other slots after returned failures; document unbounded native-call cases.
  A successful release is not proof of physical closure.
- **Ownership:** one vendor owner per serial. Share snapshots with GUI consumers;
  do not let browser sessions become independent hardware owners.
- **Configuration:** use one small validated JSON/TOML profile only if repeatable
  bench setup needs it. Separate desired runtime configuration from dated bench
  evidence. Loading a profile must never auto-connect, apply or arm.

Start with the existing modules. Add an execution module only when responsive
command ownership warrants it; a transport abstraction only when implementing a
verified second transport. Logging, result types and validation do not justify
a collection of factories, registries or compatibility layers.

## Development sequence and exit gates

These milestones are proposals for later implementation. They do not advance
the separately gated hardware-test stages in [HARDWARE_VALIDATION.md](HARDWARE_VALIDATION.md).
Current stage implementation/review status belongs to [STATE.md](../STATE.md);
it may advance independently of this review snapshot. Keep its per-stage review
requirement and the hardware hold.

```mermaid
flowchart LR
    A[1. Command and shutdown hardening] --> B[2. Feedback and execution contract]
    B --> C[3. Approved bench acceptance]
    A --> D[4. Release engineering]
    C --> E[Qualified USB package]
    D --> E
    E --> F[5. Requirement-driven extensions]
```

### 1. Harden the existing behavior

Deliver focused changes for F01, F02 and F05 first. Specify duplicate/stale
commands and Close precedence before choosing the smallest implementation.
Avoid treating a client-local click count as a globally ordered command ID.
Add a compact per-slot shutdown result, preserving fault and interruption behavior.

Exit evidence:

- Regression reproductions fail before the fix and pass afterward: replayed
  Open/Arm after Close/Disarm; reconnect generation; independent three-slot state.
- Global shutdown starts without full status reads and still attempts all slots
  after returned closure/release failures and interruption.
- Status cannot name a different cube from its connected handle. Invalid config
  changes cannot bypass validated limits.
- Existing passive startup, TTL guards, ownership and cleanup regressions pass.

Suggested first commit order: shutdown pre-read removal and regression;
identity/configuration protection and regression; command ordering and replay
regressions. Keep each change reviewable; do not mix new modes into these fixes.

### 2. Establish feedback and responsive execution

Document installed-SDK request/reply, initialization, enable readiness and polling
semantics from authoritative contracts before assuming freshness. Decouple slow
TTL configuration reads from routine status where the contract permits; retain
explicit Read and verified Apply/Arm behavior.

Expand software devices with delayed, stale, missing and out-of-order responses,
shared-hub loss, reconnect and interrupted cleanup. Use deterministic event/time
control; do not make tests pass by increasing sleeps. Add diagnostics correlated
by command ID, connection generation and serial, with UTC event timestamps,
monotonic elapsed times and SDK/runtime identity. Preserve original exceptions.

Then implement owned execution and snapshot-driven GUI updates. Define whether
Close can cancel queued operations and how busy/fault/unknown states appear.
Validate the vendor's thread constraints. If a requirement demands responsiveness
during a stuck native call, evaluate process isolation with an explicit failure
model; terminating a worker is not a physical closure mechanism.

Exit evidence: stale software responses cannot establish a fresh completion;
unknown provenance stays unknown; delayed device A does not silently affect
device B's state; responsive UI and command ordering are demonstrated with
controlled blocking tests and browser interactions. Any native-call limit remains
explicit. Real freshness/latency still requires milestone 3.

### 3. Qualify on the actual bench, incrementally

Follow the existing stages, not a parallel new test system. Respect the pending
stage-review gate before implementing its successor. Implementation approval is
separate from authority to load the SDK, enumerate or actuate hardware.

Start with one real KSC101/SH05R through KEH3 USB. Establish installed identity,
SDK/firmware, passive access, Close, approved manual cycles, shutdown from Open
and recovery before multi-pair cases. Extend to all three installed pairs and
shared-hub faults; perform separately approved TRIG1/TRIG2 electrical/TTL cases.
If only one pair is available, only that subset can pass.

For each physical requirement record the configuration, procedure, actual result,
units, observation method/time resolution, serial and evidence artifact. Compare
controller reports with independent shutter observation. Measure command/feedback/
physical timings separately. Acceptances and safe dwell/duty limits must come
from applicable requirements/manuals and approved conditions, not guessed values.
Timing calibration is required only if the package promises calibrated timing;
ordinary successful motion does not establish it.

Exit evidence: physical REQ-003–008/023/031 pass for their actual configurations,
including GUI, TTL and cleanup/recovery cases; final integrated operation is
rechecked on the final software. Unmet cases stay BLOCKED/UNTESTED, not waived.

### 4. Make installation, integration and release reproducible

Run software-only CI independently of vendor DLL installation, including a guard
against ambient hardware-test activation. Test clean wheel/sdist installation,
entry points, passive import/help and packaged resources. Maintain the already
evidenced Windows x64/Python 3.12 path first; test Python 3.11/3.13 before claiming
them supported, or narrow the declared range.

Publish a compatibility table for Python, Python.NET, Dash, Windows architecture,
installed Kinesis version, firmware and tested topology. Keep vendor SDK binaries
external. Add release notes for public renames and the selected license before
external distribution. Choose the release version from the final API changes;
do not silently restore removed aliases. Separate a GUI dependency extra only if
headless consumers need it.

Keep beginner tutorials short. Add an integration guide for lifecycle ownership,
exceptions/results, TTL semantics, reconnect and cleanup limits, plus a bench
operator checklist and diagnostic bundle procedure. Link the same source of truth
instead of duplicating state tables. Build provenance should identify the exact
revision, dependencies and evidence scope.

Exit evidence: a fresh supported environment installs and passes software smoke
checks, documented commands work, API migration is explicit, and release claims
match tested matrices. An offline-qualified release may precede bench completion
only when clearly labeled as physically unvalidated.

### 5. Add features only for demonstrated use cases

| Candidate | Prerequisite and acceptance |
| --- | --- |
| Hardware timed/cycle modes | Verify KSC101-specific mode/parameter units, limits and readback; define interruption/TTL interactions; independently measure physical timing. Python sleep is not precise exposure control. |
| KEH3 Ethernet | Use the existing [assessment](ethernet-assessment.md); verify discovery/registration lifecycle, explicit endpoint, transport-aware health and serial ownership across transports. Bench-qualify separately. |
| Multi-client automation/service | A concrete consumer requirement; one hardware owner, command ordering, authentication/exposure scope and recovery. Keep local GUI deployment simple by default. |
| XA or other devices | Verified SDK/device/transport contract and a real second use case. Add a narrow adapter then; avoid a speculative plugin framework now. |

Installer packaging, remote access, automatic reconnection/rearming, new shutter
models and persistent device settings are not implied by this plan. Automatic
rearming in particular needs a new explicit operating contract.

## Review validation and limitations

At the review checkpoint, 279 offline tests passed, including Stage-0 preparation;
real SDK tests were explicitly excluded. The two exploratory reproductions used
only `tests/conftest.py` software devices and Flask's in-process test client.
No physical shutter state, electrical level or live retry was observed.

Production source was not changed. No hardware access, SDK load, build, firmware
change, publication or feature implementation was performed for this review.
Separately edited stage tooling in the shared checkout has its own evolving
validation; this review does not approve it or overwrite its checkpoint.
