# KSC101 1.0.7 update — procedure for review

**Execution supersedes draft (E050, 2026-10-20):** user subsequently authorized
newest KSC101 firmware and confirmed protection/reset conditions. Installed
official utility 1.14.76.28950 updated cube 68800777 to 1.0.7. USB readback
confirms serial repair. Production USB health still fails separately; Ethernet
has not been retested. See current STATE.md and post-update evidence.

**Correction to section C:** actual Flash Firmware immediately started
Bootloading, Erasing Memory and programming without a separate confirmation.
Treat it as programming, never as payload inspection. Installed utility selected
the image; resulting 1.0.7 verified afterward. No manual reset/power cycle was
required in this run. Remaining text preserves the original review draft.

Prepared 2026-10-20. **REVIEW ONLY — DO NOT INSTALL, FLASH OR RUN THESE BENCH
STEPS YET.** No update authority is implied by this document. Deliberate shutter
actuation remains held throughout, including after a successful update.

## Purpose and fixed configuration

Change only KSC101 device firmware **1.0.6 -> 1.0.7**. Keep KEH3 firmware
**1.1.2**, Kinesis/SDK **1.14.60.27990**, Python environment and controller source
unchanged during this comparison. Do not update the hub or install a newer SDK
as part of the experiment. The separate Firmware Update Utility is a tool, not
the KSC101 firmware version.

| Item | Known evidence / target |
| --- | --- |
| Cube | KSC101, USB descriptor/selected serial 68800777, hardware 3, firmware 1.0.6; printed label must still be checked. |
| Identity defect | Hardware-info serial 26000000 disagrees with USB descriptor 68800777 (E040). Keep the guard; never create a serial alias. |
| Hub / bay | KEH3 120100261, firmware 1.1.2; human confirms left bay. |
| Ethernet | Last verified 192.168.1.19:40303 hub; :40304 left, :40305 middle, :40306 right, :40307 USB OUT. DHCP address may change. |
| Existing failure | Hub answers identity; left bay accepts TCP but returns zero hardware-info bytes. SDK and Kinesis both find only the hub (E046/E047). |
| Expected benefit | Correct hardware-info serial after update. Ethernet improvement is a hypothesis to test, not a promised result. |

The [official controller firmware history][controller-history] lists KSC101
1.0.7 under utility release 1.14.62 (2025-07-24), fixing incorrect serial numbers
in hardware-info messages. The [hub history][hub-history] describes 1.1.2 as a
static-IP startup fix. Neither establishes an exact-pair compatibility matrix or
proves that this cube firmware explains the silent Ethernet bay.

## Review gates before scheduling an update

These are unresolved preparation requirements, not permission requests to run now.

1. Confirm the update and recovery method with Thorlabs for **KSC101 hardware 3**,
   including reliable target identification despite the 26000000 reply, support
   for the planned USB path and recovery after an interrupted flash. The support
   question is already drafted in [the evidence packet](../records/ethernet-support-case-2026-10-20.md).
2. Confirm the selected official utility contains/selects **KSC101 1.0.7 exactly**.
   Do not substitute another model, a generic binary, the KEH3 updater or an
   automatically selected newer cube version. No downgrade/image-export recovery
   has been demonstrated; do not promise rollback.
3. Record operator, observer, independent source disable/block, initial blade and
   displayed mode/output, key/interlock/trigger conditions, and exact physical
   recovery procedure. An update/reset can alter output/settings without an
   explicit Open command. Approval must cover the required resets and that risk.
   If absolutely no blade movement is permissible, obtain a manufacturer-approved
   isolation method before scheduling; do not improvise shutter disconnection.
4. Verify actual KEH supply and powered docking arrangement against the manual.
   Plan for stable power and a stable host/cable, with no intentional sleep,
   restart, cable removal or competing controller software during programming.
   Never hot-redock a cube or add a local cube supply while it is hub-powered.
5. Inspect the installed utility's help/workflow **without a controller attached**
   after separate installation approval. Confirm it cannot flash automatically
   on detection and identify its explicit programming action and completion/error
   indications. If this cannot be established, stop before attaching the target.

The official web page's README control did not expose a readable procedure in
this review. Updater UI/help, bootloader/recovery details and installed payload
have therefore **not** been verified. This draft is not ready-to-flash approval.

## A. Stage and verify the official package — later, after approval

The [official Firmware tab][firmware-page] currently offers the separate x64
Firmware Update Utility **1.14.76**, 14.3 MB, for motion devices other than
KEH3/KEH6. It links this [installer][utility-download] and publishes SHA-256:

```text
7856f76ad8911d2a29bf1ee097f77ba91f0c601fee190ec241c5366b04167c08
```

This is the **installer hash**, not a KSC101 image hash. No installer has been
downloaded, verified, installed or run for this procedure preparation. At execution
time download from the official page, preserve its URL/version/hash and verify
the actual file hash and a valid Thorlabs Authenticode signature before install:

```powershell
# Read-only checks of a future staged download; does not run the file.
$package = 'C:\repo\thorlabs-shutter-control\tmp\firmware-prep\thorlabs_firmwareupdateutility_setup_28950_x64.exe'
Get-FileHash -LiteralPath $package -Algorithm SHA256
Get-AuthenticodeSignature -LiteralPath $package |
    Select-Object Status, StatusMessage, SignerCertificate
```

Stop on mismatch/invalid or unexpected signer. If the official package changes,
review the new package and selected device payload rather than replacing the
expected hash blindly. Record image/version/hash if the utility exposes it; mark
unavailable image details unknown rather than inventing them.

## B. Baseline and owner/cable handoff — later

1. Save source revision/dirty controller hash, imported package path, SDK version,
   firmware/identity evidence E040/E046, settings screenshots/readback and actual
   cable/bay mapping. Settings export availability is unverified; screenshots and
   readback are evidence, not a restorable firmware backup. Do not export/apply a
   guessed configuration or restore settings automatically after the update.
2. Release the Kinesis hub connection and close Kinesis, our application/REPL and
   any other controller owner. Recheck actual ownership; the last session left
   the hub connected in Kinesis. Do not force-terminate a process as routine release.
3. With handles released, the operator prepares the manufacturer-approved USB
   update route. Preferred proposed route retains the cube in the left KEH3 bay
   and connects computer -> KEH3 USB IN; **utility support for this route must be
   confirmed first**. LAN may remain cabled; USB IN disables Ethernet operation.
   No simultaneous direct cube USB fallback. If Thorlabs requires direct USB or
   changed docking/power, review that physical procedure before any change.
4. Capture one passive USB baseline if needed on the unchanged source. Discovery
   should enumerate 68800777. The existing Connect guard may reproduce the known
   26000000 mismatch; record expected FAIL and passive release. Do not weaken the
   guard or use Close/Enable as a diagnostic. No repeated attempts are required
   merely to reproduce evidence already captured on this configuration.
5. Close/release the baseline reader before opening the updater with the target.
   Its USB descriptor, printed label, model, hardware revision and only intended
   target must agree. If it offers only 26000000 or ambiguous/multiple devices,
   stop for Thorlabs' identification procedure; do not guess that it is the cube.

## C. Programming hold point — not authorized

After all review gates have evidence, prepare a screenshot of the actual utility
showing target KSC101/verified identity, current 1.0.6 and selected 1.0.7. Confirm
the selected action affects only that cube and is the documented vendor workflow.
Obtain explicit execution approval **before the utility's programming action**;
this document supplies no flash command or guessed bootloader sequence.

After that later approval, the designated operator follows the verified vendor
programming sequence once. Keep power/cabling and ownership unchanged until the
utility reports completion or a documented recovery instruction applies. Capture
the actual progress/completion/error log; a launched updater is not completion.
Perform only the reboot/reset that the verified procedure requires. Do not infer
a time limit or invent power-cycle/button-hold instructions.

On failure, stalled progress or lost identity: preserve logs and utility state,
maintain independent protection, and follow Thorlabs' recovery instructions.
No blind retry, forced power cycle, downgrade or repeated flash. Do not open our
driver or Kinesis concurrently. Firmware 1.0.7 must be read back after update;
the utility's success message alone is insufficient.

## D. Passive USB verification after a successful update

Close/release the updater. Keep the approved USB route and independent protection;
do not open the actuation tutorial, GUI control buttons, a context manager,
default disconnect or safe_shutdown (these can attempt Close).

Construct and retain one controller in the repository Python REPL:

```python
from thorlabs_shutter_control import KCubeShutter, ShutterError

c = KCubeShutter("68800777")
```

Execute the following block once. It uses the existing vendor getter only to
record firmware, since the public identity result does not expose that field.
The private handle access is confined to this reviewed diagnostic.

```python
operation_error = None
try:
    initial = c.connect()
    identity = c.identify_device()
    firmware = str(c._device.GetDeviceInfo().FirmwareVersion)
    status = c.get_status()
    print("Identity:", identity, "Firmware:", firmware)
    print("Initial:", initial, "Readback:", status)
    if firmware != "1.0.7" or identity["serial_number"] != "68800777":
        raise ShutterError("Target firmware/identity not verified")
    for sample in (initial, status):
        if (
            sample.connection != "connected"
            or sample.serial_number != "68800777"
            or sample.shutter_state not in ("open", "closed")
            or sample.operating_state not in ("active", "inactive")
            or sample.operating_mode not in ("manual", "single", "auto", "triggered")
            or type(sample.key_enabled) is not bool
            or type(sample.interlock_enabled) is not bool
            or sample.trigger_config is None
        ):
            raise ShutterError(sample.error or "Incomplete operating feedback")
    fields = ("shutter_state", "operating_state", "operating_mode",
              "key_enabled", "interlock_enabled", "trigger_config")
    if any(getattr(initial, f) != getattr(status, f) for f in fields):
        raise ShutterError("Feedback changed during passive cycle; review before repeating")
except BaseException as exc:
    operation_error = exc
    raise
finally:
    try:
        c.disconnect(close_shutter=False)
    except BaseException as cleanup_error:
        if operation_error is None:
            raise
        operation_error.add_note(f"Passive release also failed: {cleanup_error!r}")
        if not isinstance(cleanup_error, Exception):
            raise cleanup_error from operation_error
```

Record USB descriptor and hardware-info serial agreement, 1.0.7 readback, known
status/settings, initial/final independent physical observation and successful
release. Feedback is cached vendor data, not independent position or freshness
proof. Compare settings with baseline; any difference requires review, not an
automatic write-back. Numeric operating state 0 remains an error.

After each passing cycle, review observation and release before the next. Three
separately invoked cycles on the same retained object satisfy only the matching
passive lifecycle subcase of TEST-003/005. Stop after any error, unexpected motion
or unknown state; do not loop automatically. Resolve a retained handle before a
different process/transport. None of these results qualifies deliberate motion.

## E. Passive Ethernet verification — after USB passes/review

1. Release/exit USB readers first. Operator disconnects only KEH3 USB IN; keep
   LAN/power/docking/shutter wiring unchanged and no direct cube-to-PC USB cable.
   Confirm the hub's actual IP if DHCP changed; do not write a new IP.
2. In Kinesis discover the known hub IP. Expected: hub 120100261 at :40303 **and
   KSC101 68800777 at :40304**. Capture the list and provider/endpoint. If only
   the hub appears, record Ethernet FAIL/BLOCKED; stop without another flash.
   Do not confuse hub connection with cube communication or an open TCP port
   with a device identity. Do not touch Open/Close/Enable/Identify/settings.
3. Release Kinesis before the Python check. Construct the explicit endpoint
   controller below, then run exactly the same passive block from section D:

```python
c = KCubeShutter("68800777", ethernet_endpoint="192.168.1.19:40304")
```

   Use the reverified IP if different. Discovery must match TCPIP plus exact
   endpoint; USB/another bay fallback is refused. Require matching identity,
   firmware 1.0.7, known unchanged readback and passive release. Review each cycle
   before repeating on that object. Do not use default disconnect for cleanup.
4. Save independent initial/final observations. No trigger, key/interlock,
   mode/output or cycle parameter is changed. Any post-update settings change
   remains for review; do not arm or restore it automatically.
5. Finish with all readers released, final observed/reported state recorded and
   actuation still held. Physical Ethernet cable-loss/recovery qualification,
   Stage 3/4, TTL, GUI actuation and multi-cube operation are separate later gates.

## Results and decision

Use TEST-003/005 for passive acceptance with a USB/Ethernet subcase label. Assign
new E records to execution; E048/TEST-058 validates this procedure only.

| Subcase | Required observation | If it fails |
| --- | --- | --- |
| Programming | Vendor completion plus independent 1.0.7 readback on correct KSC101 | No claimed update PASS; follow vendor recovery, not blind retries. |
| USB identity | Descriptor, label and hardware-info identity all 68800777 | Preserve failure; no alias, motion or Ethernet acceptance. |
| USB passive lifecycle | Known stable feedback, settings comparison, independent observation, release; three reviewed cycles | Stop and diagnose; incomplete/unknown is not PASS. |
| Ethernet discovery | Both correct identities; cube TCPIP :40304, USB absent | Hub-only remains unresolved even if USB serial fix passes. |
| Ethernet passive lifecycle | Verified firmware/identity/readback and release; reviewed cycles | Keep Ethernet BLOCKED, preserve successful USB evidence separately. |

If USB serial reporting is corrected but Ethernet stays silent, the firmware fix
addressed the identity defect without resolving the hub path. If both pass after
only this controlled firmware change, that supports the firmware hypothesis for
this bench; it does not establish universal compatibility or a motion qualification.
Record all changed conditions before drawing causality conclusions.

Update STATE.md, records/RECORDS.md and outputs/REPORT.md with time, operator,
source/package hashes, exact versions, transport/cable map, settings, errors and
independent observations. Any changed software/configuration invalidates affected
prior validation. The current state remains **PROCEDURE PREPARED — AWAITING REVIEW;
UPDATE AND ACTUATION ON HOLD**.

[firmware-page]: https://www.thorlabs.com/software-pages/Motion_Control?tabName=Firmware
[controller-history]: https://thin01mstroc282prod.dxcloud.episerver.net/contentassets/2bdee65af856455cbce44da76a448078/history_1_14_76.txt?v=1020054006
[hub-history]: https://thin01mstroc282prod.dxcloud.episerver.net/contentassets/792378ef5d8c4f418981142766231303/revision_history.txt?v=1116040826
[utility-download]: https://media.thorlabs.com/contentassets/2bdee65af856455cbce44da76a448078/thorlabs_firmwareupdateutility_setup_28950_x64.exe?v=1020054138

Additional setup reference: [KEH3 manual, §§3.3.5, 4.2–4.3](https://media.thorlabscms.cn/globalassets/items/k/ke/keh/keh3/doc-103012.pdf?v=0129060351).
