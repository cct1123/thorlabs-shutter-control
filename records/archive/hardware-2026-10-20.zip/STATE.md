# Engineering state

## Current UX checkpoint - E078 / TEST-087, 2026-10-20

REQ-052 (derived, PROJECT.md actual user experience request): PASS for focused
GUI/CSS changes, software behavior, browser interaction and actual USB readback.
No human supervision requested. One actual browser Open ->2.015s added visible
hold ->Close, discovery, empty-slot error, passive trigger read, keyboard collapse,
release/reconnect, reload and global shutdown all verified. No new independent
blade observation or calibrated physical timing. No TTL Apply/Arm or firmware.

New GUI: prominent reported state/Close, connected count/badges, inline feedback,
error styling, disabled-Open explanations, collapsed trigger settings, delayed
busy cue and aria-busy. Connected reload no longer gives a misleading Connect
instruction. Driver/CLI hashes unchanged from E077;440 offline tests PASS; Ruff
checks/format PASS. Copy/aria-only final changes were passively revalidated without
repeating motion; command/guard paths unchanged.

Final GUI intentionally running at http://127.0.0.1:8050/, terminal session8424,
normal production CLI --serial 68800777 --verified-interlock 68800777. Current
Connected68800777, Closed/Inactive/Manual, keyenabled, SDK interlockunknown with
operator confirmation; other slots Disconnected. One GUI-owned handle retained,
no automatic sequence/pending test. Prior UX test server exited and released.
A selector wait anomaly was checked by fresh AX rather than repeating Connect;
actual final connection is healthy. Outer PTY exit1 remains recorded separately
from test server application main0, matching prior terminal behavior.

Evidence: records/gui-ux-summary-2026-10-20.json links raw hardware/browser trace,
source hashes, layout geometry and screenshots. At912x956 viewport, Open/Close
are fully visible,46px high, no horizontal overflow. Final screenshot:
records/gui-ux-final-2026-10-20.png. Earlier E077 session53364 is superseded by8424.

Current user request finished. GUI available for operator; broader physical,
three-pair, TTL, fault and Ethernet acceptance remains separate. Stage7 removed.
Human action required for this request: none.

## Historical E077 checkpoint â€” 2026-10-20, E077 / TEST-086

Current request complete for software and electronic hardware scope: Stage5/6
implemented and exercised on actual USB68800777. Administrative GUI/hardware
holds removed by explicit user instruction. Source block/normal physical interlock
retained from user confirmation. No human prompts or new physical observations.
Broad project physical acceptance is PARTIAL, not COMPLETE.

## Configuration and ownership

Computer USB -> KEH3 left bay -> KSC10168800777 -> SH05R. Firmware1.0.7/hardware3;
Kinesis1.14.60.27990, Python3.12.7 x64/pythonnet3.1. No COM assignment. Ethernet
hub120100261 was reachable at192.168.1.19:40303; cube Ethernet remains unresolved,
not part of this USB run. Do not infer current LAN/cable state from old evidence.

Production driver uses raw interlock bit0x1000 positive or unknown when clear.
No jack-continuity bit established. Explicit selected-serial/object session
confirm_interlock permits readiness from recorded human physical verification;
GUI says unknown(operatorverified), raw bits preserved. No hardware interlock
write. Retarget clears confirmation; another object/process needs its own.
Key/identity/comms/known-negative checks remain. Startup is passive.

Stage5: Closed shutdown/reconnect/Open2s->safe_shutdown all READBACK_PASS, no handle.
Stage6: actual GUI Open2s/Close, refresh/no replay, release/reconnect and one normal
terminal Ctrl+C-from-Open READBACK_PASS. Cleanup captured Closed/Inactive/Manual,
all handles released, application main0; outer PTY exit1 noted without guessing
its cause. Fresh passive post-exit identity/Closed/Inactive/Manual/release PASS.
437 offline tests PASS; Ruff check/format PASS. Host waits/call durations are not
calibrated physical blade timing. No newly observed blade transitions; E075's
human-confirmed five-cycle sequence remains historical physical evidence.

Intentional GUI handoff: localhost8050, normal production CLI session53364 with
--serial68800777 --verified-interlock68800777 (actual arguments separated by
spaces). No automatic sequence/retry. Final passive Connect/browser check PASS: Connected, Closed/Inactive/Manual,
key enabled, interlock unknown(operatorverified), Open enabled; other slots
Disconnected. GUI intentionally owns one handle; prior test owners released.
Screenshot records/gui-enabled-usb-2026-10-20.png; handoff JSON records owner.
This is an idle user GUI, not a pending test operation.

## Evidence and next action

records/stage5-stage6-summary-2026-10-20.json links raw runs and final dirty source
hashes/configuration. records/current-hardware-tests.json is current stage status.
records/RECORDS.md E076/E077 holds durable decision/test evidence. Earlier state
is preserved in records/state-history-before-stage5-6-2026-10-20.md; historical
holds and human-action requests there are superseded, not active constraints.

Current request finished; GUI remains available for operator. Later Stage8 fault injection,
three-pair Stage9, TTL Stage10, independent shutdown observation and Ethernet cube
qualification remain unexecuted scope. Stage7 is removed. Do not fabricate PASS
or start additional actuation merely to make the broader project COMPLETE.

## Human action required

None for the authorized Stage5/6/GUI request. No test loop or physical intervention
pending. Independent physical timing/optical measurements remain unperformed;
this is an acceptance limitation, not an administrative hold.

## Requirements

Sources/full criteria: PROJECT.md. Stable IDs preserved; electronic, physical,
software and historical scope remain distinct. Earlier unchanged software criteria
retain scoped evidence; no fresh packaging/publication claim made.

| ID | Short criterion | Validation / evidence | Status |
| --- | --- | --- | --- |
| REQ-044 | Firmware update procedure preparation | E048 / TEST-058, update later completed E050 | PASS (preparation) |
| REQ-043 | Resolve KSC101 through KEH3 Ethernet with minimal code and passive tests (derived, latest PROJECT.md request) | TEST-055 / E045 software path PASS; TEST-056 / E046 hub PASS, confirmed left cube bay silent; human vendor-GUI comparison also hub only | BLOCKED (physical communication) |
| REQ-042 | Revise actual-hardware acceptance procedure (derived, latest PROJECT.md request) | TEST-054 / E044; current evidence reconciliation, snippet compilation and 8 software-device cases | PASS (plan only) |
| REQ-041 | Minimal controller hardware-handling revision (derived, latest PROJECT.md request) | TEST-053 / E043; 346 offline tests and scoped lint/format; actual SDK/bench revalidation pending | PASS (software only) |
| REQ-040 | Holistic review and comprehensive package development plan (derived, latest review request in PROJECT.md) | TEST-045 / E035; source/docs review, two software reproductions, 279-test baseline and prioritized roadmap | PASS (review/planning only) |
| REQ-001 | Python, uv, packaging and lock | TEST-001/025; locked setup, build/package checks, E024 | PASS |
| REQ-002 | Reusable controller, separate GUI | TEST-002/022Ã¢â‚¬â€œ024; current software tests, E024 | PASS |
| REQ-003 | USB discovery/identity/connect/reconnect | E050/E053/E077 / TEST-086, serial68800777 | PASS (single USB pair; Ethernet separate) |
| REQ-004 | Physical opening/closure | E075 / TEST-084 five cycles, human confirmed; E077 production readbacks | PASS (requested single-pair sequence) |
| REQ-005 | Feedback vs physical state | E075 human sequence agrees; E077 electronic only | PARTIAL (new shutdown observation/timing absent) |
| REQ-006 | Physical error handling/recovery | TEST-006; real USB/hub/device loss pending | BLOCKED |
| REQ-007 | Physical safe shutdown | E077 / TEST-086 Close/readback/release PASS | PARTIAL (independent closure timing unmeasured) |
| REQ-008 | GUI on hardware | E077 / TEST-086 actual USB callbacks/browser and Ctrl+C cleanup | PASS (single-pair electronic scope) |
| REQ-009 | Setup/troubleshooting documentation | TEST-009/025; updated guides and references, E026 | PASS |
| REQ-010 | Accurate API/architecture/integration/simulation | TEST-010/025; examples/demo/review, E026 | PASS |
| REQ-011 | Actual simulated screenshot, editable diagrams | Historical E016/E023 screenshots; unchanged GUI/diagrams, TEST-035 E024 | PASS |
| REQ-012 | Reproducible documentation workflow | TEST-012/025; demo, references, E026 | PASS |
| REQ-013 | Honest prior documentation delivery | TEST-013; historical scoped E007/E008 | PASS |
| REQ-014 | Focused prior simplification (derived) | TEST-014; historical scoped E009 | PASS |
| REQ-015 | Validate current package (derived) | TEST-015/025; software suite/build, E024 supersedes E009 for changed source | PASS |
| REQ-016 | Explain architecture and retained complexity (derived) | TEST-016/025; current report E024, historical E009 | PASS |
| REQ-017 | Simple hardware-focused visual README (derived) | TEST-018/020/025; updated README E024, diagram E014 | PASS |
| REQ-018 | Multiple-controller/KEH3 compatibility review (derived) | TEST-021; source assessment E015 only | PASS |
| REQ-019 | Three independent GUI panels (derived) | TEST-022; distinct fake devices, HTTP/browser lifecycle, E024 | PASS (software) |
| REQ-020 | Exclusive ownership and cleanup all slots (derived) | TEST-023; duplicate/race/failure/interrupt tests, E024 | PASS (software) |
| REQ-021 | Passive startup and explicit selection | TEST-024 / E077; holds removed by user, default startup still passive | PASS (software and one-pair GUI) |
| REQ-022 | Reproducible package and operating docs (derived) | TEST-025; tests/lint/build/examples/visual review, E026 | PASS (software) |
| REQ-023 | Three KSC101s through actual KEH3 USB (derived physical scope) | TEST-026 / physical TEST-003Ã¢â‚¬â€œ008; prepared procedure stage 9 | BLOCKED |
| REQ-024 | Rename driver, merge hub module and prune (derived) | TEST-027; 99 tests, package, docs and layout parity, E017 | PASS (software) |
| REQ-025 | Rename ShutterHub, centralize construction and prune (derived) | TEST-029; 107 source/package tests, examples and layout parity, E019 | PASS (software) |
| REQ-026 | Simplify GUI construction, preserve independent controls (derived) | TEST-030 historical E020; current TEST-035 regression E024 | PASS (software) |
| REQ-027 | Assess KEH3 Ethernet SDK support and changes (derived) | TEST-032; official documentation/static SDK/source review, E022 | PASS (research only) |
| REQ-028 | TTL configuration/readback and explicit arm/disarm (derived) | TEST-033; static official contract, distinct software devices, E024 | PASS (software) |
| REQ-029 | Independent TTL GUI controls and draft/readback separation (derived) | TEST-033; HTTP/browser checks, E024 | PASS (software) |
| REQ-030 | TTL shutdown and package regression (derived) | TEST-033; failure/interrupt/all-slot tests and wheel, E024 | PASS (software) |
| REQ-031 | Physical TTL configuration/priming/disarm across three shutters (derived) | TEST-034; stage 10, no SDK/physical execution | BLOCKED |
| REQ-032 | Consistency review, focused fixes and pruning (derived) | TEST-035; 211 source/wheel tests, E024 | PASS (software) |
| REQ-033 | Commit and push reviewed changes | TEST-036; implementation 2bce513 pushed and remote verified, E025 | PASS |
| REQ-034 | Five beginner hardware-only tutorial scripts (derived) | TEST-037; five hardware scripts/guide, 243 source/wheel tests, E026 | PASS (software) |
| REQ-035 | Reviewed staged hardware plan (derived, final-plan request in PROJECT.md) | TEST-038; source/procedure review, syntax and six software-device cases, E028 | PASS (documentation only) |
| REQ-036 | Staged implementation with scoped authority | E075/E077; latest user permits autonomous Stage5/6; Stage7 removed | IN PROGRESS (later stages unexecuted) |
| REQ-045 | Newest compatible KSC101 firmware | E050 / TEST-060,1.0.7 and identity repaired | PASS |
| REQ-046 | Implement Stage3/4 | E051 / TEST-062; latest437-test regression | PASS (software) |
| REQ-047 | USB health correction | E053 / TEST-064 and E077 actual USB | PASS |
| REQ-048 | Holistic command/manual interpretation review | E070 / TEST-079; raw interlock remains unknown | PASS (review/correction) |
| REQ-049 | Remove Stage7 | E072 / TEST-081, user scope change | PASS (removed, not tested) |
| REQ-050 | Implement/test Stage5/6 autonomously (derived, PROJECT.md) | E076/E077 / TEST-085/086;437 offline tests, actual USB shutdown/GUI/Ctrl+C | PASS (electronic scope; physical criteria REQ-007 separate) |
| REQ-051 | Enable GUI/hardware; remove holds (derived, PROJECT.md request) | E076/E077; session serial-specific confirmation, live flags/GUI tested | PASS |
| REQ-052 | Actual GUI/hardware user experience and focused GUI design (derived, latest PROJECT.md request) | E078 / TEST-087;440 software tests, real browser actions and USB readback, final layout/reload proof | PASS (electronic/browser scope) |
