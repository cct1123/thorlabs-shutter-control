# Engineering records

Durable evidence and decisions. Software doubles, SDK enumeration, and physical
observations have distinct scopes. Each record identifies its scope; subsequent
documentation evidence is appended below. No physical shutter operation has
been observed or claimed.

## E001

Kind / scope: official documentation and SDK inspection; TEST-002, REQ-002/005.
Sources: [interface notes](../docs/INTERFACE.md) link the official KSC101 Python/C#
examples, manufacturer manual and Kinesis download page. Python example source
revision: `d85b2014d12018028c3eba1f724f42e94d3c47bf`.

Method: inspect examples without executing their device-control code; extract/read
the manual and visually inspect its specification/interlock pages. Download the
official x64 Kinesis 1.14.60 package; verify its published SHA-256 and Authenticode
signature; extract an MSI administrative image into the workspace. Load its
DeviceManagerCLI/GenericMotorCLI/KCube.SolenoidCLI assemblies via Python.NET;
reflect the actual properties, method names and enum values. Compare state meanings
with the vendor KSC101 C header included in the SDK.

Expected: authentic vendor package and real KSC101 API members supporting the
required class boundary. Observed: SHA-256
`298c4cc03a6c3b4d5c174964ae9193d13baca63dab10c1595b4e9ad5d914ff05` matched;
signature valid, signer Thorlabs, Inc. SolenoidCLI file/product version
`1.14.60.27990`. .NET Framework and all selected assemblies loaded.
GetSolenoidState is distinct from GetOperatingState; enum values and health/
key properties match [test_sdk.py](../tests/test_sdk.py). Native header documents
the interlock bit 0x1000. PASS for source/API selection and reflection scope.

Local, ignored sources: `tmp/references/`, `tmp/pdfs/`, `tmp/kinesis-sdk/`.
The initial extraction-only switch produced no usable image; documented MSI
administrative extraction succeeded (log ACTION=ADMIN, return 0). No system Kinesis
driver installation or firmware modification performed. CHM extraction produced no
usable HTML; API conclusions are based on actual assembly reflection, vendor
header and official examples, not inferred CHM contents.

Limitations: loading/reflection does not validate hardware commands, exact polling
freshness, or physical feedback. The manual contains legacy APT software material;
current Kinesis APIs were taken from the SDK/examples.

## E002

Kind / scope: environment/USB inventory and real SDK discovery; TEST-003, REQ-003.
Method: inspect usual Kinesis folders; inspect connected PnP device descriptions;
execute `DeviceManagerCLI.BuildDeviceList()` and `GetDeviceList(68)`, also through
`uv run --locked shutter-control --list --kinesis-dir "tmp/kinesis-sdk/Program Files 64/Thorlabs/Kinesis"`.
Use `--cache-dir .uv-cache` on this sandbox.

Observed: only Thorlabs OPM in the usual program folders; no standard Kinesis
installation found. Connected PnP inventory had no device identified as KSC101/
Thorlabs. WMI OS query was denied, so it was not used as hardware evidence.
The real SDK returned `[]`; CLI displayed `No KSC101 devices discovered.`
with exit code 0 (enumeration completed, not a hardware PASS).

Result: BLOCKED for required physical discovery/connection. No controller serial,
shutter model or power arrangement was discovered. USB-driver readiness is
unverified; empty enumeration alone does not distinguish unavailable hardware
from connection/power/driver problems. No Connect or output command reached hardware.
Bearing: B001 in STATE.md; REQ-003..008 require operator/hardware access.

## E003

Kind / scope: software tests and packaging; TEST-001..008 (software scope only).
Configuration: Windows x64, uv 0.11.2, CPython 3.12.14, Dash 4.4.1, Plotly 7.0.0,
Python.NET 3.1.0, pytest 9.1.1; official Kinesis x64 1.14.60.27990 for the opt-in
SDK check. [validation-manifest.json](validation-manifest.json) fingerprints the
tested source/configuration and final build outputs.

Method / expected:

- `uv lock --check`, `uv sync --locked --offline`: lock consistent; environment reproducible.
- `uv run --locked ruff check src tests`, `ruff format --check src tests`: no findings.
- Set KINESIS_TEST_DIR to the extracted SDK and run
  `uv run --locked pytest -q -p no:cacheprovider`: all tests pass without physical actuation.
- `uv build --offline`: build sdist/wheel; inspect wheel for controller, GUI, CLI,
  CSS and absence of vendor DLLs/test files.

Observed: locked/offline sync passed with 39 resolved packages; lint clean, formatter
left files unchanged. Final test run: **43 passed in 0.57 s**, exit 0. Final
sdist/wheel built successfully; package contents verified. An earlier pytest cache
warning was an environment permission issue; use of the cache provider was disabled
for final validation and its failed generated cache directory was removed.

Tests demonstrate input/selection validation; no output writes during connect;
partial-connect cleanup; 20 repeated open/close cycles in a software double;
manual-mode ordering; safeguard refusal; missing-feedback timeout and recovery-close
attempt; fault latching and unknown state, including connection loss during sampling;
release even after close/polling errors or interrupted close; retained handle on
disconnect failure; context-manager error preservation; CLI shutdown on server
failure; Dash lifecycle callbacks and no command replay on refresh. The optional
test loads actual DLLs/checks SDK members and enumerates, without connecting.

Result: PASS for REQ-001 and software architecture portion REQ-002. Physical
REQ-003..008 remain BLOCKED. Software-double transitions are not observations of
the real shutter. Kinesis's own USB/cache timeout behavior remains to be measured.

## E004

Kind / scope: real-browser GUI inspection with real SDK, no device; TEST-008.
Method: run the local Dash server with the extracted SDK on 127.0.0.1:8050,
inspect rendered page, click Discover, click Connect, and inspect feedback.
Review the final compact CSS layout after reload.

Expected: passive initial state, no unintended output commands, actionable
no-device error and disabled Open/Close. Observed: Disconnected, unknown identity/
state/key/interlock; Discover showed `Found 0 device(s).`; Connect showed
`Expected one KSC101; found 0. Connect a device or explicitly select its serial number.`
Open and Close stayed disabled. Page/callback/asset requests returned HTTP 200;
layout reviewed visually. PASS for this no-device browser scope.

Server stopped after verification; no controller handle had been opened. Stopping
this no-device server is not evidence of physical shutdown behavior. Successful
connected GUI lifecycle was exercised through HTTP callbacks with a software double
in E003; its physical counterpart remains blocked.

## D001

Decision: accept the user's 2026-09-09 autonomous launch as superseding the original
initialization-only pause. Updated PROJECT.md's current scope accordingly.
Basis: explicit user instruction to begin and continue the engineering loop.
Consequence: research, reversible local implementation and software checks proceed;
physical actions remain bounded by the actual setup and AGENTS.md. Requirements
and firmware/interlock restrictions unchanged.

## D002

Decision: use a single public Python controller around official Kinesis .NET via
Python.NET; Dash only orchestrates that public interface.
Basis: E001 and the user's supported-interface/minimal-structure constraints.
Consequence: Windows/Kinesis runtime required for hardware; vendor binaries are
external prerequisites. One SDK version per process, one owner per device.
Reconsider if official KSC101 interface support or the host platform changes.

## D003

Decision: connect without explicit output/mode commands; explicit Open/Close use
Manual mode; default disconnect attempts close before release and reports failures.
Never represent a successful setter as independent physical verification.
Basis: user requirements, manufacturer mode/state semantics (E001), failure-path
software checks (E003). Recovery must preserve an unknown state after a fault.
Consequence: close on context exit/Ctrl+C is best-effort; default disconnect changes
output. A deliberate communication-only disconnect is available. Browser closure,
forced termination and USB loss do not guarantee closure. Physical acceptance
must verify the documented policy before the project can be COMPLETE.

## E005

Kind / scope: hardware-readiness source audit and reproduced defect; 2026-09-09.
Reviewed PROJECT, AGENTS, STATE, engineering records, controller/real SDK boundary,
test double, GUI/CLI/assets, all tests, packaging/lock and documentation. Read local
official Python example, KSC101 native header and manual text; no SDK load, USB
inventory, discovery, connection or actuation was performed during this audit.

Baseline: 42 software tests passed in 0.17 s with tests/test_sdk.py explicitly
excluded. E003's 43 included one real-SDK enumeration test; that result is historical,
not rerun evidence. E004's rendered-browser zero-device result is also historical.

Finding: Open preparation required only Manual feedback before EnableDevice/Active,
so it proceeded even when the preceding Inactive command still reported Active or
Open. Two software regressions injected those independent disagreements: both
FAILED before the fix (DID NOT RAISE), reproducing false successful preparation.
The single production change requires Closed AND Inactive AND Manual before
EnableDevice/Active. It retains the existing timeout/recovery-close/fault behavior.
Both regressions and the full software suite now PASS. No API, GUI, dependency or
backend abstraction was added. E003 alone no longer validates the changed code;
E006 supplies current software evidence. Physical feedback freshness remains unknown.

Procedure defect: TEST-003's initial disconnect used the default Close policy.
Replaced it with explicit disconnect(close_shutter=False) for communication-only
checks; documented exact first vendor calls, first Close before Open, normal
shutdown before GUI/repeated cycles, and closed-state USB fault injection last.
All potential actuation and observation gates are identified. Clarified that no
explicit persistence call does not prove a mode change is nonpersistent: the
manufacturer manual describes remembering the last mode across power cycles.
The ordered procedure was reviewed against actual public methods and shutdown paths.

## E006

Kind / scope: current software/packaging acceptance; TEST-001..008 software scope.
Configuration: Windows x64, CPython 3.12.14, uv 0.11.2; locked 39-package environment
including Dash 4.4.1, Plotly 7.0.0, Python.NET 3.1.0, pytest 9.1.1, ruff 0.16.6.
Application source/build/document fingerprints: [readiness manifest](hardware-readiness-manifest.json).
Base Git revision: bdcb48fffd8a579edc83a2cadf91eed5256a385f plus the audited changes.

Commands run from repository root with
`C:\Users\ctcheung\.local\bin\uv.exe --cache-dir .uv-cache`:

1. Unset KINESIS_TEST_DIR. `run --locked --offline pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py`:
   **44 passed** after fix (0.19 s).
2. Set UV_PROJECT_ENVIRONMENT=tmp/audit-venv and run `sync --locked --offline --python
   C:\Users\ctcheung\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`:
   created a fresh environment, installed all 39 locked packages. Repeat software
   test command: **44 passed in 0.43 s**.
3. `run --locked --offline ruff check src tests`: PASS;
   `run --locked --offline ruff format --check src tests`: 9 files already formatted.
   `run --locked --offline shutter-control --help`: PASS without SDK loading.
4. `build --offline --out-dir tmp/audit-dist`: sdist and wheel built successfully.
5. `pip install --offline --python tmp/audit-venv/Scripts/python.exe --no-deps
   --reinstall tmp/audit-dist/thorlabs_shutter_control-0.1.0-py3-none-any.whl`:
   replaced editable install with wheel. Using that environment's Python directly,
   `-m pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py`: **44 passed in 0.17 s**.
   Installed CLI --help and `pip check --python tmp/audit-venv/Scripts/python.exe`: PASS.
6. Verified import path is the audit environment's site-packages, wheel contains
   CSS and no vendor DLL/executable, and passive Flask page/layout/CSS routes return
   200. Asserted _loaded_sdk is None and clr/pythonnet/Thorlabs modules absent.

Meaningful simulated coverage: discovery/selection and no-device handling, passive
connection, partial-connect cleanup, 20 cycles, safeguard refusal, incomplete
preparation, missing feedback, communication faults and unknown-state latching,
shutdown failure/retry/interruption, original-exception preservation, CLI cleanup,
real Dash HTTP callback lifecycle/error handling and no replay on refresh.
The fake applies normal updates immediately; it does not model USB timing, vendor
cache age, drivers, electrical interlocks or mechanics. No claim of real-time or
physical acceptance is made. The real SDK opt-in test was excluded, not counted
as a current PASS. Final documentation-only package rebuilds preserve tested code.

Reproducibility boundary: runtime/dev dependencies are locked and a fresh cached
install was demonstrated on Python 3.12 x64. Other allowed Python versions are
not validated. Fresh uncached hosts require package/Python downloads and a separate
supported vendor runtime/driver installation. Hatchling's allowed build dependency
range is not a claim of byte-identical builds on every host; artifact hashes record
the actual builds. Neither vendor binaries nor drivers are supplied by uv.lock.

## D004

Decision: user-requested review supersedes autonomous hardware continuation.
After E005/E006, record HARDWARE_READY, then AWAITING_HUMAN_REVIEW; retain BLOCKED
for physical REQ-003..008. These explicit user-requested readiness states refine
the template workflow; neither means COMPLETE or grants physical authority.
PROJECT.md's current scope records the same user instruction. No hardware
communication, actuation, firmware changes or safeguard bypass occurred in this audit.
Resume only after human approval using docs/HARDWARE_VALIDATION.md from stage 0.
Unknown bench facts remain unknown until discovered or supplied. Preserve E001–E004
as historical evidence; use the new manifest for the current reviewed candidate.

## D005

Decision / scope: documentation-only follow-up to the user's
[request in prompt log.txt](../prompt%20log.txt), REQ-009–013. Preserve the production controller,
GUI, CSS, tests, dependency configuration and hardware-review hold. No device access,
hardware validation or architectural change is authorized by this request.

Inspection found no production simulator or separate backend class: the real
Kinesis implementation is inside controller.py, and simulation is the pytest rig
in tests/conftest.py. Document this existing structure rather than inventing
`--simulate`, `open()`/`close()` aliases or a pluggable backend interface.
Add only a source-checkout documentation helper under docs/examples that reuses
the existing fixture for the API walkthrough and actual GUI screenshots. It
replaces the SDK loader before use and restores it after cleanup; it is not an
installed command or public backend. This is documentation-enabling support,
not production feature work. No concrete production defect was found in the
documented workflows.

Keep the detailed hardware procedure's sequence/gates and historical readiness
evidence intact. Replace its machine-specific working-directory/uv path with a
repository-root instruction and PATH lookup; this changes no device operation.
The readiness manifest still identifies the unchanged code/test/configuration
candidate; its older document/build hashes are historical after this pass.
Do not interpret documentation completion as physical project completion.

## E007

Kind / scope: documentation, software-only examples, GUI browser captures,
Markdown/diagram checks and packaging on 2026-09-09/10 UTC. TEST-009–013,
REQ-009–013; software evidence also supports unchanged REQ-001/002.
No real SDK loading, USB enumeration, device communication or actuation occurred.

Expected results: current commands/examples match implementation, the actual GUI
renders the documented simulated states, internal links/assets resolve, Mermaid
renders, packaging succeeds, and production/test/configuration fingerprints remain
unchanged. Physical REQ-003–008 are excluded, not counted as PASS.

Observed software validation:

- Fresh `tmp/docs-venv` environment: `uv sync --locked --offline` installed all
  39 locked packages with CPython 3.12.14 x64 and uv 0.11.2. In this sandbox, set
  `UV_CACHE_DIR` to `.uv-cache`, `UV_PROJECT_ENVIRONMENT` to `tmp/docs-venv`, and
  `UV_PYTHON` to the existing bundled Python 3.12 executable. The initial offline
  attempt without that interpreter reference could not discover Python 3.12;
  explicitly selecting the installed interpreter resolved it. This is a fresh
  environment equivalent, not a new system Python/uv installation.
- `uv run --locked pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py`:
  **44 passed in 0.46 s**. The SDK test was explicitly excluded regardless of
  environment. `ruff check src tests docs/examples` and
  `ruff format --check src tests docs/examples`: PASS, 10 Python files.
- `uv run --locked shutter-control --help`: PASS. Documented hardware CLI flags
  match argparse; actual `--list`/Connect/actuation were not run on hardware.
  Git HTTPS clone URL matches the configured origin; remote cloning and the
  documented uv installer command were not executed. Fresh-clone network/access
  conditions and vendor-driver installation are not established by this pass.
- `uv run --locked python docs/examples/simulated_demo.py --api`: PASS; fictional
  identity `68000001`, Closed → Open → Closed → Disconnected. All four Python
  example blocks in README.md / docs/python-api.md executed against the existing
  fixture. Integration callback return and exception paths both closed the fake.
  `_loaded_sdk` remained None; no clr/pythonnet/Thorlabs modules were loaded.
  Detailed temporary result: `tmp/docs-example-results.json`.
- All 13 source/test/configuration fingerprints covered by this review match
  the prior readiness manifest, including source CSS, tests, pyproject.toml,
  uv.lock and .python-version. User-maintained prompt log.txt was not edited.
- `uv build --offline --out-dir tmp/docs-dist`: wheel and source distribution
  PASS. Installed the wheel with `uv pip install --offline --python
  tmp/docs-venv/Scripts/python.exe --no-deps --reinstall` and its wheel path;
  `uv pip check --python tmp/docs-venv/Scripts/python.exe` and installed CLI help
  PASS. Verified import from site-packages, passive GUI page/layout/CSS HTTP 200,
  current README in package metadata, CSS in wheel, no demo/test/vendor binaries
  in wheel, and demo plus all four screenshots in sdist. No vendor modules loaded.
  Detailed temporary result: `tmp/docs-package-results.json`.

Observed GUI/visual validation:

- Ran the actual `create_app`/callbacks/CSS with the documentation fixture helper.
  Microsoft Edge 152.0.4191.66, Playwright, viewport 820 × 850 px, scale 1.
  Captured fresh disconnected, connected/Closed, Open, and empty-discovery error
  states. Normal browser lifecycle ended with Close & disconnect; the error case
  remained disconnected with Open disabled. No browser JavaScript errors in the
  normal lifecycle. Screenshots were inspected visually without pixel editing.
- [Asset provenance and reproduction steps](../docs/gui.md#screenshot-provenance) identify
  every screenshot as simulation. Fictional identity and test-double description
  are visible in connected captures. No private desktop material, real device
  serials or vendor photographs were included. Missing bench photos are documented.
- Browser/server sandbox restrictions initially prevented localhost binding and
  headless process launch. Scoped automatic escalation allowed the fixture-only
  server and temporary-profile browser; no hardware fallback was used.
- Markdown/diagram tools were installed only in ignored `tmp/docs-tools` with
  scripts disabled, without changing project dependencies. Markdownlint-cli2
  0.23.2 uses an ignored config permitting HTML img elements and long lines/tables
  (MD013/MD060 disabled). Seven user-facing Markdown pages checked. An underscore
  in a CLI link label was corrected. Mermaid blocks rendered in an isolated
  local-content browser; diagram labels were shortened after visual inspection.
  Final link/render result: `tmp/docs-render-results.json`.
- Final user-page render: seven pages, 77 internal references, five Mermaid
  diagrams, zero missing references/images and zero browser JavaScript errors.
  Broader checkpoint/report/reference-document links are checked again with the
  final manifest present. Both screenshot servers were stopped after verifying
  their process command lines; the normal simulated device had already been
  closed/disconnected. No pending device/process operation remains.

Command verification distinguishes executed software commands from source-checked
hardware/installer/remote-clone commands. Official uv instructions and Python.NET
runtime guidance were checked online. The vendor download page was reachable but
provided no readable text; the linked manual could not be refetched by the web
reader, so its existing local extraction and E001 were used to verify the quoted
hardware context. No new vendor version/compatibility claim is made.

Final outcomes, artifact hashes and check counts are captured in the
[documentation manifest](documentation-manifest.json). New documentation status
and limitations are summarized in [the report](../outputs/REPORT.md#documentation-pass).
These results do not change the blocked physical acceptance criteria.

## E008

Kind / scope: user-requested review, pruning and publication of the documentation
with `prompt log.txt`. TEST-009–013, REQ-009–013; no device access. Expected result:
concise, accurate guides with valid links/builds and unchanged production behavior.

Review found repeated simulation, status and shutdown explanations, plus a full
request archive already present verbatim in the prompt log. Removed that duplicate
and linked the original log; shortened README, architecture/hardware/setup text,
asset notes and the report: 2,730 words removed, including the 2,137-word duplicate
request. Kept all examples, screenshots, diagrams, public API
details and hardware-validation gates. No production defect was identified.

The user explicitly authorized committing the prompt log with these changes and
pushing. Its content was preserved; Git applies the repository's LF normalization.
Fetched origin and confirmed main had no divergence before preparing the commit.
Markdownlint reports zero issues; all 110 internal references resolve, and four
Python documentation blocks pass against the fixture, including acquisition
failure cleanup. Final builds/installed-wheel checks and file hashes are in
[the manifest](documentation-manifest.json).
E007's screenshots, example execution and 44-test results remain applicable to
unchanged source/tests/demo. Publication is identified by Git history/origin/main;
physical acceptance remains blocked under the existing review hold.

## D006

Kind / scope: active user-requested aggressive simplification, superseding only
PROJECT.md's prior documentation-only implementation restriction. Hardware hold
and all acceptance criteria remain. REQ-014–016 derive from that request.

Retain four production modules: exports, hardware controller, Dash UI and CLI.
Each has a current API/runtime boundary. Reuse Close during Open preparation and
replace generic predicate waits with one concrete state wait. Preserve the vendor
call order, full feedback/safeguard gates, fault latching, locks and cleanup.
Exception type is unchanged; timeout messages now name the full expected state,
and Open preparation errors can include the nested Close failure.

Remove duplicate workflow documentation, merge screenshot provenance into its
GUI guide, use Dash's package-local asset default, and prune unused fixture state
and a custom server fake. Keep used public wrappers, vendor isolation, dependency
lock/build configuration, all important tests and historical evidence. No new
framework, production abstraction or dependency was introduced. The only adjusted
historical record link points to the relocated screenshot provenance.

## E009

Kind / scope: software cleanup on 2026-09-10 UTC, base commit `1984b17`.
REQ-001/002, REQ-009/010/012 and derived REQ-014–016; TEST-014–016, with affected
TEST-001/002 and TEST-009/010/012 rechecked. Physical REQ-003–008 remain BLOCKED.
No real SDK load, USB enumeration, device communication or actuation is authorized.

Expected: preserve public signatures and command/safety/cleanup behavior, remove
redundancy, pass all software tests and documented examples, and build/install the
package with functional passive GUI/CSS. Real-SDK enumeration is explicitly excluded.

Observed:

- Baseline: 44 software cases PASS (0.23 s), Ruff lint/format PASS. After collapsing
  Close and feedback waits, the same 44 cases PASS (0.18 s). Ruff identified one
  line wrap, corrected with its formatter before subsequent checks.
- Added five parameter cases for preparation-mode and post-Active operating-state,
  mode, key and interlock disagreement. All 49 cases PASS after fixture/GUI pruning
  (0.22 s), retaining every existing behavior/regression case.
- Fresh `tmp/cleanup-venv`: `uv --cache-dir .uv-cache sync --locked --offline`, with
  `UV_PROJECT_ENVIRONMENT=tmp/cleanup-venv` and `UV_PYTHON` pointing to the existing
  bundled CPython 3.12.14 x64. uv 0.11.2 installed all 39 locked packages. This
  validates a fresh environment from cache, not a fresh network/OS installation.
- Fresh environment: `python -m pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py`
  PASS, 49 cases (1.02 s); `ruff check src tests docs/examples` and
  `ruff format --check src tests docs/examples` PASS, 10 files. CLI `--help` PASS;
  `uv pip check --python tmp/cleanup-venv/Scripts/python.exe` PASS, 39 packages.
- All four README/API Python blocks PASS using the patched fixture, including
  acquisition success/failure cleanup; no clr/pythonnet/Thorlabs module loaded.
  Demo `--api` returned 0 with Closed → Open → Closed → Disconnected; `--api --empty`
  returned the expected 1 with the missing-device diagnostic. One-off verification
  source: `tmp/cleanup-examples.py`; it excludes obsolete unchanged-source assertions.

- `uv --cache-dir .uv-cache build --offline --out-dir tmp/cleanup-dist`: sdist and
  wheel PASS. Installed with `uv pip install --offline --python
  tmp/cleanup-venv/Scripts/python.exe --no-deps --reinstall` plus the wheel path.
  All 49 software cases PASS against site-packages (0.21 s). Passive GUI, layout
  and CSS return HTTP 200; initial callback remains enabled; no vendor modules load.
  Wheel includes CSS/current README and excludes tests/demo/vendor binaries; sdist
  includes the demo/screenshots and excludes the two deleted documents. Check source:
  `tmp/cleanup-package.py`. Builds use the configured Hatchling range, not a claim
  of byte-identical artifacts across build-tool versions.
- Markdownlint-cli2 0.23.2: 11 maintained Markdown files, zero issues using the
  existing ignored `tmp/docs-lint.json` (long lines/tables and HTML images allowed).
  A pre-existing bare URL in the hardware procedure was converted to a link; its
  ordered steps/limits are unchanged. `tmp/cleanup-docs.cjs` checked internal links
  and rendered six user pages/five Mermaid diagrams: zero missing references/images
  or browser errors. The simplified architecture was visually reviewed. Headless
  Edge initially hit sandbox EPERM; scoped automatic escalation permitted the
  temporary local-only browser check. Browser closed normally; no server was needed.
- Public method signatures checked with AST comparison against HEAD; package
  exports, CLI, CSS, pyproject.toml, uv.lock and .python-version are byte-identical
  to baseline. User-maintained prompt log.txt matches its pre-cleanup SHA256.
  No static type checker is configured; none was added for this refactor.
- Final pruning reviewed every remaining module, helper, configuration and dependency.
  39 -> 37 tracked files; production Python 637 -> 616 lines (3.3% reduction).
  Test Python 534 -> 547 lines for five additional safety cases. No public API or
  dependency removed; no permanent verification framework/manifest introduced.

Changed production SHA256 (other production/configuration files match base 1984b17):

- `controller.py`: `7761daa9f3dc383384e58bc3f990b3a19f7eb78e101708e05b3cb944cd594baf`
- `gui.py`: `a52e176194de1e7d17a445f9ade1942440633c886f73835a656843919c0bc775`

TEST-014–016 PASS; affected software/documentation requirements revalidated.
Cleanup is COMPLETE. Physical REQ-003–008 remain BLOCKED under the review hold.
Historical manifests still identify their original candidates. No hardware operation,
server or browser remains pending; no commit or push was requested/performed.

## E010

Kind / scope: user-requested review, fixes, commit and push of the cleanup,
2026-09-10 UTC. TEST-017: prepublication review of REQ-014–016 and current software
validation, followed by Git publication verification. Hardware hold unchanged.

Reviewed the full pending diff, including the shared Close path, all feedback gates,
fault/recovery behavior, Dash defaults, revised tests and documentation removals.
No production defect found. Corrected stale checkpoint statements referring only
to baseline tests and saying publication had not been requested. Production/test
files remain the candidate validated in E009; its source fingerprints still apply.

Current source suite: `python -m pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py`
PASS, 49 cases (0.20 s). Ruff lint/format PASS for all 10 Python files; `git diff
--check` PASS. Internal references resolve; E009's package/example/diagram checks
remain applicable. No real SDK load or device access occurred.

Fetched origin and confirmed HEAD/origin/main had no divergence before publication.
The reviewed commit includes the related user-maintained prompt-log additions;
their content is preserved, with Git's configured LF normalization in the index.
The active user request authorizes commit and push to the existing origin/main.
Git history and the matching origin/main revision identify the publication result.

## E011

Kind / scope: first-time-user README rewrite, 2026-09-15; base `b40ec49`.
Derived REQ-017 from the current user request; TEST-018 rechecks affected
REQ-009–012. Documentation only; the hardware-review hold is unchanged.

Expected: a concise Install → Test → Demo → Hardware → Safe use guide, with
repository-backed commands, interfaces and validation claims; usable existing
screenshot, valid diagram/links, and no SDK/USB access.

Observed:

- Inspected controller, GUI, CLI, packaging/lock, fixture/demo, hardware procedure,
  current checkpoint and E009/E010. Reused the existing simulated GUI screenshot
  after visual inspection; its provenance remains in docs/gui.md.
- `uv sync --locked` PASS: 39 packages checked. This shell lacked uv on PATH;
  prepended the existing `C:\Users\ctcheung\.local\bin` for verification and used
  project-local `UV_CACHE_DIR=.uv-cache`. uv 0.11.2, CPython 3.12.14 x64.
- Documented software pytest command PASS: 49 cases in 0.23 s. Real-SDK test
  explicitly excluded. Normal API demo PASS with documented states; empty API
  demo returned the expected missing-device message and exit 1. CLI help PASS.
- README Python block executed against the patched fixture and cleanup verified;
  three additional API-guide blocks also PASS using `tmp/cleanup-examples.py`.
  No clr, pythonnet or Thorlabs module loaded.
- Documented Ruff lint/format commands PASS (10 files). `uv build` could not reach
  PyPI for Hatchling in this environment; `uv build --offline` PASS from the existing
  cache, producing wheel and sdist. A fresh network install was not demonstrated.
- Clone URL matches the configured GitHub repository; cloning was not repeated.
  Real-hardware commands were checked against source and tests, not run on devices.

- Markdownlint-cli2 0.23.2 PASS for README; local Markdown/image/anchor checks
  PASS. The README rendered with its screenshot and one Mermaid diagram without
  broken images or browser errors; rendered top section and diagram visually
  reviewed. Sandbox browser launch initially returned EPERM; scoped automatic
  escalation permitted the local-only render. Browser closed normally.
- Exact Quick Start demo launch started the server at 127.0.0.1:8050. HTTP layout
  and CSS returned 200; real Dash callback requests exercised initial state,
  Discover, Connect, Open, Close and Close & disconnect with the documented identity
  and states, all PASS (`tmp/readme-demo-check.py`). After verified Disconnected,
  Ctrl+C stopped the terminal session (wrapper exit 1); this is not a physical
  shutdown validation. Existing screenshot assets were preserved.

TEST-018 PASS; REQ-017 and affected documentation REQ-009–012 revalidated.
The README task is COMPLETE. Physical REQ-003–008 remain BLOCKED. No hardware
operation is authorized or performed. No server or browser remains pending.

## E012

Kind / scope: same-day user follow-up, "more focus on using with real hardware".
TEST-018 revalidates revised REQ-017 and affected documentation REQ-009–012.
Expected: hardware setup/operation is the main README path, simulation optional;
retain accurate validation limits and the existing hardware hold.

Observed:

- README now leads with Windows/Kinesis installation and software checks, bench
  topology/checklist, discovery, actual serial selection, GUI connection,
  Close/Open/Close observations and shutdown. Troubleshooting prioritizes hardware.
  The simulated screenshot is explicitly labeled; no hardware imagery or bench
  configuration was invented. The simulator is an optional later section.
- Reviewed CLI flags, environment-variable use, serial selection and GUI workflow
  against source, hardware notes and the ordered procedure. Discovery remains
  gated by approval; the GUI follows first-use stages 2–5. No procedure stages,
  physical limits or acceptance criteria changed; no device access occurred.
- Revised Python example uses the selected serial and prompts for Closed/Open
  observations. It makes no timing guarantee and explicitly leaves approved
  dwell/thermal limits to the operator. `tmp/readme-hardware-example-check.py`
  executed the actual README block against the fixture: normal completion and
  KeyboardInterrupt at the second prompt both leave the fake Closed/released.
  No clr/pythonnet/Thorlabs modules loaded. This is software-only evidence.
- Markdownlint and internal Markdown/image/anchor checks PASS. Local browser render
  PASS: one Mermaid diagram, no missing images or browser errors; top section
  visually reviewed. Existing screenshot/diagram assets retained. Browser closed.
- E011's source tests, software demo, dependency and Ruff checks remain applicable;
  production code/configuration is unchanged. Hardware commands are documented and
  source-checked, not physically executed. No redundant full-suite run or build.

TEST-018 PASS for the revised guide. Documentation COMPLETE; physical REQ-003–008
remain BLOCKED under AWAITING_HUMAN_REVIEW. No hardware/server operation pending.

## E013

Kind / scope: user-requested review, fixes, commit and push, 2026-09-15.
TEST-019: prepublication review of the README change and REQ-009–012/017;
TEST-018 example/reference checks rerun. Hardware-review hold unchanged.

Reviewed all five changed documentation files against controller/CLI/GUI source,
packaging, existing guides and E011/E012. Corrected four first-use gaps: specify
Python 3.12 x64, show the eight-digit serial format beginning with 68, stop on
failed software checks, and explicitly Close & disconnect/stop the GUI before
running the Python example. Updated the stale publication checkpoint. No
production, test, configuration, dependency or hardware-procedure changes.

Validation:

- `uv run --locked pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py`:
  49 PASS (0.18 s). No real-SDK test or device operation executed.
- Actual README Python block: normal completion and interruption after Open PASS
  against the fixture, ending Closed/released; no vendor modules loaded.
- Ruff lint/format PASS, all 10 Python files. Cached wheel/sdist build PASS.
- Fixed a pre-existing missing blank line before the E003 list. PowerShell
  command blocks parse; Markdown lint, internal references and
  `git diff --check` PASS. E012's diagram/screenshot rendering remains applicable;
  only small text clarifications were made during this review.
- Fetched origin; HEAD and origin/main both at b40ec49 with zero divergence before
  publication. Only the five reviewed documentation files are in scope.

TEST-019 PASS. The current user request explicitly authorizes commit/push to the
existing origin/main. Git history and remote refs identify publication; no force
push or hardware access is part of this action. Physical REQ-003–008 remain BLOCKED.

## E014

Kind / scope: user-reported GitHub diagram failure, 2026-09-15. TEST-020;
REQ-011/017. User observed "Unable to render rich display" and an undefined
`render` property. This invalidated the README's viewer-compatibility conclusion
from local Mermaid rendering; the exact GitHub/client runtime cause is unconfirmed.

Expected: the README diagram displays without a viewer-side Mermaid dependency,
with the same hardware topology and accessible editable source.

Changed README to embed `docs/assets/hardware-connections.png` and link
`hardware-connections.mmd`. The source matches the prior README Mermaid block
exactly. Exported with local Mermaid 11.17.2 and headless Edge at scale 2:
2080 x 692 px, 44,400 bytes, white background. Reviewed the labels and connections;
used opaque label backgrounds to avoid lines crossing text. Export helper is
`tmp/export-hardware-diagram.cjs`; the committed .mmd is the source of truth.

Validation: source equality and absence of a README Mermaid fence PASS; local
README render with JavaScript disabled PASS, both images load, no broken images
or browser errors. Markdown lint, local links and whitespace checks PASS. Test
helper: `tmp/readme-static-review.cjs`. No source/configuration change, SDK load,
USB access or hardware actuation; prior software tests remain applicable.

TEST-020 PASS for the static display path. The reported GitHub renderer was not
repaired or diagnosed; the README no longer invokes it. Other guides' Mermaid
blocks are outside this reported README issue. Existing authorization to fix,
commit and push this documentation covers publication to origin/main. Physical
acceptance remains BLOCKED under AWAITING_HUMAN_REVIEW.

Post-publication check: commit `5ef79a1` was pushed to origin/main. A fresh headless
browser opened that commit's GitHub README (HTTP 200); the visible diagram decoded
successfully at 2080 x 692 px. Screenshot: `tmp/github-readme-diagram.png`;
check: `tmp/check-published-readme.cjs`. GitHub display PASS for the static image.
The browser closed normally. This supplements the local script-free rendering check.

## E015

Kind / scope: compatibility review, 2026-10-20; REQ-018 (derived from user
request to review multiple shutter cube controllers with KEH3), TEST-021.
Expected: distinguish hardware hub suitability, serial selection, simultaneous
control, Ethernet support, and demonstrated versus inferred compatibility.

Observed from source:
- controller.py discover() enumerates type 68; connect() requires an explicit
  serial when discovery is ambiguous and creates a serial-addressed handle.
- Per-instance device, fault and lock state permit separate Python objects in
  principle. No duplicate-serial ownership registry exists; BuildDeviceList uses
  per-instance locking only. Cross-instance SDK behavior is not validated.
- gui.py create_app(controller) and CLI main() own one controller. GUI serial
  selection/discovery is disabled while a handle exists. No multi-shutter panel,
  coordinated commands or aggregate shutdown exists.
- _check_connection() requires USBConnected == Connected. No Ethernet discovery,
  address configuration or hub initialization is implemented. Ethernet support
  cannot be inferred from the hub offering Ethernet.
- tests/test_controller.py tests ambiguous enumeration/explicit selection, but
  tests/conftest.py returns the same FakeDevice for every requested serial.
  This does not demonstrate independent concurrent device operation.

Vendor references consulted:
https://www.thorlabs.us/newgrouppage9.cfm?objectgroup_ID=16708
Thorlabs describes KEH3/KEH6 as Ethernet and USB hubs for up to three/six cubes.
https://www.thorlabs.com/catalogpages/Obsolete/2025/SC10.pdf
Historical KSC101 product documentation describes multi-cube USB hub operation
using KCH301/KCH601; it is not direct KEH3 acceptance evidence. Search-indexed
vendor content was accessible; several direct current product fetches failed.

Conclusion: KEH3 USB operation with multiple KSC101s is plausible, conditional
on actual SDK enumeration and bench validation. Existing UI selects one device
at a time. Multiple independent objects/processes require distinct serial
ownership and validation; synchronized operation is not established. Ethernet
is unverified, not claimed incompatible at vendor level.

Validation attempt: uv run --locked pytest -q -p no:cacheprovider
--ignore=tests/test_sdk.py failed before collection due to default cache access.
Retry with --cache-dir tmp/uv-review-cache and --offline created .venv but
could not resolve cached ruff==0.16.6. No tests executed or passed in this review.
No SDK loading, USB/device communication or actuation. Production code unchanged.
TEST-021 PASS for documented source assessment only; physical REQ-003-008 remain
BLOCKED. Further hardware work requires the existing staged approval.

## D007

2026-10-20; REQ-019–023. The user explicitly authorized three KSC101 shutters
through KEH3 USB in one GUI and explicitly kept hardware access on hold.

Keep one driver per serial and add a small ShutterBank for fixed GUI slots,
shared discovery and aggregate cleanup. Retain the existing single-controller
API. Guard serial ownership inside this process, including partial initialization
and failed release; serialize shared SDK enumeration/creation. Do not create a
new transport, dependency, background worker or cross-process ownership service.

Use explicit selection in multi-device slots, independent status/faults and
individual controls. Bank shutdown is sequential, attempts all slots after
reported errors/interrupts, and preserves diagnostics. It cannot bound hung
vendor calls or prove physical closure. Global success text does not claim
closure for disconnected or previously faulted slots. Keep the operator's
single-process ownership responsibility and existing physical safeguards.

Interpret KEH3 USB as the intended hub carrying separately addressed KSC101
identities. Do not claim Ethernet, synchronization or physical USB compatibility
from source or simulated tests. Stage 9 of the hardware procedure prepares
combined acceptance without authorizing execution.

## E016

Kind / scope: three-shutter implementation and software validation, 2026-10-20;
REQ-001/002/009–012/015–017/019–022; TEST-022–025. Human source: PROJECT.md,
Three-shutter KEH3 USB follow-up. REQ-023 / TEST-026 and physical TEST-003–008
remain BLOCKED under the user's explicit hardware hold.

Expected results before testing:
- TEST-022: three distinct fake USB identities connect without output writes;
  each panel's commands/state/faults are independent, and refresh never replays
  old button counts. A lost retained identity remains visible until cleanup.
- TEST-023: duplicate serial claims, including concurrent initialization, are
  refused; failed release retains ownership. All-slot cleanup attempts later
  slots after errors/interrupts, aggregates slot/serial failures and re-raises
  interruption after remaining attempts. A failed closure never becomes verified
  merely because its handle was released or cleanup was retried.
- TEST-024: default GUI/CLI provides three passive slots; up to three distinct
  serial arguments preselect only. Invalid/duplicate/excess arguments fail before
  SDK/server access. CLI server failure/Ctrl+C still performs all-slot cleanup.
- TEST-025: locked environment, distributable module/CSS, software examples,
  lint/format, user guides and actual simulated browser layout remain usable.

Implemented: bank.py and package export, process-wide serial registry/shared SDK
locks, three-panel GUI and all-shutdown button, repeated CLI --serial, independent
fake device mapping, three-device demo, focused tests and updated documentation.
PROJECT.md records the authorized scope; STATE.md and outputs/REPORT.md describe
the current result. No dependency/lockfile changes.

Observed validation:
- `uv sync --locked`: PASS; 39 locked packages installed after approved cache/
  dependency access. Environment: Windows x64, CPython 3.12.7 (Anaconda build),
  Dash 4.4.1, Python.NET 3.1.0, pytest 9.1.1, Ruff 0.16.6.
- `.venv\Scripts\python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: 98 PASS in 0.35 s on final source.
- `.venv\Scripts\python.exe -m ruff check src tests docs/examples`: PASS.
  `ruff format --check src tests docs/examples`: all 12 Python files formatted.
- `uv --cache-dir tmp/uv-review-cache pip check`: 39 packages compatible.
- `uv build`: final source distribution and wheel PASS. Extracted that wheel to
  tmp/wheel-validation and put it first on sys.path; verified imports came from
  the extracted package. Passive three-panel layout/HTTP 200 and packaged CSS
  smoke check PASS with SDK loading replaced by a forbidden-operation function.
  A fresh interpreter ran the full software suite from that package: 98 PASS
  in 0.34 s. No vendor-boundary test ran.
- `.venv\Scripts\python.exe docs/examples/simulated_demo.py --api`: PASS;
  discovered distinct fictional 68000001/2/3, read each identity, Open/Close,
  then all three Disconnected. The documented bank example also ran under the
  patched rig and ended with all three Closed/released.
- Actual local browser at http://127.0.0.1:8059 used only the patched simulator.
  Connected all three, opened Shutter 2: rendered Closed/Open/Closed. Global
  cleanup returned all three Disconnected and disabled Open/Close. Screenshot:
  docs/assets/gui-three-simulated.png, 452 x 2237 px, responsive stacked layout,
  all identities explicitly TEST DOUBLE, NOT HARDWARE. Browser tab and simulator
  were closed after cleanup; no server/device handle remains pending.
- Documentation Python blocks parse; local referenced paths resolve; Markdown
  fences and `git diff --check` PASS. Historical single-panel screenshots are
  labeled as such. The deferred hardware procedure includes three-cube mapping,
  independent operation/reconnect and combined cleanup/shared USB cases.

Validation harness issues, resolved without changing product behavior: the
initial CLI/GUI tests still assumed a single object/callback signature and were
adapted to the three-slot interface. The full tests exposed missing-selection
auto-connect; bank selection now explicitly rejects None. A review caught a
false global closure claim for no-handle cleanup; text and regression tests now
preserve unverified state. An extraction using tempfile.mkdtemp hit Windows
permissions; a normal workspace directory worked. The first wheel test harness
left its forbidden SDK patch installed, causing the missing-SDK-message test to
fail; a fresh interpreter passed all 98 packaged tests. Prior cache-permission
and missing-offline-dependency failures from E015 were resolved by locked sync.

Reproducibility hashes/configuration: records/three-shutter-validation.json.
TEST-022–025 PASS within software-only scope. No real Kinesis assembly loading,
USB enumeration, device connection/actuation, calibration or firmware writes.
Actual KEH3 USB and physical criteria remain BLOCKED; follow B001 in STATE.md
before any future bench work. No commit or push was requested or performed.

## D008

2026-10-20; REQ-024, user-directed rename/module consolidation and pruning.
`KCubeShutter` replaces the public `KSC101Controller` name with no compatibility
alias. Move ShutterBank into controller.py and remove bank.py; keep its class and
behavior. Update current imports/guides/examples, preserving historical evidence.

Use the atomic driver serial registry as the sole ownership authority. Remove
the redundant bank scan that read another device's status to reject duplicate
assignment; it could perform unnecessary SDK I/O and latch an unrelated fault.
Keep slot/selection validation, driver and bank locks, retained ownership after
failed release, per-device safeguards/faults and all-slot cleanup/interrupt logic.
Reuse existing fake handles, simplify CLI padding and share repeated readout
markup. Do not add operation dispatch abstractions or widen hardware authority.

## E017

Kind / scope: KCubeShutter rename and simplification, 2026-10-20. REQ-024 /
TEST-027 and affected software TEST-022–025; supersedes E016 for changed source.
Physical TEST-003–008/026 remain BLOCKED under the unchanged hardware hold.

Expected: public imports use KCubeShutter; ShutterBank shares controller.py;
bank.py and the old class alias are absent. Retain independent controls, passive
startup, atomic serial ownership, latched faults and all-shutter cleanup despite
failures/interrupts. Reduce redundant implementation without altering GUI layout.

Changed: all current source/tests/demo and API examples use KCubeShutter; package
exports both driver and bank from controller.py. Removed bank module/imports and
its duplicate ownership scan. Reused rig.devices in the independent-device test
fixture; factored repeated GUI readouts without changing output structure;
shortened CLI serial padding. Current documentation/source maps/checkpoint/report
were reconciled. Historical E records/manifests retain their original names.

Measured against the working-tree implementation at the start of this request:
production Python 5 -> 4 modules and 839 -> 802 lines (37 lines removed). Driver
and bank are separate classes in one module. Dependencies/lockfile, CSS, controls,
timeouts, hardware command sequence and supported CLI flags are unchanged.

Validation / observed results:
- `.venv\Scripts\python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: 99 PASS in 0.43 s. New regression proves duplicate
  assignment does not read/fault the current owner's status; existing race,
  retained-claim, independent-state and error/interrupt cleanup cases still pass.
- Ruff check PASS; format --check PASS, 11 Python files. Dependency compatibility:
  39 packages compatible. `git diff --check` PASS.
- `uv build`: source distribution/wheel PASS. Checked both omit bank.py. Extracted
  wheel to tmp/wheel-refactor-validation; verified imports resolve there, both
  KCubeShutter/ShutterBank come from controller.py, and no old class export exists.
  Passive three-panel HTTP/layout/CSS smoke PASS with the SDK loader forbidden.
  Full software suite against packaged code: 99 PASS in 0.42 s; one benign Dash
  assertion-rewrite warning because the smoke check imported it before pytest.
- Compared both default three-panel and injected one-panel /_dash-layout JSON
  against E016's extracted package in separate Python processes: identical.
  The healthy GUI screenshot therefore remains representative; no new browser
  or hardware session was needed for this structural cleanup.
- Simulated demo --api PASS for three distinct fictional serials: identity,
  Open/Close and all Disconnected after cleanup. Renamed README single-device,
  API single-device and API bank examples executed under the patched rig; all
  fake shutters ended Closed/released. Documentation Python blocks parse,
  local links resolve and Markdown fences balance.
- Static search: no old class name, bank module imports or bank.py references in
  active src/tests/docs/README. Historical records and PROJECT's quoted human
  rename request intentionally retain the old name. A final rebuild captures
  updated report/evidence references; package source is checked against final src.

Environment remains Windows x64 / CPython 3.12.7 with unchanged uv.lock versions.
TEST-027 PASS in software-only scope. No real SDK loading, USB/device discovery,
connection, actuation or firmware write; no server/handle pending. No commit/push.
Final source/configuration/artifact hashes: records/controller-cleanup-validation.json.

## E018

Kind / scope: current manufacturer-documentation verification, 2026-10-20;
REQ-009/010/018/023, TEST-028. User supplied the official product-page URL:
https://www.thorlabs.com/k-cube-r-solenoid-controller?tabName=Overview

Expected: determine whether the current KSC101 product documentation explicitly
supports the requested three-controller KEH3 USB topology and whether it changes
our software-interface assumptions. Do not infer physical acceptance or authority.

Observed: direct web fetch failed; the actual page loaded in the in-app browser
as 'Thorlabs · K-Cube Solenoid Controller'. Overview / Power Supply Options and
Compatible Power Supplies explicitly list KEH3 for up to three K-/T-Cubes and
KEH6 for up to six. They describe a USB 2.0 hub circuit, power/communications,
single power connection, and combined cube load not exceeding 4.6 A. The KSC101
is described as a 15 V solenoid controller suited to SH05R(/M), with interlock/key
safeguards. Overview/product details explicitly advertise USB control using
Kinesis or XA, superseding the reference notes' prior lack of a KSC101 XA claim.

Conclusion: manufacturer documentation now directly confirms KSC101/KEH3 USB
compatibility as a supported topology, strengthening E015's indirect evidence.
It does not establish this bench's supply/load, installed SDK/driver behavior,
three-serial enumeration/mapping, physical state/feedback or closure. Ethernet
and XA backends remain unimplemented/unvalidated here; keep the established
Kinesis API and safeguards. No source or configuration change is required by
this reference alone.

Updated docs/INTERFACE.md, docs/hardware.md, STATE.md and outputs/REPORT.md with
these distinctions and the current source. TEST-028 PASS for documentation
verification only. Physical TEST-003–008/026 and REQ-023 remain BLOCKED. Prior
99-test software evidence E017 remains applicable to unchanged code. No new
software tests/build were needed for reference-only text updates. Local links,
Markdown fences and whitespace checked. No SDK, USB/device operations, actuation
or authority change; hardware access remains on hold.

## D009

2026-10-20; REQ-025. User requested ShutterBank -> ShutterHub, simpler
construction and removal of unnecessary controller scaffolding. Rename without
an alias. Give the hub one normal construction path from serial preselection;
retain a keyword-only controllers injection path for existing integrations/tests.
Centralize count/duplicate checks and padding; do not add factories, backend
classes, generic command wrappers, or timing/configuration passthrough layers.

Controller review retained the small lazy SDK boundary, per-instance/shared
locks, strong serial-owner claims (including the claimed serial), fault snapshots,
verified command waits and cleanup/interrupt logic. Each enforces real behavior:
removing these would weaken ownership, safeguards, recovery or all-shutter cleanup.
Remove duplicate CLI setup and the unused single-controller demo/count wrapper.
Consolidate slot validation but keep missing-selection rejection and retained
fault/handle behavior. No hardware authority or physical acceptance change.

## E019

Kind / scope: ShutterHub rename/construction/controller review, 2026-10-20;
REQ-025 / TEST-029 and affected software TEST-022–025/027. Human source:
PROJECT.md, ShutterHub construction and controller review. Supersedes E017 for
changed code. E018's vendor topology evidence and the hardware hold remain valid.

Expected: imports/exports use ShutterHub without an old alias; constructor
preselects up to three distinct serials, pads remaining slots without SDK access,
and rejects invalid/excess/duplicate configuration. Explicit controller injection
must preserve one to three distinct objects and not silently ignore hub options.
Retain independent controls, atomic ownership and failure/interrupt cleanup.

Changed: hub class/current callers/docs/test file renamed; ShutterHub(serials,
kinesis_dir=...) owns construction, validation and preselection. CLI now creates
one hub in one call; its duplicate validation and controller-list/padding code are
removed. Injection uses controllers= explicitly. Removed the unused simulated
single-controller wrapper/count option and collapsed slot validation. Updated
README/API/source-map/checkpoint/report and hub-message callback ID. No dependency,
CSS, backend or hardware-command changes. Production modules remain four;
production Python is 802 -> 806 lines, with real configuration validation moved
into the hub rather than omitted. Unused demo support was removed separately.

Observed validation:
- `.venv\Scripts\python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: 107 PASS in 0.37 s. Constructor tests exercise
  zero/one/three serial selections, passivity/configuration propagation, invalid/
  duplicate/excess serials and conflicting injected-controller options. Existing
  race/ownership, status/fault, GUI and all-slot shutdown/interrupt checks pass.
- Ruff check PASS and format --check PASS, 11 Python files. Dependency check:
  39 installed packages compatible. `git diff --check` PASS.
- `uv build`: wheel and source distribution PASS. Extracted wheel to
  tmp/wheel-hub-validation; verified every packaged Python file matches final src
  bytes, expected imports resolve there, ShutterHub exports come from controller.py,
  the old class export is absent and no bank.py is present. Passive serial
  preselection, three-panel HTTP/layout and packaged CSS smoke PASS with SDK
  loading forbidden. Fresh-interpreter software suite on packaged code:
  107 PASS in 0.34 s.
- Default three-panel and injected one-panel /_dash-layout JSON match the previous
  extracted package after normalizing bank-message -> hub-message. Visible layout
  is unchanged; E016's healthy simulated screenshot remains representative.
- Simulated demo --api PASS: distinct fictional serials 68000001/2/3, identity,
  independent Open/Close and all Disconnected after cleanup. README single-device,
  API single-device and serial-configured hub examples executed only under the
  patched rig; all three fakes ended Closed/released.
- Documentation: seven Python blocks parse, local referenced paths exist and
  Markdown fences balance. Static scan of active src/tests/docs/README finds no
  old class/demo wrapper references; historical project quotes/evidence are kept.

TEST-029 PASS in software-only scope. Physical TEST-003–008/026 and REQ-023 remain
BLOCKED. Environment unchanged: Windows x64, CPython 3.12.7, existing uv.lock.
No real SDK loading, USB discovery, device connection/actuation, firmware writes,
new browser session, commit or push; no server/device handle pending. B001 remains
the exact bench-resumption dependency.

## D010

2026-10-20; REQ-026. User requested gui.py construction simplification while
preserving three independent controls and keeping hardware on hold. Build each
panel with one plain function, compute slot suffixes once and reuse message/
readout elements. Use Dash's named event/selection grouping instead of slicing
raw callback arguments, and its documented zero counter defaults instead of
repeating them in every component.

Keep one serialized callback, explicit output bindings and action branches,
per-slot transient messages/selections, hub locking, safeguard/fault gating,
retained identity and all-shutter cleanup. Replacing these with a widget framework,
generic command dispatcher or independently scheduled callbacks would add
unneeded machinery or change behavior. Preserve injected single/two-slot views.

## E020

Kind / scope: GUI construction cleanup, 2026-10-20; REQ-026 / TEST-030 and
affected software TEST-022–025/027/029. Human source: PROJECT.md, GUI construction
cleanup. Supersedes E019 for changed GUI code; controller/CLI/CSS/dependencies and
E018's manufacturer evidence remain unchanged. Physical requirements stay BLOCKED.

Expected: reduce construction/scaffolding without changing three independent
serial/connection/state/error/safeguard controls, passive startup, event routing,
message persistence, fault/identity handling or complete best-effort shutdown.
Keep supported injected views and the existing rendered layout/accessibility.

Changed only production gui.py: pure panel/message/readout helpers, one suffix
list for layout/bindings, declarative panel list and named callback event/selection
groups. Removed nested ID builders/card append loop, repeated explicit zero
click/interval defaults, raw callback argument slicing and a status-label helper
recreated inside the rendering loop. Kept one lock-protected callback and explicit
per-slot commands/output fields. gui.py 257 -> 237 lines; production Python total
806 -> 786 lines. No new module, framework, dependency or controller abstraction.

Observed validation:
- `.venv\Scripts\python.exe -m pytest tests/test_gui.py tests/test_cli.py
  -q -p no:cacheprovider`: 26 PASS in 0.30 s.
- `.venv\Scripts\python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: 107 PASS in 0.34 s. Existing cases cover independent
  states and controls, duplicate ownership, mixed faults, passive startup,
  retained lost-device identity, non-replayed refresh and all-slot error cleanup.
- Before editing, saved default/single/two-slot/preselected /_dash-layout JSON
  snapshots. Final layouts compare equal after normalizing omitted n_clicks=0
  and n_intervals=0. Installed Dash 4.4.1 Button.py/Interval.py explicitly document
  these zero defaults. All labels, IDs, disabled states, CSS/accessibility props
  and panel ordering remain equal. E016's healthy simulated image remains useful;
  no new browser/physical visual test is claimed.
- Ruff lint PASS; format --check PASS, 11 Python files. Dependency check: 39
  packages compatible. `git diff --check` PASS.
- `uv build`: source distribution and wheel PASS. Extracted wheel to
  tmp/wheel-gui-validation, verified packaged Python bytes match final source,
  and imports resolve there. Passive three-panel HTTP/layout/packaged CSS smoke
  PASS with real SDK loading forbidden. Fresh-interpreter software tests against
  packaged code: 107 PASS in 0.50 s.
- Current docs/README/checkpoint/report updated; corrected the stale architecture
  sentence about the removed single-controller demo helper. Documentation links,
  Python syntax and Markdown fences checked. Prior examples/controller tests
  continue to apply to unchanged API and hardware-command paths.

TEST-030 PASS in software-only scope. Environment unchanged: Windows x64,
CPython 3.12.7, Dash 4.4.1, existing uv.lock. Hardware hold remains in force:
no real SDK loading, USB/device discovery, connection/actuation, calibration or
firmware writes. No server/device handle pending; no commit or push. Physical
TEST-003–008/026 and REQ-023 remain BLOCKED under B001 in STATE.md.

## E021

2026-10-20; TTL capability/configuration clarification, TEST-031 source/manual
review, relevant to REQ-002/010. User asked whether KCubeShutter supports IO1/IO2
TTL and how configuration is set. No implementation change was requested.

Source inspection: the class exposes no per-port direction/polarity, TTL-state or
trigger-arming API. Constructor options are serial, SDK directory, feedback
timeout (5 s) and polling interval (250 ms). Connect makes no explicit trigger
configuration/output writes and status reads operating mode. Open prepares via
Close; Close selects Inactive then Manual. Default shutdown also closes/selects
Manual and does not restore a prior triggered mode. Thus the manual GUI cannot
be used as a TTL arming interface while preserving external-trigger operation.

Thorlabs KSC101 manual HA0368T Rev D, section 3.4.1, describes bidirectional
TRIG1/TRIG2, default input/output respectively, 5 V logic, selectable active
polarity, Triggered mode and a separate priming requirement. It warns that an
open input is LOW and active-low operation can open when primed. This is
manufacturer documentation, not observed bench configuration. Reference:
https://media.thorlabs.com/contentassets/e92d618c92c94cea9096b3f231859611/etn017648-d02.pdf
The document is legacy APT material; exact current Kinesis TTL setters have not
been validated. Do not borrow trigger APIs/electrical limits from other cube models.

TEST-031 PASS for capability assessment only. Actual stored port settings are
unknown under the hardware hold. TTL support would require an explicit future
configuration/arm/disarm API and appropriate validation. No code, SDK/device
operation, actuation or authority change; E020 software evidence remains valid.


## E022

2026-10-20; Ethernet SDK assessment, REQ-027 / TEST-032. Human request in
PROJECT.md: verify official Kinesis/XA support for three KSC101s through KEH3
Ethernet and identify code changes, with hardware access on hold.

Expected: distinguish vendor support, exact inspected APIs, inference, unresolved
SDK details and physical evidence; identify current source assumptions without
implementing or exercising a hardware backend.

Observed: DOC-103012 Rev E, January 22, 2026, sections 4.2/4.3/4.3.1 documents
KEH3 Ethernet routing and Kinesis connection of attached cubes. Section 6 notes
identical cube enumeration can depend on firmware. Official product page supports
three bays and Ethernet. The manual was read through the web text extractor;
direct PDF download/screenshot returned access errors, so the bay-port figure
was not visually verified. No exact per-bay mapping is asserted by this review.
Source: https://media.thorlabscms.cn/globalassets/items/k/ke/keh/keh3/doc-103012.pdf?v=0129060351

Official Motion_Control_Examples revision
3ef959523e2be48d57704af964f7a2c24547b722 includes a BBD Ethernet example and API
CHM. Downloaded as data; hh.exe -decompile extracted help only. SDK help confirms
ScanEthernetRange(startIPAddress,endIPAddress,portNo,openTimeout),
CreateManualDeviceEntry(comSpec), DeleteManualDeviceEntry(comSpec),
GetManualDeviceEntries and GetTransportInfo(serialNo). The BBD example does not
prove KSC101 bay registration grammar. The KSC101 Python example supplies the
serial-based device factory/connect path. No real SDK assemblies were loaded.
CHM SHA-256: dfa52c72df9c0c9859bd29a9cfb9efe7a29e33787f9b4ddec0e720704de29b7d.

Official XA PyPI 1.9.1.28941 wheel and source archive inspected without import,
installation or native DLL execution. Wheel SHA-256 verified against PyPI:
48f0405cd094689ca790691b3fc174ae4f9271b9e97c786f1e984e606830fa2f.
Its changelog adds KSC101 in 1.7.0 (2026-09-18); product/factory, solenoid feature
methods and device/transport/parent discovery fields are present. DLL string
inspection finds TLMC_DiscoverEthernetDeviceInfo; historical changelog documents
Ethernet fixes. These establish components, not this topology's runtime behavior.
SystemManager has transport-aware open_device_as but no dedicated Ethernet scan
method in the inspected Python wrapper. Native discovery signature/startup settings
schema remain unresolved; no invented binding/transport literal is proposed.
Static source also shows Device.parent_device_id returning _device_id; assessment
warns against relying on it for hub mapping.

Current production review: discover() uses BuildDeviceList/GetDeviceList(68),
connect() creates a serial-based KCubeSolenoid; _check_connection() requires
USBConnected, and no Ethernet endpoint configuration/registration exists.
ShutterHub already provides three instances and failure-tolerant cleanup.
Assessment documents transport-aware discovery/health, ownership across transport
aliases, shared registration lifetime, CLI/status propagation and software/bench
test needs; XA would require a larger driver/lifecycle/status mapping change.

Result: TEST-032 PASS for research/source assessment, not SDK execution or physical
acceptance. Kinesis is the documented incremental route; XA is a supported-device
candidate with its exact Python KEH3 discovery contract still unresolved. Full
sources, limitations and proposed changes: docs/ethernet-assessment.md. Production
source, uv.lock and dependencies unchanged; prior E020 tests remain applicable.
No USB/network hardware scan, device connection, actuation, configuration/firmware
write, commit or push. No SDK/device handle or helper process remains pending.

## D011

2026-10-20; REQ-028–030 / TTL follow-up in PROJECT.md. Use one immutable normalized
TriggerConfig, the existing KCubeShutter driver and one serialized GUI callback;
retain separate per-panel draft settings and device readback. No generic trigger
backend, compatibility fallback, new dependency or automatic arming. Apply requires
Closed/Inactive/Manual; Arm uses device settings and checks safeguards/input.

Disarm/Close must verify Closed/Inactive before selecting Manual. Basis: Active
in Manual requests opening, while a primed Triggered/Active cube can be closed
because its input is inactive. Changing mode before acknowledged Inactive could
therefore request opening. If the command/feedback fails, skip Manual, report
closure/disarming as unverified and still attempt release and remaining slots.
This tightens the prior sequence without claiming physical proof; the model
explicitly reproduces Manual/Active opening. No prior trigger mode is restored.

## E023

2026-10-20; TRIG1/TRIG2 implementation, REQ-028–030 / TEST-033. Expected: verified
KSC101-specific configuration/readback contract, explicit independent arming and
disarming in driver/GUI, passive startup, draft separation, faults/refusals,
safe cleanup sequencing and all-slot continuation, reproducible package/docs.
Authority: user's local implementation/software-validation request in PROJECT.md;
hardware hold unchanged. Physical REQ-031 / TEST-034 remains BLOCKED.

Static official contract: extracted the previously downloaded Thorlabs Kinesis
.NET API CHM (official Motion_Control_Examples revision
3ef959523e2be48d57704af964f7a2c24547b722). Read KCube.SolenoidCLI KCubeSolenoid
`a07553.html`, TriggerConfigSettings `a07565.html` and OperatingModes
`a07549_a4682b683a86f17b04ee9fe588f7f913f.html`. Verified request/get/set trigger
configuration methods, four settings properties, Disabled/TrigIN_GPI/TrigOUT_GPO,
TriggerHigh/TriggerLow and Triggered mode. No assemblies were loaded. This is
static API evidence, not validation of the installed SDK. Links and exact mapping:
docs/INTERFACE.md#ttl-interface. CHM SHA-256 remains
dfa52c72df9c0c9859bd29a9cfb9efe7a29e33787f9b4ddec0e720704de29b7d.

Implementation: public TriggerConfig and per-status trigger_config/ttl_armed;
get_trigger_config/configure_triggers/arm_triggers/disarm_triggers. Both settings
and arming require matching reported feedback. Unknown enum values, communication
errors and setting mismatch invalidate TTL status. Arm requires key/interlock and
an input; failed/interrupting arm attempts closure. Close requires Inactive/Closed
before Manual (D011), then verifies Closed/Inactive/Manual. Default release, hub
and CLI retain every-slot error/interrupt cleanup and serial ownership semantics.
No explicit settings-persist/EEPROM/firmware command. A communication-only explicit
disconnect(close_shutter=False) retains its existing output/mode semantics.

GUI: both ports' mode/polarity drafts, independent readback and Apply/Read/Arm/
Disarm buttons in every panel. Read replaces drafts; ordinary refresh preserves
them and cannot replay a write. Arm uses device readback, never unapplied drafts.
Apply requires Closed/Inactive/Manual; Manual Open refuses Triggered. Faulted
readback is Unknown, Apply/Arm disabled, cleanup available for retained handles.

Observed final validation, Windows x64 / CPython 3.12.7 / Dash 4.4.1 /
Python.NET 3.1.0, unchanged dependencies/uv.lock:

- `.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py`:
  **187 PASS in 0.50 s**. Baseline 107 plus 80 TTL regressions. Includes all 36
  mode/polarity combinations, malformed values, both input polarities on TRIG2,
  modeled active-low opening, Armed/Closed distinction, existing armed connect
  without writes, idempotent arm, faults/safeguards/no-input refusals, setting
  mismatch, failed arming/interrupts, no Manual after unacknowledged Inactive,
  retained-handle cleanup and continuation across all three shutters.
- HTTP GUI tests verify independent Apply/readback/arming, draft preservation,
  Read draft replacement, invalid browser values, fault gating and global cleanup.
  Background browser additionally connected three fake identities, armed only
  Shutter 2 (Armed/Closed with LOW input and high polarity), verified gating,
  Disarm and all-slot shutdown. Native JPEG detail saved as
  docs/assets/gui-ttl-simulated.jpg, 1265 x 712 px. Existing pre-TTL captures are
  labeled historical. Browser layout is unchanged by the final driver-only
  Inactive-feedback gate. Simulator/listener on 8058 and temporary tab closed.
- Ruff check and format --check PASS (12 Python files); `uv ... pip check`: 39
  compatible packages. `git diff --check` PASS. Three-device simulated_demo --api
  PASS for manual/TTL/configuration/arming/disarming, all three finally disconnected.
- `uv build` PASS for sdist and wheel. A restricted-cache build first failed on
  network resolution; normal approved build succeeded. Extracted final wheel to
  tmp/wheel-ttl-final; verified packaged Python bytes equal final source and import
  resolves from that tree. Fresh-interpreter packaged tests: **187 PASS in 0.49 s**.
  Final wheel SHA-256:
  ae296ea4d82b42097160f61b8bccadbc069c349460b8e017b0112745affe35c3.
- Updated README, API/GUI/interface/architecture docs, simulated example, STATE
  and report. Prepared stage 10 TTL acceptance as unexecuted TEST-034. Manifest
  records source/artifact hashes and scope: records/ttl-validation.json.

TEST-033 PASS for software scope only. Readback waits one polling interval after
requests but remains vendor-maintained data, without certified age or pin voltage.
Three panel refresh adds at least 750 ms at default polling plus SDK time. The
manual's open-input LOW/active-low warning is documented; no actual wiring,
electrical behavior, priming, persistence, closure or timing has been demonstrated.
Shutdown remains sequential/best effort, with no bound on hung vendor calls.
No real SDK import, USB/network device scan, connection, actuation, calibration,
firmware write, commit or push. E022 Ethernet research remains intact; production
transport is USB. AWAITING_HUMAN_REVIEW / B001 and physical blockers remain in force.

## D012

2026-10-20; consistency review, REQ-032 / TEST-035. Separate operating feedback
needed to close/disarm from optional TTL settings readback. A configuration read
or unknown configuration enum must not prevent verified Inactive/Manual cleanup.
Open/Close/Disarm command snapshots can omit trigger_config; get_status/connect/Arm
still request full settings. Preserve the original fault until successful cleanup.

Release collects failures/interruption from StopPolling and Disconnect separately,
attempts both, then updates handle/ownership and re-raises any interruption. Apply
the same fault-before-propagation rule to failed connection and Open recovery.
Verify returned identity at connect and sample operating feedback after the
settings delay. Keep the existing driver/hub and one serialized GUI callback;
no new framework or hardware authority. Historical validation artifacts remain
unchanged; E024 supplies current LF-normalized source/package evidence.

## E024

2026-10-20; user requested consistency review, pruning/fixes, commit and push.
REQ-032 / TEST-035; full software regressions also revalidate current three-shutter
and TTL requirements. Publication is REQ-033 / TEST-036, recorded separately.
Expected: reproduce supported defects, fix their causes, preserve independent
controls/ownership/shutdown and hardware hold, align docs and validate packaging.

Review findings and fixes:

1. StopPolling interruption skipped Disconnect; release interruption could also
   bypass fault/ownership bookkeeping. Release now attempts both steps, preserves
   errors/interruptions and keeps the claim only when the handle remains retained.
   Failed connect cleanup records a fault even when interrupted.
2. TTL settings reads were required by every closure wait. A settings failure or
   unknown enum prevented the Manual step despite otherwise valid Closed/Inactive.
   Operating-only waits now allow verified disarm without settings readback.
   Full status/GUI still reports the latched settings fault until disconnect/reconnect.
3. Status sampled key/interlock/state before the TTL polling delay, returning
   values already superseded during that wait. It now samples operating feedback
   after the settings request/read. This reduces an avoidable stale interval;
   it does not establish atomic feedback or physical/cache freshness.
4. Connect accepted returned identity without comparing it to the selected serial.
   Identity mismatch now fails/release before any output write. Non-string serials
   produce actionable validation errors before SDK access.
5. An interrupt during failed Open recovery escaped before recording a fault.
   Open/Arm recovery records faults before propagation; an interrupted failed
   Open cannot subsequently appear healthy.

Pruning: build enum maps once per configuration call, consolidate separate release
handlers and remove duplicate recovery-message construction. GUI construction and
its single serialized callback stay unchanged. Corrected status/API semantics,
Close's two confirmation stages versus Open/Arm's three, identity/shutdown docs,
historical screenshot labels and publication intent. Ignore only pytest-generated
temporary cache names; no recursive cleanup/deletion. Normalize current source to
the repository's LF policy so committed/package hashes are reproducible.

Observed validation (no real SDK/device access):

- Re-ran 14 focused new regressions against the E023 extracted wheel at
  tmp/wheel-ttl-final: **14 FAIL**, 197 deselected. Failures reproduce identity,
  pre-delay feedback, interrupted Open recovery, release interrupts in normal and
  failed-connect paths, and disarm blocked by settings reads/unknown enums.
- Final source command `.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: **211 PASS in 0.60 s**, including 24 added cases.
  Includes interruption in one armed slot while remaining slots still close/release.
- Ruff check and format --check PASS, 12 Python files. uv dependency check: 39
  compatible packages; dependencies/uv.lock unchanged. Simulated API completes
  manual/configuration/Arm/Disarm on all three fake identities, then disconnects all.
- `uv build` PASS. Wheel and sdist Python bytes match final source; CSS present;
  no tmp, venv or pytest-cache artifacts. Final wheel extracted at
  tmp/wheel-review-validation; explicit import path verified. Fresh-interpreter
  packaged software tests: **211 PASS in 0.50 s**. Wheel SHA-256:
  9d152e4c50074f6cde54e42c89d22211fc7db4d035f64ccddabdb4f3bd15eccd.
- GUI/CSS bytes, normalized to LF, match the E023 package; no new browser test is
  claimed. HTTP/layout regressions pass. Current source/artifact/environment
  evidence: records/review-validation.json. Earlier JSON manifests describe their
  historical workspace/artifacts and must not be used as current-source hashes.
- Origin fetched successfully; before commit HEAD and origin/main both ca47dd2,
  ahead/behind 0/0. User explicitly authorizes normal commit/push. No history rewrite.

TEST-035 PASS (software only). Physical tests remain BLOCKED. No SDK assembly
loaded, USB/network device scan, device connection/actuation, calibration,
electrical measurement or firmware change. No simulator/device handle pending.
Source/package/doc review is complete; normal commit/push and remote verification
are the remaining authorized publication steps.

## E025

2026-10-20; REQ-033 / TEST-036, authorized commit/push from the latest user request.
Expected: commit the explicitly reviewed files, push normally to origin/main,
verify remote identity and retain the hardware hold.

Observed: staged an explicit 33-file allowlist; cached diff/check reviewed, no
unstaged changes, no local cache/SDK artifacts. Staged Python blob SHA-256 values
match the final source manifest. Commit 2bce513baeef36a38f365c1e78c3702e30bf821e,
"Add three-shutter hub and independent KSC101 TTL controls", created successfully.
`git push origin main` succeeded as ca47dd2..2bce513, no force/history rewrite.
`git ls-remote origin refs/heads/main` returned the same full commit ID. Local
HEAD/origin/main matched, ahead/behind 0/0, working tree clean after that push.

TEST-036 PASS for implementation publication. The subsequent record-only
checkpoint preserves this evidence without changing the validated software;
its publication uses the same normal push and remote-verification procedure.
Software checks remain E024 / 211 source and wheel tests. No hardware or SDK
access occurred; AWAITING_HUMAN_REVIEW / B001 and physical blockers remain.

## D013

2026-10-20; REQ-034 / beginner hardware-only tutorials. Keep five standalone,
numbered programs in docs/examples, with one guide and no common helper or
simulation mode. Require explicit actual serials for connection and operator-
approved finite positive holds for actuation; do not invent safe dwell defaults.
Use explicit try/finally for connection and all-slot cleanup. The passive status
lesson deliberately uses communication-only release and explains that it does
not close/disarm an existing state. The TTL lesson uses TRIG1 input/high and
TRIG2 disabled; explain immediate opening, retained settings and timing limits.

Move the existing simulator to tests/simulated_demo.py, preserving developer
verification without making it a hardware tutorial. Update current links and
fixture location; keep historical records untouched. No production API change,
hardware authorization or automatic publication is part of this request.

## E026

2026-10-20; REQ-034 / TEST-037. User requested four to five easy, tutorial-like
hardware examples with beginner explanations. Expected: five ordered hardware-only
scripts, clear setup/configuration, explicit side effects and cleanup, runnable
help, maintained links, software-only validation with hardware still held.

Delivered docs/examples/README.md and:
01_discover.py, 02_connect_and_read_status.py, 03_open_close.py,
04_three_shutters.py, 05_ttl_control.py. They cover serial mapping, feedback,
single-shutter manual operation, sequential three-shutter control and TTL.
The guide supplies PowerShell commands, vocabulary and explanations of reported
state versus physical observation, passive release versus shutdown, arming versus
position, finite operator-chosen dwell and best-effort recovery. Source comments
explain each operation. No sample real serials or assumed safe dwell defaults.
Actuation scripts always attempt closure/release in finally, including after
failed connection, command errors or Ctrl+C; the hub attempts every slot.

Moved docs/examples/simulated_demo.py to tests/simulated_demo.py and adjusted its
fixture lookup. Updated README, setup/GUI/API/architecture links and removed the
duplicate README interactive actuation program. The simulator remains internal
and the example folder contains only five hardware scripts plus its guide.
Production source, dependencies and uv.lock unchanged.

Observed validation:

- 32 new tests in tests/test_examples.py PASS using the existing distinct fake
  devices. Covers passive imports/help, discovery without connection, status
  release without output writes, chosen holds, no two shutters opened together,
  TTL apply/read/arm/disarm, malformed/non-finite durations, duplicate serials,
  all-connected cleanup after Open failure, and TTL wait interruption cleanup.
- Full software suite, explicitly excluding tests/test_sdk.py: **243 PASS in
  0.56 s**. No SDK/device operation is authorized by this validation.
- Executed all five actual __main__/--help paths under an SDK-loader prohibition:
  PASS with no SDK loading. Static syntax and folder count PASS.
- Ruff check and format --check PASS. All 112 checked local documentation links
  and anchors resolve; Markdown fences balance. The developer-only simulator's
  --api walkthrough PASS with three independent manual/TTL lifecycles and final
  all-disconnected state. No server or handle remains pending.
- `uv build` PASS. Source distribution contains all five lessons, guide and
  relocated simulator with exact file bytes; old simulation-example path absent.
  Final wheel extracted to tmp/wheel-tutorial-validation; production Python
  matches unchanged source, import root verified. Packaged software suite:
  **243 PASS in 0.85 s**. No real SDK loaded during these tests.

TEST-037 PASS in software scope only. No hardware tutorial was run against real
devices. AWAITING_HUMAN_REVIEW / B001 and physical TEST-003–008/026/034 remain
BLOCKED. Real feedback, wiring, pin levels, priming, timing and closure remain
unproven. No firmware change or new commit/push. Prior E024/E025 publication is
historical; current tutorial changes are local.

The current API stage-10 link follows the separately refined E027 hardware plan;
that plan and its evidence were preserved without hardware execution.

TEST-037 artifact SHA-256 values (final measured files):

- docs/examples/01_discover.py: fb240de86be58a2288b06a42aa56753055857c6e4b4c38ca5848e0decfe60fa4
- docs/examples/02_connect_and_read_status.py: 7c4a430e8e40248c3d5aa56ef3e6ff1c9f72bfbb76990c986e5eda3f72ffd2fd
- docs/examples/03_open_close.py: e68a04dae189ae15be8474cc0f66712fb84f5db601c520639ebbc1f14560b41b
- docs/examples/04_three_shutters.py: c848d78ab70adcf90c5a07049d2e50185ae18ab423ecb2653a26a87af6a866ff
- docs/examples/05_ttl_control.py: a0f41230005086eb3299907406da9a5db3cbf76806cfb9f41e6070d4b7b185af
- dist/thorlabs_shutter_control-0.1.0-py3-none-any.whl: f44ef023377d8512857eb7dc914a1d1e5d68cf2b9b0009b8878515ac0f3683e3

## E028

2026-10-20; REQ-035 / TEST-038, final hardware-plan review requested before
implementation. Review scope: documentation plus software-device verification,
not hardware launch. E027 topology remains human-reported, not bench-verified.

Reviewed current controller.py, gui.py, __main__.py, test_sdk.py, software-device
fixture, hardware tutorials and interface notes. Checked official KSC101 trigger
warning (HA0368T Rev D, section 3.4.1); direct KEH3 manual retrieval was unavailable.
The procedure requires matching bench manuals before dependent setup/electrical
actions. No newly inferred electrical limits or firmware instructions were added.

Corrected consequential gaps:

- Replaced duplicate A–H overview plus stage sequence with one numbered procedure
  and an explicit physical-requirement/test/evidence matrix. One-pair initial
  acceptance does not require three installed serials or TTL authority; full
  three-device/TTL requirements remain pending until their own cases pass.
- First Close uses try/finally cleanup; first Open/Close reuses the checked
  tutorial. Other motion stages require the protected pattern and no prompt
  while Open. Added hold/Closed pause and independent finite-dwell enforcement
  conditions; sleep and vendor/GUI delays are not a maximum Open-time mechanism.
- Distinguish shutdown-from-Open from explicit Close followed by shutdown, live
  physical closure from cached feedback, and retained handle from latched fault.
- Treat proposed USB-loss 10 s as an observed acceptance window, not a deadline
  that can interrupt a blocked SDK call. Refusal test runs only after a returned
  latched fault. Record intentional-loss cleanup errors without calling closure PASS.
- Move manual-Open refusal into the armed/inactive-input TTL subcase before
  Disarm. Isolate input/output ports, make GUI draft/readback checks explicit,
  account for measurement loading and keep Open-state loss/power-cycle tests out
  of the launch scope. No output-setting readback is called a pin measurement.
- Keep software proof of command guards/cleanup attempt order separate from
  physical evidence: no motion/UI summaries alone do not prove every SDK call.
- Require final integrated checks and preserve all physical blockers, per-device
  identity/mapping and independent recovery conditions. No authorization expanded.

Observed TEST-038 results:

1. Inline `.venv/Scripts/python.exe -` review parsed all **3 Python fences** with
   ast.parse, checked stages 0–10, balanced fences and the local interface link.
2. Executed documented Python blocks against tests/conftest.py's existing rig
   using runpy and pytest.MonkeyPatch: **6 cases PASS** — three passive cycles,
   passive release error, first Close, first-Close error, shutdown from Closed,
   shutdown from Open. Final handles/serial claims released; passive cases issue
   no mode/state/enable/settings write; first-Close cases never issue Active.
   Assertions confirm no loaded SDK, clr or Thorlabs modules.
3. PowerShell Language.Parser.ParseInput parsed all **6 PowerShell fences**:
   PASS; no command in those fences was executed. `git diff --check`: PASS.
4. Reviewed plan SHA-256:
   981fc25d99548f5d4ebafcac2ba1dcc7212f939371a7ec5b850e0b7ae5c9743f.

TEST-038 PASS for procedure/source review and software-only checks. No new
production-code change, dependency change, package build or whole-suite rerun
is claimed. E026 remains evidence for its unchanged tutorial/production software
and named package artifact, not a rebuilt package containing this revised plan.
No SDK discovery, physical connection, actuation, wiring change, electrical
measurement, calibration, firmware write or publication occurred. Hardware status
remains AWAITING_HUMAN_REVIEW; physical acceptance BLOCKED under B001. Resume only
with the stage-0 bench record and explicit approval for the named initial stages.

## E029

2026-10-20; REQ-036 / TEST-039, Stage-0 implementation under the user's instruction:
implement one stage, wait for human review, keep hardware access on hold.

Implemented only Stage-0 preparation:

- records/hardware-bench.json records the supplied topology as human-reported;
  actual pair count, serials, power, host configuration and transient bench states
  remain unfilled. Later motion/TTL limits are explicitly deferred, not assumed.
- docs/hardware_tests/stage_0.py reads a local JSON file only. It reports missing
  fields, wrong shapes, malformed serials, duplicate identity/mapping, changed
  model/host assumptions and absent ownership confirmation. Exit 0 is structural
  record completeness only, 1 incomplete and 2 unreadable/malformed. It never
  authorizes a launch, verifies physical conditions, imports the controller/SDK,
  modifies the record or executes a later stage.
- The guide documents pair fields, observation freshness limitations, deferred
  limits, passive invocation and the Stage-0 human review boundary. The acceptance
  plan only gains a Stage-0 tooling cross-reference; physical criteria unchanged.

Expected: an incomplete supplied record is refused, complete fictional records
can be assessed without hardware, and all outcomes keep the hardware hold visible.
Observed software-only validation:

- 36 new tests in tests/test_hardware_stage_0.py, including guarded imports that
  reject controller, pythonnet, clr or Thorlabs imports; one/three-pair records,
  unknown/malformed fields, timestamp timezone, duplicate serial/label/bay/cable,
  changed topology/bitness/OS, ownership, CLI status/error/help and no-write paths.
- First run: 31 PASS / 5 fixture errors from Windows access denial to pytest's
  temporary directory. A fresh workspace --basetemp also hit Windows directory
  access denial. Neither run is claimed PASS; no ACL change or recursive cleanup.
  Read-only CLI input/error tests now use in-memory Path.read_text fixtures and
  forbid Path writes, avoiding dependence on pytest temporary-file permissions.
- Final command `.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: **279 PASS in 0.67 s** (243 prior + 36 Stage-0).
- Actual `python docs/hardware_tests/stage_0.py` prints HARDWARE ACCESS ON HOLD,
  lists missing bench fields and exits **1**, expected for the supplied record.
  Actual --help exits **0**. No SDK/device code is present in the checker.
- Scoped Ruff check and format --check PASS (2 Python files); git diff --check
  PASS. Production source, pyproject.toml and uv.lock have no diff. No build,
  physical test, calibration, device access or publication is claimed.

SHA-256 of reviewed Stage-0 artifacts:

- docs/hardware_tests/stage_0.py: 332eeee0dab6709dd83a599b5bb39299bcd79ede61c4c9c1c2eaa3502bc7013a
- records/hardware-bench.json: 6afe0a440b1a01d17544c00af40da98ae21bc0a527cccbfa0f5aa3f3ee671929
- tests/test_hardware_stage_0.py: f99a1fd504cd66f68c3843a7ba7acf69b53aa15329ddc06ea4a2cf4302ffabe4
- docs/hardware_tests/README.md: b4033380066ce4d78301b8a320f44d98b691a2ad943d961cf2bc33ce0610783f

TEST-039 PASS for Stage-0 software preparation only. REQ-036 remains IN PROGRESS;
Stage-0 human review is pending (B002), Stage 1–10 tooling is not implemented in
this request, and physical acceptance remains BLOCKED (B001). Stop here until
the human reviews Stage 0. That review can authorize Stage-1 implementation only;
the explicit hardware hold persists without separate launch authority.

## E027

2026-10-20; hardware-plan refinement for physical REQ-003–008/023/031.
Human-reported configuration: computer -> USB -> KEH3 -> KSC101 -> SH05R.
This resolves the previously unspecified shutter model and confirms intended USB
topology only. Installed pair count, serials, power, firmware/SDK, safeguards,
initial states and limits are not independently verified.

Updated docs/HARDWARE_VALIDATION.md with gates A–H for one pair through KEH3,
conditional three-pair acceptance and a separate TTL gate. Retained existing
physical TEST IDs and criteria, explicit launch hold, independent observation,
approved dwell and recovery, shared-USB failure scope and sequential cleanup
limitations. No timing specification from another controller is used as acceptance.
Official Thorlabs shutter information identifies the KSC101/SH05R pairing;
matching bench manuals and supply labels remain prerequisites.

Validation scope: documentation/source review only; no physical test executed,
SDK loaded, enumeration, connection, actuation or electrical measurement.
Physical requirements remain BLOCKED; this record is not a hardware PASS.

## D015

2026-10-20; REQ-040, holistic review/development-plan request. Retain the compact
KSC101/SH05R, KEH3 USB, Kinesis .NET scope as the proposed package foundation.
Prioritize command/identity/shutdown and feedback/execution contracts before new
modes/transports. Deliver a review and roadmap only, preserving separately gated
stage implementation, human review and hardware launch authority. No public API
change or feature implementation is authorized by this planning decision.

## E035

2026-10-20; REQ-040 / TEST-045, holistic package review and development plan.
Deliverable: docs/DEVELOPMENT_PLAN.md. Reviewed production controller, hub, GUI,
CLI, software-device fixtures, SDK-test boundary, tutorials, package metadata,
interface/architecture/Ethernet notes and physical acceptance/stage records.
Official reference inspected: Thorlabs Motion_Control_Examples, Python/Kinesis/
KCube/KSC101/KSC101_pythonnet.py on GitHub. It supports the existing API path;
it does not establish current SDK version, bench compatibility or recovery.

Expected review result: distinguish supported strengths, reproducible defects,
unverified physical/SDK assumptions and conditional features; provide prioritized
changes with exit criteria without changing production behavior or accessing hardware.

Observed software-only reproductions, via inline `.venv/Scripts/python.exe -`
using runpy, pytest.MonkeyPatch, tests/conftest.py's rig.__wrapped__ and
tests/test_gui.py's invoke helper (Flask in-process client, no real server):

1. Connect fake 68000001, assign public serial_number='68000002', compare
   get_status().serial_number with identify_device()['serial_number']:
   **68000002 versus 68000001**. Restore serial and clean up. This bypass uses
   direct attribute mutation; normal connect(other_serial) already refuses it.
2. Create single-controller GUI with fake SDK, Connect, Open(clicks=1),
   Close(clicks=1), repeat Open(clicks=1): **Open, Closed, Open**. Cleanup follows.
   Server accepts the repeated event; no normal-browser retry or physical
   reopening was observed. The probe demonstrates absent server-side replay/order
   validation, not a measured frequency of stale requests.

Source findings: global GUI shutdown calls full status on every controller
before hub cleanup; serialized callback/native calls can block all controls;
TTL reads request/sleep/get without response-generation or age metadata;
real-SDK test can enumerate USB on ambient KINESIS_TEST_DIR. These are findings
and design limits, not observed physical failures. Detailed priorities/acceptance
are in the development plan. No test was added for these proposed fixes yet.

Validation checkpoint:

- `.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: **279 PASS in 0.65 s** at the review cutoff.
- `ruff check src tests docs/examples docs/hardware_tests`: PASS at first review
  run. Broad format check then encountered a newly appearing, concurrently edited
  docs/hardware_tests/stage_1.py: one file needed formatting. No edits made to it.
- Final scope: `.venv/Scripts/python.exe -m ruff check src tests docs/examples
  docs/hardware_tests/stage_0.py --exclude tests/test_hardware_stage_1.py`: PASS;
  corresponding `ruff format --check`: **21 files already formatted**. An earlier
  explicit-path attempt named absent tests/test_main.py and failed; corrected to
  the scoped command above. No broad format PASS is claimed for concurrent work.
- Production SHA-256: controller.py
  f9970adbf203622ac3cf3ff1b1c93b84bea965ba39d48adbc7778c6406b54aff;
  gui.py 4c20c1fa90ce0bc51c1cc9889fd1fb0a4e8a0bea808c8f53dc53fdcd0829e374;
  __main__.py 64992f7a84a3044181cd81cc3618da65d95cf858ca3242aa6d54936159aedab4;
  __init__.py 8f3f2b6322eb188a53e9483781c161da05ad835d5e8489f69fde9388293f1d97.

Plan local links resolve and Markdown fences balance; git diff --check PASS.
TEST-045 PASS for review/planning and its software baseline only. The package is
not physically qualified. Concurrent Stage-1 implementation is outside this
review's validated snapshot and does not receive approval from this record.
Preserved existing dirty tutorial/stage work. No production edits, real SDK load,
device access, electrical test, calibration, build, firmware write, commit or push
were performed for this request. Hardware hold and separate review gates remain.

## E036

2026-10-20; REQ-036 / TEST-046. The human approved Stage 0 and requested Stage-1
implementation with the hardware hold retained and a review stop before Stage 2.

Added docs/hardware_tests/stage_1.py and tests/test_hardware_stage_1.py. Default/
--preflight reads the bench record and local distribution/Python metadata only,
reports missing facts/dependencies and host mismatches, and labels physical tests
UNTESTED. --discover returns BLOCKED/exit 3 before reading any record, with no
CLI approval/force override. The reusable check_discovery function accepts an
explicit enumerator; under the hold tests supply KCubeShutter.discover backed
by the existing fake SDK only. It requires complete recorded prerequisites,
compares expected/observed serial sets, rejects malformed/duplicate identities,
reports missing/unexpected serials and errors, and does not retry or connect.
MATCH means enumeration comparison only, not physical mapping or TEST-003 overall.

Observed software-only validation:

- 22 new tests: held/import/help/default/offline CLI, record errors, metadata/host
  issues, incomplete-record guard, one/three fake devices, missing/unexpected or
  malformed/duplicate identities, error preservation and interrupt propagation.
  Real clr/pythonnet/Thorlabs imports are forbidden in these tests. Fake-device
  call logs confirm enumeration only, with no Connect/poll/output/cleanup calls.
- Focused Stage-0 + Stage-1 tests: **58 PASS in 0.18 s**.
- Full `.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: **301 PASS in 0.71 s**.
- Actual offline CLI: exit 1 / INCOMPLETE for the supplied record, reporting
  Windows / Python 3.12.7 x64, Dash 4.4.1, pythonnet distribution 3.1.0,
  pytest 9.1.1. These are local metadata, not a vendor assembly/driver load.
- Actual held --discover CLI: exit 3 / BLOCKED; no real discovery attempted by
  this command. --help PASS. Scoped Ruff lint/format and git diff --check PASS.
- SHA-256 stage_1.py:
  46a31518806a002b079f497da8a2abbc79d2b7e16a24e71a14ace74e9bd9f083.
  SHA-256 tests/test_hardware_stage_1.py:
  88e037521a8359aac55f8021ebded19872a9ed99b214740539b430645c6a0ed3.

TEST-046 PASS (software only). Stage 0 approved; Stage 1 AWAITING HUMAN REVIEW.
Stage 2–10 tooling unimplemented. No production-source/dependency change, package
build or publication. Subsequent actual read-only Windows discovery was separately
authorized by the next human message and is recorded in E037, not software evidence.

## E037

2026-10-20; TEST-047 (actual Windows device/COM inventory), related to physical
REQ-003 / TEST-003. Human instruction: "discover the actual device. determine the
COM". Scope permits read-only actual discovery/SDK loading as needed, not driver
installation, Connect, polling, output/TTL configuration, actuation or firmware.

Observed present-device inventory:

- Kinesis Solenoid Controller: USB serial **68800777**, instance
  USB\\VID_0403&PID_FAF0\\68800777, Windows Status Error. Device ProblemCode **28**,
  ConfigManagerErrorCode CM_PROB_FAILED_INSTALL; DriverInfPath, Service and
  DriverVersion empty. No assigned COM appears for this controller in the current
  present-device/serial inventory or inspected Device Parameters.
- Present COM3 = FTDI VDIS200; COM7 = FTDI D200MMC5; COM6 = Windfreak Serial USB
  Devices. These ports do not map to the discovered shutter controller.
- USB parent is USB\\VID_0424&PID_2514\\6&3288d96b&0&1. This reports a USB hub
  relationship, not verified KEH3 physical identity/bay/shutter-cable mapping.
- C:\\Program Files\\Thorlabs\\Kinesis and its DeviceManagerCLI DLL are absent;
  KINESIS_DIR was unset. No Kinesis entry found in inspected 32/64-bit uninstall
  registry; no claim that every possible portable SDK path was searched.

Commands/method: SerialPort.GetPortNames, read HKLM HARDWARE/DEVICEMAP/SERIALCOMM
and USB Enum metadata, Get-CimInstance Win32_SerialPort, Get-PnpDevice -PresentOnly,
then Get-PnpDeviceProperty for the exact shutter instance (ProblemCode/Status,
DriverInfPath/Version, Service, Parent) and matching Win32_PnPEntity. Initial
restricted WMI/PnP reads were denied; authorized read-only escalation succeeded.
No port was opened, no device rescan/driver change requested, and no SDK loaded.

Microsoft documents Code 28 as failed installation/no selected driver:
https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/device-manager-problem-codes
This supports a driver-readiness blocker, not a demonstrated KSC101 hardware fault.
Snapshot: records/device-discovery-2026-10-20.json, recorded 23:19:38 UTC, SHA-256
df66bf387e6702075b8668c87bcebc1befaf7ff6077c6c4a460ef34cff2aa2c5.

TEST-047 establishes current OS-visible identity/error and COM associations only.
Kinesis enumeration remains UNEXECUTED/BLOCKED; physical TEST-003 and requirements
are not PASS. The operator must arrange approved official driver/SDK installation
and return its path/version plus healthy device status before SDK enumeration
under the existing discovery authorization. Do not install automatically or move
to Stage 2; implementation review and connection/actuation holds remain separate.

## E038

2026-10-20; TEST-048, SDK/driver repair and actual TEST-003 enumeration subcase.
Authority: user requested "finish up stage 1. implement stage 2", then "resolve
the SDK issues" and supplied the official Thorlabs Python example repository.
This authorizes necessary SDK/USB-driver installation and discovery; actual
Connect, polling, shutter/TTL/firmware commands and automatic reboot remain held.

Source references inspected:

- Official Thorlabs download page: https://www.thorlabs.com/software-pages/Motion_Control
- Official installer: https://media.thorlabs.com/contentassets/24d3756d382b4310b72149e2f26aa8ca/thorlabs_kinesis_setup_27990_x64.exe?v=0804065826
- Microsoft winget manifest (publisher URL/checksum/switches):
  https://raw.githubusercontent.com/microsoft/winget-pkgs/master/manifests/t/Thorlabs/Kinesis/x64/1.14.60.0/Thorlabs.Kinesis.x64.installer.yaml
- User-supplied https://github.com/Thorlabs/Motion_Control_Examples/tree/main/Python
  and Kinesis/KCube/KSC101/KSC101_pythonnet.py. The example's DLLs, Connect/settings/
  polling and release corroborate the existing interface. Its Enable/Manual/Active
  sequence actuates, so the example was inspected only, never executed.

Expected: authentic x64 SDK installed; matching USB driver binds; application
enumeration returns the previously OS-visible serial without a Connect command.
Observed:

- Restricted network download failed; authorized download escalation succeeded.
  Ignored installer cache: tmp/sdk-repair/thorlabs_kinesis_setup_27990_x64.exe,
  178612936 bytes. SHA-256 **298c4cc03a6c3b4d5c174964ae9193d13baca63dab10c1595b4e9ad5d914ff05**
  matches the manifest and previous official audit. Authenticode Valid, signer
  Thorlabs, Inc. Reverified hash/signature immediately before execution.
- Launched with Start-Process -WindowStyle Hidden and arguments
  /S /V"/qn /norestart REBOOT=ReallySuppress /L*v C:\repo\thorlabs-shutter-control\tmp\sdk-repair\kinesis-install.log".
  Bootstrap returned 0 while MSI child processes continued; early file/driver
  checks still failed, so bootstrap success was NOT counted as installation PASS.
  The requested workspace log was not created. No competing installer was started.
- Later verification: registered Thorlabs Kinesis 1.14.60.0 in
  C:\Program Files\Thorlabs\Kinesis; DeviceManagerCLI and SolenoidCLI file version
  1.14.60.27990. Windows Installer Application events 1040/1042 identify transaction
  beginning/ending against the cached Thorlabs Kinesis.msi. The InstallShield
  wizard (msiexec 58668) was last observed open; it was not killed or assumed to
  have exited. No restart was requested by the agent. Preserve/recheck this state
  before any additional installer operation; no driver repair retry is needed.
- USB instance USB\\VID_0403&PID_FAF0\\68800777 now Class USB, FriendlyName
  APT USB Device, Status OK, ProblemCode **0**, oem187.inf, service FTDIBUS,
  driver **2.12.28.1**. Existing COM names remain COM3/COM6/COM7; no COM assigned
  to this controller in present inventory.
- Actual `.venv/Scripts/python.exe -m thorlabs_shutter_control --list` returned
  **68800777**, exit **0**. This loads the installed official SDK and performs
  BuildDeviceList/GetDeviceList(68), not Connect, polling or Enable/output writes.

TEST-048 PASS for SDK/driver repair and actual enumeration of this one USB serial.
Full physical TEST-003 remains incomplete: identity after connection, physical
label/cable mapping, three-pair configuration and reconnect are not established.
No shutter position, timing or physical closure was measured. E037's initial
Code 28/default-path absence is superseded, retained as historical evidence.
Snapshot records/sdk-repair-2026-10-20.json SHA-256:
670fe6a940b317cbc6a0d8ac4067b9d6ea0e0fb401a34333d5ce6cae042f4a3b.

## E039

2026-10-20; REQ-036 / TEST-049, Stage-2 software implementation after the user's
request to finish Stage 1 and implement Stage 2. Stop for review before Stage 3;
SDK-repair/discovery authority from E038 does not extend to real connection.

Added docs/hardware_tests/stage_2.py and tests/test_hardware_stage_2.py. Default/
--preflight performs offline record/environment/explicit-serial checks. --connect
returns BLOCKED / exit 3 before record I/O or controller/SDK import. No override.
passive_cycle accepts a caller-retained controller and matching Stage-1 enumeration
record, requires complete bench fields and explicit selected identity, and refuses
another serial or existing connected/faulted owner. One cycle captures connect,
identity/status and stable known normalized feedback; it does not create an
automatic three-cycle loop or mark physical tests PASS.

Every started connection attempt has finally: disconnect(close_shutter=False).
No Close/Enable/mode/settings command is introduced. Operation and release errors
are preserved together; release errors are UNCONFIRMED, not proof of a retained
handle. Interrupts propagate after passive release attempts with the report as a
diagnostic note. No automatic reconnect, cleanup retry or post-error SDK probe.

Observed validation:

- Initial focused Stage-2 suite: 27 PASS in 0.16 s. Added three consequential
  regressions for release interruption, primary+release failure with retained
  owner/no retry, and refusal to retarget another serial's controller.
- Final full `.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider
  --ignore=tests/test_sdk.py`: **331 PASS in 1.33 s** (301 prior + 30 Stage-2).
  Tests forbid real SDK imports and use only the existing software-device rig.
  Covers three separately invoked cycles on one object, Open/Triggered state
  preserved through release, all required guards, connect/identity/status/release
  errors, identity/feedback mismatch, interrupts and offline/held CLI paths.
  Fake call logs contain no state/mode/enable/TTL-setting writes.
- Actual held --connect --serial 68800777 exits **3** before any real connection.
  Actual offline --preflight exits **1** for the still-incomplete bench record;
  this expected result is not physical acceptance or a software test failure.
- Scoped Ruff lint/format PASS; no production source, dependency, package build
  or publication change. Stage-1 implementation is accepted for advancement;
  actual Stage-2 connection/polling remains UNEXECUTED/ON HOLD.
- stage_2.py SHA-256:
  fdd867610cdb6a3379ea3cf0ce07b820c40a4c498ba8d898dc506f40ad1bd597.
  tests/test_hardware_stage_2.py SHA-256:
  32db966facf7f211fea926f875e72627958ba97bc5ac1b254496c99ab7c8fd68.

TEST-049 PASS for software preparation only. Stage 2 AWAITING HUMAN REVIEW, Stage
3–10 tooling unimplemented. Physical requirements remain BLOCKED. Resume Stage-3
implementation only after human Stage-2 review; actual passive-connection launch
needs separate authority and the missing bench observation/recovery prerequisites.


## E040

2026-10-20; REQ-003/005/036, TEST-050: actual passive USB diagnostic.
Authority: user requested Stage-2 USB then Ethernet testing and confirmed
"safe to test with the hardware"; subsequently closed Kinesis. Passive Connect,
initialization, polling, identity/status reads and communication-only release
were authorized. No output/Enable/mode/TTL/firmware command was authorized or sent.

Expected: selected USB serial 68800777 matches connected hardware information;
known status captured and passive release succeeds. Observed first production
KCubeShutter.connect rejects "Device identity mismatch: selected 68800777;
connected 26000000"; release COMPLETED, elapsed 2.969 s. See
records/passive-usb-2026-10-20.json. No automatic cycle repetition followed.

Diagnostic isolation, outside production acceptance: USB descriptor/native
TLI_GetDeviceInfo returns type 68, serial 68800777, PID 0xFAF0, description
Kinesis Solenoid Controller. Raw .NET SerialNo/DeviceID remain 68800777 while
GetDeviceInfo SerialNumberText stays 26000000 over cumulative 1.75 s of polling
(records/usb-identity-timing-2026-10-20.json). A later raw diagnostic encountered
DeviceNotReady while Kinesis GUI was present; testing stopped until the human
closed it. Fresh-process read after that closure again reports internal serial
and OriginalSerialNumber 26000000, firmware 1.0.6, hardware 3, DeviceType 16,
model KSC101. Returned feedback: Closed, AutoToggle, operating state "0",
key enabled, status bits 8192, comms OK, hub bay -2. Release completed without
errors (records/usb-identity-detail-2026-10-20.json). Its native hardware-info
return code 2 means unsuccessful; zero fields are NOT actual hardware values.

TEST-050 FAIL for production passive connection/identity acceptance. Raw reads
establish a stable disagreement, not its root cause or an approved serial alias.
No independent blade observation, timing or calibration was obtained. Mode and
operation normalization are also unresolved. Production guard/code unchanged;
no attempt to repair identity or firmware. All diagnostic sessions released.

## E041

2026-10-20; REQ-003/027/036, TEST-051: targeted passive Ethernet testing.
User screenshots identify hub serial 120100261, firmware 1.1.2, MAC
D8:47:8F:93:68:CB; Connect dialog 192.168.1.19:40303 and settings display static
192.168.0.200. These are human-supplied screenshots, not commands. Host LAN
address observed 192.168.1.201. No persistent IP/network setting changed.

Official KEH3/KEH6 manual DOC-103012 Rev E (2026-01-22), sections 4.3 and 6:
https://media.thorlabscms.cn/globalassets/items/k/ke/keh/keh3/doc-103012.pdf?v=0129060351
Downloaded to ignored tmp/ethernet-test/keh3-manual.pdf; page 23 / Figure 17
visually checked: 40303 hub, 40304 left bay, 40305 middle, 40306 right, 40307
USB OUT. Ethernet requires no USB IN connection; DHCP and static addresses may
coexist. Firmware-update instructions were reference only, never executed.

Human confirmed USB IN disconnected twice and no direct cube USB connection.
Early OS/SDK checks still showed USB-present cube/FTDI transport; those were not
counted as Ethernet cube evidence. After the latest confirmation, fresh
Get-PnpDevice -PresentOnly filtered for 68800777 returned no entries. Fresh SDK
BuildDeviceList with existing local TCPIP entries now lists only hub 120100261.
This resolves the earlier transport ambiguity; do not ask the operator to repeat
the same cable confirmation based on older snapshots.

Expected: documented endpoints discover actual identities over TCPIP, passive
reads succeed, release completes. Observed:

- SDK ScanEthernetRange on only 192.168.1.19:40303 returns that IP. User's existing
  manual entries :40303 through :40307 were reactivated locally; before/after
  entry sets identical. No existing entry deleted or network setting written.
- Earlier registered discovery listed hub TCPIP and cube FTDI; final fresh list
  contains only hub TCPIP 192.168.1.19:40303. Final port probes: TCP accepted on
  40303 and 40304, timed out on 40305, 40306, 40307 (1 s connect timeout). TCP
  acceptance alone does not prove a cube is present or communicating.
- Installed CubeEthernetHub.CreateKCubeEthernetHub / Connect over confirmed TCPIP
  reads matching serial 120100261, description K-Cube Ethernet Hub, firmware
  1.1.2, hardware 1. RequestEthernetInfo submitted; subsequent generic
  RequestStatus throws "Command not implemented". No Ethernet-info result or
  status bits claimed. Disconnect completed; IsConnected false afterward.
- Targeted SDK bay scans returned no devices. One independent raw request to
  192.168.1.19:40304 used documented passive MGMSG_HW_REQ_INFO 0x0005,
  bytes 05 00 00 00 50 01, expected MGMSG_HW_GET_INFO with 84-byte payload.
  Source: official APT Communications Protocol v40, hardware-info section p52,
  host 0x01 / generic unit 0x50 address definitions:
  https://www.thorlabs.com/Software/Motion%20Control/APT_Communications_Protocol_v40.pdf
  Socket accepted, recv timed out at 3 s with no bytes; context released socket.
  No alternative addresses/commands or actuating messages were tried.

Evidence: records/ethernet-discovery-2026-10-20.json,
records/ethernet-devices-2026-10-20.json,
records/ethernet-registered-discovery-2026-10-20.json,
records/ethernet-recheck-2026-10-20.json,
records/ethernet-hub-passive-2026-10-20.json,
records/ethernet-cube-hwinfo-2026-10-20.json.

TEST-051 partial result: PASS hub TCPIP identity/connection/release; FAIL generic
hub status operation; BLOCKED cube SDK discovery/identity/status acceptance.
No production Ethernet backend added or validated. Request human observation of
physical cube bay, powered display and bay LED pattern; no docking/power/wiring
change requested. Stage 2 remains BLOCKED, Stage 3 held for human review.

## D016

Preserve the production identity and USB health guards. Successful raw USB reads
and a responding Ethernet hub do not establish a safe identity alias or working
cube Ethernet transport. Do not weaken normalized-status acceptance, update
firmware/IP, or use output commands to diagnose these failures. Obtain the bay/
power/LED observation, then choose a passive test supported by that evidence.
No new source tests/build were needed for diagnostics and checkpoint-only edits;
E039's 331 software-test result remains scoped software evidence.


## E042

2026-10-20; REQ-003/004/005/007/036, TEST-052: Stage-3/4 readiness review.
User requests examination of readiness to implement Stage 3 and Stage 4, then
answers the pending observation request: "cube connected to the bank. display
powered. can manually control the SH05R. no bay LED." Treat as human-reported
local functionality and absent observed LED, not independently measured blade
state, a specific bay identity, docking failure or successful SDK communication.
The earlier power/LED observation request is answered; exact bay remains unknown.

Method: inspect PROJECT/STATE and E040/E041 JSON evidence, reviewed hardware
procedure sections 0/2/3/4, Stage-2 feedback validation, production connect/
open/close/release and docs/examples/03_open_close.py. No SDK import, discovery,
connection, output command or physical operation occurred in this review.

Readiness criteria and result:

- Stage-3 offline implementation: feasible with existing controller and fake
  devices, but current request is review only; stage-by-stage human review stays.
- Stage-3 physical launch: NOT READY. Reviewed plan requires stages 0–2 PASS.
  Connect fails selected serial 68800777 versus hardware serial 26000000 (E040).
  Raw AutoToggle/operating state 0 feedback is unresolved; do not assume it is
  accepted normalized inactive/manual feedback. Bench mapping, safeguards,
  observation/recovery details and specific actuation authority remain incomplete.
- Stage-4 offline implementation: can be designed now, implement only after
  Stage-3 implementation review under the established sequencing.
- Stage-4 physical launch: NOT READY. Requires Stage-3 PASS including independent
  Closed observation, approved Enable/Open/Close/cleanup authority and hold/duty/
  recovery conditions. Proposed 1 s is not an approved safe operating limit.
- Hub Ethernet connection does not establish cube Ethernet communication (E041).
  A validated USB-only Stage-3/4 launch need not wait for Ethernet qualification;
  receipts and acceptance must remain specific to the tested transport.

Implementation acceptance proposed: prerequisite refusals emit no output; verify
Inactive -> Closed/Inactive -> Manual -> Closed/Inactive/Manual ordering; preserve
operation and cleanup failures; handle interrupts and communication release;
record independent observations separately from SDK data. Stage 4 adds finite
positive approved added hold, one Open/Close pair and best-effort Close/release.
No software sleep or finally block guarantees maximum exposure or physical
closure. No new implementation/tests were added for this inspection; existing
331-test result E039 remains software-only, not freshly rerun bench evidence.

TEST-052 PASS for source/evidence readiness assessment; live Stage-3/4 launch
BLOCKED. Next engineering priority: explain identity/status disagreement and
revalidate Stage 2, preserving the guards and avoiding actuation as a diagnostic.


## E043

2026-10-20; REQ-041 / TEST-053: minimal controller hardware-handling revision.
Source authority: user's request to examine/revise controller with minimal
modifications. Software-only implementation; hardware access held for this task.

Inspection found: callers can relabel an owned controller through public serial
assignment; status requested generic status/TTL but not operating mode/state;
raw .NET timed-mode names were lowercased rather than normalized, while state 0
could be returned as healthy connection feedback. These gaps are distinct from
the still-unexplained actual hardware identity disagreement E040.

Primary contract inspected locally (no SDK import or hardware call): official
Kinesis API help extracted from the official examples' CHM under ignored
 tmp/ethernet-research/kinesis-api/a07549.html and a07553.html. They document
SingleToggle/AutoToggle and RequestOperatingMode/RequestOperatingState. Installed
Thorlabs.MotionControl.KCube.Solenoid.h lines 650–709 corroborates request/get
pairs and valid Active=1, Inactive=2; numeric 0 is not a supported Inactive value.

Implemented only in production controller.py:
- Validated serial property, refusing retarget/clear while a handle is retained,
  including failed release. Successful release permits valid reselection.
- Explicit read-only requests for operating mode/state before cached feedback;
  share existing one-poll TTL wait, and allow one poll in operating-only reads.
  Removed the former pre-read wait from _wait_for_state to avoid adding a second
  intentional poll interval. Cache freshness and total native-call bounds remain
  unproven; asynchronous replies may still be delayed beyond this wait.
- Normalize documented SingleToggle to single and AutoToggle to auto. Unknown
  operating state/mode raises an error, faults normal status/Open and rejects
  connection with passive release. Do not reinterpret state 0 or alias serials.

15 new software regressions cover retained-handle relabel rejection/reselection,
invalid disconnected selection, both timed mode names, request-before-wait/cache
read ordering for full and operating-only reads, unknown feedback at Connect and
before Open, plus failures of each read request and passive connection cleanup.
The fake gained read-only request methods; it does not claim SDK cache fidelity.

Observed validation commands:
- .venv/Scripts/python.exe -m pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py
  -> 346 PASS in 1.52 s, including prior ownership/TTL/recovery/staged checks.
- Scoped ruff check and ruff format --check for controller.py, tests/conftest.py,
  tests/test_controller.py -> PASS after formatting only the changed code.

No hardware, SDK load, actuation, SDK/firmware/network configuration, dependency,
GUI, Ethernet implementation, build or publication operation occurred. E040/E041
remain historical prior-source measurements, not validation of this revision.
REQ-041 PASS for software scope; physical Stage 2 and Stage 3/4 remain BLOCKED.
Controller SHA256: 136cb52c13c1af3c08056386e55576682098ed71339091187e12b99a495b2032.
Test controller SHA256: 76e3896f632fe68c3ef8d5626c0f0ece8749acbf6b05332d2720d68fd6b6e6d0.


## E044

2026-10-20; REQ-042 / TEST-054: actual-hardware test-plan revision, requested by
user after E043's minimal controller change. Plan/documentation only; no SDK load,
hardware communication, cable action or actuation performed.

Updated docs/HARDWARE_VALIDATION.md and staged guide around actual configuration
and E040/E041 diagnostic failures, E042 observations and E043 source revision.
Known identities, SDK/driver and Ethernet endpoint are labeled as prior evidence;
current physical state is not invented. Next prepared bench path: refresh only
missing/changed prerequisite facts, operator restores USB IN after release,
enumerate, run one revised-source passive cycle, and stop on unresolved serial/
status failure. Three separately reviewed matching passive cycles are required
before first Close consideration. E040 is not a passing cycle. No aliasing,
experimental Enable, firmware/IP write or automatic retries to cure identity.

Stage 2D defines failure capture and bounded passive diagnosis/vendor packet.
Separate Stage 2E requires actual TCPIP cube identity/feedback, not hub identity or
open TCP port; production Ethernet handling remains absent/unqualified. USB-only
acceptance need not wait for Ethernet. Power/docking/wiring changes are not hidden
in either branch. Existing user power/manual-control/LED reports are preserved.

Stage 3 explicitly requires current Stage-2 PASS, target mapping, Close/Manual/
cleanup authority and independent Closed observation; already Closed is baseline,
not a closing transition. Stage 4 additionally requires Stage-3 PASS/review,
Enable/Open/Close authority and finite positive approved hold/duty/recovery
conditions. Prior proposed 1 s is not approved. Use the verified-target protected
block, not the tutorial's unconditional shutdown, for acceptance: Connect or
identity failure can retain a handle, so cleanup must remain passive until the
target and feedback were verified. Preserve operation+cleanup failure evidence,
check final Closed/Inactive/Manual feedback and separately observe physical
closure/release. No operator prompt while Open or maximum exposure guarantee.
Later stages retain per-stage review, their specific launch gates and scope.

Validation: extracted 5 Python plan blocks compile; assembled Stage-4 block
compiles. Ignored tmp/plan_review_check.py runs actual extracted blocks with
existing tests/conftest.py fake rig, no SDK: 8 cases PASS (first Close, one pair,
identity mismatch, mismatched retained handle, unknown feedback, operation plus
cleanup failure, failed Open and KeyboardInterrupt). Saved-file runner exit 0.
An earlier stdin runner printed completed assertions but returned 1; clean
saved-file rerun is the accepted process result. Local document links resolve;
git diff --check PASS. Machine-readable summary:
records/hardware-plan-review-2026-10-20.json.

TEST-054 PASS for revised procedure and software-only validation. Existing E043
346-test result remains scoped software evidence; no production changes in this
plan revision. Physical Stage 2 remains BLOCKED, Stage 3/4 unlaunched. This document
revision grants no new device-write or motion authority.


## E045

2026-10-20; REQ-043 / TEST-055: minimal explicit Ethernet transport implementation.
Authority: user's Ethernet-resolution request permits focused code changes and
actual passive communication only; shutter actuation stays held.

Added optional immutable ethernet_endpoint to KCubeShutter (IPv4 literal plus
KEH3 cube/USB OUT port 40304..40307). Construction remains passive. Discovery
activates only the selected local Kinesis manual entry and filters type-68
serials by GetTransportInfo provider TCPIP and exact endpoint. Recheck before
factory/Connect and during health checks; never fall back to USB/another bay.
Serial identity matching and cross-transport process ownership remain unchanged.
No dependency, CLI, GUI or hub configuration feature added. Local SDK entry is
retained; existing entries are not deleted. No persistent hub/IP write.

Ethernet health uses exact transport descriptor, IsConnected and CommsStatus OK;
default USB still checks USBConnected. An initially considered generic
GetConnectionState check was removed after E046 observed Connecting throughout
successful live hub reads/init/polling. That managed state is not assumed to
establish network health. Neither flags nor descriptor prove fresh feedback or
bounded cable-loss detection; physical qualification remains pending.

Installed SDK reflection confirmed CreateManualDeviceEntry(String),
GetTransportInfo(String), ScanEthernetRange(String,String,Int32,Int32), and generic
ConnectionStates enum. Primary local API help and official KEH3 manual from E041
support endpoint registration/routing. No unsupported firmware/protocol workaround.

17 new software cases: invalid endpoints before SDK access (including bytes),
passive Ethernet reads with USB disconnected, provider/wrong-port filtering,
transport change between discovery and factory, health loss/unknown feedback,
shared USB/Ethernet serial ownership and retained identity mismatch guard.
.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider --ignore=tests/test_sdk.py
-> 363 PASS in 0.98 s. Scoped Ruff lint/format PASS. Source SHA256:
304deeaf7c94abf2c12ed1678f3821a87a2783ff3018db845b4963d947358d03.
TEST-055 PASS for software handling only; no physical cube connection claimed.

## E046

2026-10-20; REQ-003/027/043 / TEST-056: actual passive Ethernet fault isolation.
User closed Kinesis after process 46996 was observed. Other shutter-repository
Python process 45780 was identified as editor isort LSP, not a controller owner;
no unrelated process was terminated. No cube USB entry was returned in current
present-only inventory. Human subsequently confirmed left bay and performed a
separate vendor-GUI discovery-only comparison after all our handles released.

Expected: cube responds to discovery/hardware-info on the correct endpoint and
matches selected serial before status; no output commands; all handles released.
Observed controlled distinctions:

- Fresh discovery after Kinesis closure activates existing :40303..:40307 entries;
  before/after sets identical. Only hub 120100261 TCPIP 192.168.1.19:40303 appears.
- Passive hub session held during targeted bay scan still discovers only hub.
  Read MAC D8:47:8F:93:68:CB, Ethernet status 141/0x8D (official flag mask has no
  setup-error bit), SDK GetBaysCount 4 (not interpreted as physical cube count).
- Complete hub settings initialization and 250 ms polling +750 ms wait still
  discovers only hub. IsConnected true while generic GetConnectionState remains
  Connecting. StopPolling/Disconnect succeed, IsConnected false afterward.
- New production endpoint path discovers [] for selected 68800777 at :40304;
  stops before factory/Connect. Passive disconnect completes with no handle.
  This is BLOCKED, not a successful cube connection/status cycle.
- Human confirms LEFT bay. Paired raw MGMSG_HW_REQ_INFO 0x0005 requests use the
  identical official bytes 05 00 00 00 50 01 on hub :40303 and left :40304.
  Hub returns 90 bytes: message 0x0006, 84-byte payload, serial 120100261/model
  KEH3. Left port accepts TCP but returns ZERO bytes before 2 s recv timeout.
  Each socket is context-released. This validates the passive packet against the
  hub, but does not identify which physical/firmware subsystem silences the cube.
- After all our SDK sessions/sockets were released, human runs Kinesis -> Connect
  -> Find device -> Known IP 192.168.1.19 -> Scan with USB absent, stopping before
  Connect or output controls. Human result: "only hub 120100261". This independent
  vendor-application result agrees with SDK discovery, not a Python-only defect.

Raw records: ethernet-resolution-discovery-2026-10-20.json,
ethernet-resolution-hub-session-2026-10-20.json,
ethernet-resolution-hub-initialized-2026-10-20.json,
ethernet-resolution-controller-2026-10-20.json,
ethernet-resolution-paired-hwinfo-2026-10-20.json, all under records/.
Summary: records/ethernet-resolution-summary-2026-10-20.json.
The production-path probe preceded only the final invalid-endpoint TypeError
handling refinement; valid endpoint discovery logic did not change afterward.

TEST-056 partial: hub passive identity/info/release PASS; cube discovery/readback
BLOCKED (bay read times out). No shutter/output, Enable, mode/TTL, firmware/IP,
power/docking command sent. All agent handles/sockets released; polling stopped.
Kinesis may now remain open after the human discovery comparison; recheck before
another SDK owner. Existing powered-display/manual-operation observations do not
prove the dock data link. Root cause among docking/data path, hub bridge and
firmware compatibility is NOT established; don't call a candidate a diagnosis.

Useful passive/software isolation is exhausted under current boundaries. REQ-043
remains BLOCKED, not complete. Prepared records/ethernet-support-case-2026-10-20.md
for owner/manufacturer review; nothing was sent externally. Resume with a
model/version-specific supported diagnostic/compatibility finding and approval
for any dependent physical/configuration operation. Preserve actuation hold.


## E047

2026-10-20; REQ-043 / TEST-057, official firmware investigation and GUI handoff.
User requested exact-version compatibility research and Kinesis discovery/passive
connection; firmware updates/actuation explicitly forbidden. Read official Motion
Control Firmware tab through browser; followed its vendor-linked change logs.

Observed documentation:
- Firmware Update Utility history 1.14.76 includes utility release 1.14.62,
  2025-07-24: KSC101 device firmware 1.0.7 fixes incorrect product serial numbers
  in hardware-info messages. This directly matches the class of E040 USB identity
  discrepancy, but release notes do not explicitly mention KEH discovery.
- KEH3 official page offers 1.1.2; history dates it 2025-09-23 and describes a
  static-IP startup fix after initial 1.1.1. No KSC-specific compatibility rule.
- Kinesis 1.14.60 vendor-linked history documents KEH support introduced in
  1.14.55. Installed SDK is later; no evidence of missing basic KEH support.
  Older KSC101 1.0.6 entry is wheel support. Utility version is not device version.
- Manual DOC-103012 Rev E sections 4.3/4.3.1 confirms one IP, hub port 40303,
  cube bay ports 40304–40306, USB IN absent. Section 6 recommends current cube
  firmware for the case of two identical cubes with only one detected; this is
  not an exact minimum-version statement for the present one-cube failure.

Official links are recorded in docs/ethernet-assessment.md, Firmware findings.
Read-only downloaded histories in ignored tmp/firmware-compatibility/:
controller-history.txt SHA256 92874538e24c415a3db9376ab1747e350ba2891e1b4e60e3aac62258e0882c95;
keh3-history.txt SHA256 e10facfcd0ec68c9ecf134e69d0b5f16f573c221f079b64429d4ba00e0a0e6c1.
No firmware installer, updater or image was run. No device configuration written.

GUI work used computer-use skill @oai/sky through node_repl. Launched installed
Kinesis, opened Connect/Find device. Known-IP masked entry could not be filled
reliably by the native input API; no entry or scan was falsely claimed successful.
Used documented available-port scan on local 192.168.1.0–192.168.1.255 instead.
Only hub 120100261 listed. Selected/connected this hub, observed Connected,
firmware 1.1.2, matching MAC; no KSC available. Screenshot:
records/kinesis-ethernet-hub-only-2026-10-20.jpg. AX included stale/hidden search
text; the visible dialog and resulting connected hub were used as UI evidence.
No Open/Close/Enable/Identify/settings action was selected.

User stopped computer use with physical Escape before another input; all further
UI automation stopped. User said they can operate Kinesis manually. Requested
manual discovery/passive controller connection only if available; current human
reply is "only hub". Cube connection remains BLOCKED; Kinesis may retain hub
ownership. Do not launch a competing SDK owner without release.

TEST-057 PASS for official-source investigation and confirmed GUI hub connection;
exact firmware-pair compatibility and Ethernet causality INCONCLUSIVE, physical
cube connection BLOCKED. KSC101 1.0.7 serial fix is the leading documented lead
for E040; whether it explains the silent bay remains an inference, not proven.
No firmware update, shutter actuation, production code change or new hardware
recovery operation occurred. Support packet updated, not sent externally.


## E048

2026-10-20; REQ-044 / TEST-058: prepare KSC101 1.0.7 firmware procedure for review.
User explicitly requests preparation including passive USB/Ethernet checks,
forbids firmware update now and keeps shutter actuation held. No new hardware
execution authority inferred. Created docs/KSC101_FIRMWARE_UPDATE_REVIEW.md;
linked it from hardware plan and support packet; checkpoint/report updated.

Official Motion Control Firmware page rechecked read-only through browser. X64
Firmware Update Utility 1.14.76 is for motion devices except KEH3/KEH6; published
installer hash 7856f76ad8911d2a29bf1ee097f77ba91f0c601fee190ec241c5366b04167c08.
This is not a KSC101 image hash. Existing E047 device release note remains the
basis for proposed 1.0.7. README button returned no readable document; actual
utility UI/help, payload/selection, update-through-hub support, bootloader and
recovery behavior remain UNVERIFIED. No installer downloaded/installed/run,
firmware flashed or hardware/USB/network interface accessed in preparation.

Procedure fixes target to KSC101 hardware 3, selected serial 68800777, 1.0.6 ->
1.0.7; hub 1.1.2, SDK/source unchanged. Requires vendor-supported identification
in the presence of hardware serial 26000000, exact firmware payload and no-auto-
flash behavior/recovery before execution. Includes package signature/hash checks,
settings evidence (not claimed restorable backup), ownership and operator cable/
power route, independent protection/observation and reset-output risk, explicit
programming approval immediately before the irreversible action. No guessed UI
button, raw flash command, firmware downgrade or automatic settings restoration.

Post-update USB verifies descriptor/hardware serial agreement and firmware 1.0.7,
known unchanged reported status, independent observations and passive release;
three separately reviewed cycles, no automatic loop. Ethernet follows USB release
and operator USB-IN removal; correct hub/cube discovery and exact TCPIP :40304
identity/status/readback/release must pass independently. Successful USB serial
repair does not pass silent Ethernet. All deliberate motion/TTL/GUI actuation and
loss injection stay held. Use current source/version hashes and fresh E records
for actual execution; this procedure result is not firmware or physical PASS.

Validation: three Python blocks compile; saved ignored helper
 tmp/firmware_update_plan_check.py extracts the actual blocks with existing fake
rigs. 16 software cases PASS (8 each USB and Ethernet): healthy, old firmware,
identity mismatch, unknown/changed feedback, request/release/combined failures;
assert no Enable/state/mode/TTL writes in fake logs, passive release or retained
handle evidence and preservation of combined errors. Initial helper wrongly used
the real bench serial against the fictional fixture and failed; corrected only
in-memory fixture substitution 68800777 -> 68000001, never the procedure/source.
PowerShell integrity-check block parses via AST only and is NOT executed. Local
links and git diff --check PASS. No production/test/dependency change; 363-test
software result E045 remains prior source evidence, not rerun hardware proof.

Machine-readable result and procedure hash:
records/firmware-update-plan-review-2026-10-20.json. TEST-058 PASS for preparation;
UPDATE/ACTUATION ON HOLD, REQ-043 physical communication still BLOCKED. Review the
procedure and resolve listed vendor gates before scheduling or granting a flash.

## E049

2026-10-20 local; TEST-059: actual passive USB resumption under the user's
USB-only continuation request in PROJECT.md. User confirmed "closed kinesis";
read-only process recheck found no Kinesis process. Windows PnP reports APT USB
Device USB\VID_0403&PID_FAF0\68800777, status OK. No rewiring by this program.

Method: syntax-checked ignored tmp/usb_resume_probe.py, then ran
.venv/Scripts/python.exe -i tmp/usb_resume_probe.py. Expected exact USB/FTDI
discovery, selected/hardware identity agreement, known unchanged passive status
and communication-only release; stop immediately on mismatch without retry.
Probe records production module path/hash, refuses non-USB transport and always
uses disconnect(close_shutter=False). No output/configuration/updater call.

Observed: SDK discovery [68800777], provider FTDI, empty COM specification.
Connect FAIL: "Device identity mismatch: selected 68800777; connected 26000000."
The subsequent identity/firmware/status reads were not reached. Passive release
COMPLETED, has_device_after_release false, elapsed 3.484 s; interactive process
exited with code 0 after exit(). No retained device owner or pending operation.
No independent physical blade observation supplied for this cycle; prior 1.0.6
firmware is historical, not remeasured. No automatic repeat, shutter command,
firmware update or production source change.

Raw evidence records/usb-resume-2026-10-20.json, UTC timestamp
2026-10-21T00:20:25.399598+00:00 (Oct 20 America/Chicago), source SHA256
304deeaf7c94abf2c12ed1678f3821a87a2783ff3018db845b4963d947358d03.
TEST-059 FAIL for passive controller acceptance; enumeration/release succeeded.
Stage 2 stopped for human review; Stages 3–4, update and actuation remain held.
Same mismatch as prior USB evidence supports pursuing E047/E048's documented
serial-fix/vendor gates, but does not prove Ethernet causality or authorize flash.

## E050

2026-10-20 local; REQ-045 (derived from user's newest KSC101 firmware request),
TEST-060 firmware/USB identity, TEST-061 production passive acceptance.
User superseded firmware hold with "update the KCS101 firmware to the newest"
and answered yes to independent source disable/block, stable power/USB,
acceptable reset/output changes, and printed serial 68800777. Deliberate shutter
actuation remains held. Proposed software identity workaround was not implemented.

Official x64 utility installer downloaded to ignored tmp/firmware-prep;
SHA256 7856f76ad8911d2a29bf1ee097f77ba91f0c601fee190ec241c5366b04167c08
matches published E048 value; Authenticode Valid, Thorlabs Inc. signer. Product
1.14.76.28950. Registry shows same version already installed in Program Files
(x86)/Thorlabs Firmware Update Utility; redundant installer upgrade canceled.
No new installation performed. Installed utility executable SHA256
437699afddb1c62c6462ad3ab1fc0174ef104f0b03eed77ab6539c26ae53e531;
CHM SHA256 aebb616377f0e0e0d7fc7e9b83f49db6dd4a8de6575de76cc88a7a10d4231891.
Installed history agrees with official 1.14.76 and lists latest KSC101 1.0.7.
Web fetch failed this turn; installed vendor files/package verification supplied
current evidence. No separate device-image hash/backup/rollback demonstrated.

Computer-use skill used for vendor UI. Existing utility initially empty, no
automatic flash; Discover Hardware identifies 68800777 KSC101 1.0.6 over current
KEH3 USB route. Help button errors file-not-found. Extracted installed CHM using
SysWOW64 hh.exe on a workspace copy; 64-bit reader produced no files. Vendor
Updating_Device_Firmware.htm specifies select device, Flash Firmware then OK,
follow status instructions, never remove power/close unless instructed and
rediscover after success. No model-specific interruption recovery proven.

Flash Firmware invoked ONCE on selected 68800777 under existing update authority.
ACTUAL behavior immediately starts Bootloading then Erasing Memory/Reprogramming;
no separate confirmation or proposed payload version appeared. This differs from
CHM; record this procedural limitation rather than claiming pre-flash image
verification. Monitored Writing To Memory 61%, then Target Device Has Been
Reprogrammed. No second flash, manual power cycle, cable/docking change, SDK/hub
update or output command. Rediscovery displays KSC101 68800777 V1.0.7.
Saved completion/version .jpg and .txt files in records. Exited updater before
any Python owner. Firmware reset may affect physical output; no independent
blade observation supplied and no claim of unchanged physical blade position.

TEST-060 PASS: tmp/post_update_usb.py performs one passive SDK discovery, exact
FTDI check, connect/poll/GetDeviceInfo and status/mode/state requests, then
StopPolling/Disconnect. No native unsuccessful diagnostic or setter used.
records/firmware-post-usb-2026-10-20.json: firmware 1.0.7, hardware 3, all three
hardware serial fields and selected identity 68800777. Closed / Inactive /
SingleToggle, key true, bits 8192, CommsStatus OK, errors [], release COMPLETED.
This demonstrates repaired hardware-info serial; no software alias/bypass.

TEST-061 FAIL: one subsequent unchanged production passive cycle, source SHA256
304deeaf7c94abf2c12ed1678f3821a87a2783ff3018db845b4963d947358d03.
records/firmware-post-production-usb-2026-10-20.json: discovery 68800777 FTDI;
identity guard passed, then Connect failed: USB connection lost; disconnect and
reconnect. This guard checks IsConnected and USBConnected; exact failing member
not captured. No diagnosis that actual USB was disconnected is established.
3.828 s, passive release COMPLETED, no handle retained. Both REPLs exited;
no automatic retry. Stage 2 remains FAIL; next review concerns USB health/timing,
Ethernet not retested after firmware change. No source change or fresh software
suite required for this hardware-only update. Firmware request satisfied;
whole hardware project and actuation acceptance remain incomplete.

## E051

2026-10-20; REQ-046 / TEST-062: user reports "stage 2 passed. implement stage 3
and 4". Record the stage result as human-reported PASS, preserving TEST-061's
last production USB failure. No new production PASS log, physical observation or
changed transport conditions supplied. Implement/review authority does not
launch physical Close/Open; no hardware access, SDK load or output command here.

Added docs/hardware_tests/stage_3.py first_close and stage_4.py open_close_pair,
sharing one private lifecycle. Complete bench, exact serial, reviewed physical
prior-stage PASS/evidence and disconnected-owner prerequisites. Stage 4 also
requires explicit finite positive hold; never adopts the proposed 1 s default.
Connect/identity/fresh known feedback must agree before verified-target output
and cleanup Close. Stage 3 first Close, Stage 4 initial Close/Open/hold/Close;
check returned feedback and final full status. No prompt while Open, retry,
automatic next stage, live CLI or automatic controller construction.

Unknown/failed connection/identity gets communication-only release. Verified
target cleanup may Close even after operation faults; both errors preserved.
BaseException interrupts get cleanup then propagate with result note. Caller
retains object for diagnosis; no extra post-error probe. READBACK_CAPTURED is
reported-data scope only, physical_test_status always UNTESTED. Operator must
provide physical observations and stage review separately.

Initial new-test run exposed that close/open return operating feedback without
TTL settings (by intentional driver design). Corrected motion-result checks to
verify healthy exact target, known safeguards and exact expected state/mode;
pre-motion/final full reads still require known TTL configuration. Existing-owner
test expectation corrected to allow passive get_status reads while forbidding
any connect/release/output. No production driver guard changed.

35 software-device cases PASS: healthy stages, missing/wrong review, incomplete
bench, invalid hold, existing owner, bad identity/unknown/connect faults, combined
operation/release errors, interrupt while Open, Enable failure. Exactly one
Active request on healthy Stage 4, none on Stage 3. Command:
.venv/Scripts/python.exe -m pytest -q --ignore=tests/test_sdk.py -p no:cacheprovider
398 PASS in 1.26 s. Scoped Ruff check/format PASS. Live SDK test excluded to
preserve hardware hold; no physical acceptance inferred. Guide/plan/checkpoint
updated. Stop for human review; resolve conflicting USB evidence before launch,
Stage 3 physical PASS/review before Stage 4, then review before Stage 5.

## E052

2026-10-20 local; TEST-063 passive USB health diagnosis before Stage-3 launch.
User requests hardware tests, then "read from status. do the hardware tests".
This authorizes electronic reads and test work within established prerequisite
and stage-review boundaries. No Kinesis/FirmwareUpdateUtility process found.
Source unchanged from E050. No independent physical state/recovery facts invented.

Ignored tmp/usb_health_probe.py adapts the reviewed passive post-update probe:
exact FTDI 68800777, Connect, capture IsConnected/USBConnected/CommsStatus/
GetConnectionState, initialize/poll, capture again after 0.5 s; read hardware
info, request status/operating mode/state, wait 0.25 s, read electronic feedback,
StopPolling/Disconnect. No output, Enable, mode/TTL setter or updater call.

records/usb-health-diagnostic-2026-10-20.json: no errors. Both samples show
IsConnected true, USBConnected Connecting, CommsStatus OK, GetConnectionState
Connecting. Identity 68800777 in all hardware fields, hardware 3, firmware 1.0.7.
Closed / Inactive / SingleToggle, key true, status bits 8192 (0x1000 interlock
mask clear). This identifies the failing production comparison, not a proven
physical disconnection or justification to accept Connecting for motion.
No proof of independent blade position, current trigger wiring or physical
shutdown method. Passive release COMPLETED, REPL exited with code 0.

TEST-063 PASS diagnostic scope only. Stage 3 BLOCKED before actuation by unresolved
production connection health and incomplete physical bench record; Stage 4
UNTESTED pending Stage-3 physical PASS/review. No automatic cycle retry or guard
bypass. Next useful work: establish SDK health-state semantics/timing and validate
a supported correction against healthy/lost communication, then reconsider
motion launch under actual bench conditions. No production code changed here.

## E053

2026-10-20 local; REQ-047 / TEST-064: user requests quick USB health resolution.
Official GitHub fetch failed; extracted installed vendor DotNet_API.chm using
SysWOW64 hh.exe into ignored tmp/sdk-health/help. API IGenericCoreDeviceCLI:
CommsStatus page a05620_af4f5155b49e3b2d74d8d9fa9b815be5d.html defines OK as
working communication; IsConnected as connected and ready for commands. Its
example uses IsConnected after Connect. USBConnected page
a05620_a048612bc3f85e34cff6cb3f55a9ad8e1.html describes initialization enum;
SetUSBConnectionState page a05620_a11e02ca0b269856b096eb09d20f7c525.html marks
setter INTERNAL USE ONLY. No setter used. E052 empirically shows ready/OK and
successful identity/status while enum remains Connecting. Exact internal cause
of enum persistence unknown; do not claim vendor explicitly guarantees it.

Minimal _check_connection change: allow Connected or Connecting for USB only
when IsConnected true and CommsStatus OK; reject Disconnected and other enum
values. Existing request failures, exact identity, fault latch and output guards
preserved. Six new software regressions cover passive Connecting success,
not-ready, timeout, error, request failure and PreConnecting rejection; failed
status inhibits Open without output writes. Existing Disconnected tests pass.
404 offline tests PASS in 0.94 s, tests/test_sdk.py excluded to avoid unplanned
access. Scoped Ruff check/format PASS. Production source SHA256
1d1914a72e5c742a858ca25d2557099b995b2645dcddadcc08d5f4304d56ae5b.

No Kinesis/updater owner found. One production passive USB cycle via ignored
tmp/usb_health_fixed_probe.py, reviewed lifecycle copied to distinct evidence:
records/usb-health-fix-passive-2026-10-20.json. FTDI discovery68800777,
Connect/identity/full status PASS, firmware1.0.7 hardware3, Closed/Inactive/single,
key true, interlock false, TRIG1 input/high TRIG2 output/high. Initial and final
feedback unchanged; errors []; 4.312 s, passive release COMPLETED, no retained
handle. No actuation/Enable/mode/TTL setter/update. Independent blade observation
not supplied; no physical loss injection or latency qualification performed.
TEST-064 PASS for correction and one passive cycle; no automatic stage advance,
no three-cycle physical PASS or Stage-3/4 result claimed. Open still blocked by
reported interlock false. Preserve independent recovery/bench prerequisites.

## E054

2026-10-20; TEST-065: user specifies Stage 3 status read before motion control.
Inspected helper: already Connect/identity then fresh pre_motion get_status before
verified=True and Close. Added distinct error phase for that read and two
software regressions asserting order and no Close/cleanup output on read failure.
37 motion-helper cases PASS in 0.06 s, scoped Ruff PASS. No production change,
hardware read or motion launched. Stage 3 remains first Close only, Stage 4
Open/Close requires separate Stage-3 physical result/review.

## E055

2026-10-20 local; TEST-066: user explicitly says "do hardware run" after directing
Stage 3 status then motion. Single Close-only launch interpreted within prior
source-block/stable wiring/observation conditions and stage-review sequence.
No Kinesis/FirmwareUpdateUtility process found. Stage-2 human approval and E053
production passive success precede launch; no Stage-4 Open authority inferred.

Used reviewed HARDWARE_VALIDATION section-3 protected REPL procedure in ignored
tmp/stage3_hardware_run.py, AST parsed before execution. Did not fabricate missing
bench fields or invoke/override complete-bench helper. This is a bounded functional
Close/readback run under direct user authority, not a complete bench acceptance.
Exact FTDI serial68800777, firmware1.0.7, identity/fresh full status required
before verified=True permits Close/Inactive and Manual. Cleanup Close only after
verification; otherwise passive release, both errors retained. One cycle only.

records/stage3-hardware-2026-10-20.json, production source SHA256
1d1914a72e5c742a858ca25d2557099b995b2645dcddadcc08d5f4304d56ae5b:
pre-motion connected Closed/Inactive/single, key true, interlock false,
TRIG1 input/high TRIG2 output/high. Close and final full status Closed/Inactive/
manual. No errors, communication release COMPLETED, no handle, 5.985 s. Cleanup
also attempted authorized Close. No Enable/Active/Open/TTL setter/update.
Already Closed means no physical closing transition demonstrated. No independent
blade observation supplied yet; requested final Closed/unexpected-motion report.
TEST-066 PASS for command/readback/release only, physical result pending review.
Stage 4 not launched, reported interlock false continues to inhibit Open.

## E056

2026-10-20; TEST-067: user requests shutter Open/Close sequence and responds
10 seconds to added Open hold question. Existing source-block/observation
conditions preserved. No Kinesis/updater process found. Before output, inspected
official installed Thorlabs.MotionControl.KCube.Solenoid.h lines639–640: interlock
bit0x1000 explicitly 1=Enabled/0=Disabled, 0x2000 not used. SDK API SolenoidStatus
has KeyEnabled separately. No evidence supporting inversion/substitution/bypass.

One passive production precheck via ignored tmp/sequence_precheck.py;
records/sequence-precheck-2026-10-20.json: FTDI68800777, hardware3 firmware1.0.7,
Closed/Inactive/manual, key true, interlock false in initial and final samples,
TRIG1 input/high TRIG2 output/high unchanged. No errors, 4.328 s, passive release
COMPLETED/no retained handle. No Enable/Open/state/mode/TTL setter/update issued.
TEST-067 PASS for precheck, Stage 4 BLOCKED by disabled interlock. Approved10s
hold not executed; it would begin after Open feedback, not cap total exposure.
Requested operator normal interlock-circuit check via manufacturer procedure,
no bypass/no powered connector change, then return resulting condition before
fresh read and any Open. Stage-3 physical observation still not supplied.

## E057

2026-10-20; TEST-068: human replies "abled" to the interlock check request.
Exact physical intervention unknown, not recorded as a verified enabled state.
Prepared one guarded status-first Open/10s/Close protected REPL procedure,
including both key/interlock true check BEFORE initial Close/verified cleanup
authorization. AST parses. Initial shell generation failed quoting before Python
or hardware ran; generated via ignored prepare_stage4_probe.py instead, no
production code change. One actual attempt only, no automatic repeat.

records/stage4-hardware-2026-10-20.json: correct USB68800777 firmware1.0.7,
fresh status Closed/Inactive/manual, key true, interlock false. Pre-motion guard
raises Open blocked: key or interlock not enabled; no output. verified false,
passive release COMPLETED/no handle, 4.297 s. No Close/Enable/Open/state/mode/TTL
setter/update. Approved10s hold never reached. TEST-068 records successful
safeguard refusal; requested physical sequence BLOCKED/UNTESTED, not PASS.
Status remains contradictory to any interpretation of human reply as enabled;
do not replace hardware feedback with that reply or override guard. No further
retry pending physical interlock diagnosis or supported evidence of reporting
error; Stage-3 independent observation still absent.

## E058

2026-10-20; TEST-069: user reports "interlock abled". Interpreted as a changed
condition to verify, not authority to override the electronic safeguard. One
fresh attempt using the unchanged guarded Stage-4 procedure with distinct output
records/stage4-interlock-recheck-2026-10-20.json. No competing Kinesis/updater
process found. USB68800777 / firmware1.0.7, Closed/Inactive/manual, key true,
interlock false in connection and fresh pre-motion samples. Guard refuses before
any Close/Enable/Open/state/mode/TTL setter. 10 s hold not reached, passive
release COMPLETED/no handle, 4.328 s. No source/firmware change. Stage4 BLOCKED,
physical sequence UNTESTED. Do not repeat unchanged reads as a resolution;
diagnose normal circuit versus vendor reporting under approved conditions.

## E059

2026-10-20; TEST-070: explicit user "check again" authorizes one passive status
recheck. No competing Kinesis/updater process found. Distinct record
records/interlock-status-check-2026-10-20.json: FTDI68800777, firmware1.0.7,
hardware3, stable Closed/Inactive/manual, key true, interlock false in initial/
final samples. TRIG1 input/high and TRIG2 output/high unchanged. Errors [],
4.313 s, passive release COMPLETED/no retained handle. No shutter/output,
configuration or firmware command. Diagnostic capture PASS, Open/sequence still
BLOCKED; no physical acceptance or status interpretation change inferred.

## E060

2026-10-20; TEST-071: user again requests passive recheck. No Kinesis/updater
owner found. One distinct cycle, records/interlock-status-check-2-2026-10-20.json:
FTDI68800777 / firmware1.0.7 hardware3, both status samples Closed/Inactive/manual,
key true, interlock false, unchanged trigger configuration. No errors, 4.171 s,
passive release COMPLETED/no handle. No output/configuration/update. Capture
PASS; Open remains BLOCKED. No automatic repetition or weakened safeguard.

## E061

2026-10-20; TEST-072: user requests another passive check. No Kinesis/updater
owner found. One cycle: records/interlock-status-check-3-2026-10-20.json,
UTC2026-10-21T00:47:35.085629+00:00 (Oct20 local). FTDI68800777 firmware1.0.7
hardware3, both samples Closed/Inactive/manual, key true, interlock false,
unchanged trigger configuration. Errors [], elapsed4.313 s, passive release
COMPLETED/no handle. No output/configuration/update. Capture PASS, Open BLOCKED.

## E062

2026-10-20; TEST-073: user suspects command problem. Audited production sequence
RequestStatus -> RequestOperatingMode/State -> trigger read/wait -> GetStatusBits.
Installed KSC101 native header SC_RequestStatus and SC_RequestStatusBits both
document status-bit refresh; GetStatusBits documents0x1000 interlock. Installed
.NET KSC101-specific GetStatusBits/RequestStatus/RequestStatusBits pages agree.
SolenoidStatus class exposes KeyEnabled, OperatingMode/State, SolenoidState,
ToggleCount; no separate Interlock property. GetMasks relates logging only, not
status mapping. No internal setter or Enable used as a diagnostic.

Official web search found vendor interlock description and protocol manual;
protocol fetch failed DNS/502. No claim of independent protocol verification.
Sources: https://www.thorlabs.com/catalogpages/Obsolete/2025/SC10.pdf (KSC101
interlock connector description); attempted
https://punchout.thorlabs.com/Software/Motion%20Control/APT_Communications_Protocol.pdf.

One passive comparison on USB68800777 via tmp/compare_status_requests.py,
records/status-request-comparison-2026-10-20.json. Three measurements within one
session: production RequestStatus/polling; StopPolling, RequestStatusBits and
0.5s wait; RequestStatus and0.5s wait. All8192/0x2000, documented interlock bit
clear, structured KeyEnabledTrue, Closed/Inactive/Manual, ToggleCount0,
IsConnectedTrue/CommsStatusOK. Errors[], release COMPLETED/no retained handle.
No configuration, output, firmware update, production change or mask override.

TEST-073 PASS diagnostic scope; no request-method difference or proven driver
defect. Agreement does not prove hardware freshness/circuit condition or exclude
vendor reporting/mapping defects. Correct earlier shorthand: controller-reported
interlock bit is clear, physical interlock disablement is not independently
established. Open remains BLOCKED pending supported resolution. No more identical
reads as a claimed resolution; seek independent physical/vendor reporting evidence.

## E063

2026-10-20; TEST-074 open/closed interlock A/B comparison requested by user.
User defines without3.5mm jack as circuit open, withjack as closed; currently
open. This describes circuit condition, not an instruction to open shutter.
One passive baseline using same RequestStatus/polling then stopped-polling
RequestStatusBits and RequestStatus with0.5s waits. Initial script-generation
quoting error occurred before hardware access; corrected via Python builder,
no production change. All baseline samples8192/0x2000, KeyEnabledTrue,
Closed/Inactive/Manual, IsConnectedTrue, CommsStatusOK, errors[].
records/interlock-ab-open-2026-10-20.json explicitly labels human-reported circuit
open/jack removed. Release COMPLETED/no handle. No output/configuration/update.
Asked operator to perform approved power-down, install normal interlock jack,
restore power and report ready, retaining source block; no powered rewiring.
Second condition not captured yet; comparison PENDING, no conclusion/mask fix.

## E064

2026-10-20; TEST-074 second-condition capture. User says 3.5mm jack plugged in,
then clarifies "I changed to automode". Do not attribute mode change to firmware,
power cycling or our command. No process owner found. Same production comparison
attempt refuses Connect before samples: Unknown operating feedback state0/mode
auto, release COMPLETED/no handle. Saved interlock-ab-closed-2026-10-20.json.

To isolate raw status without changing production guard, performed one read-only
SDK identity/status diagnostic (tmp/interlock_closed_raw.py). Exact FTDI68800777,
firmware1.0.7 hardware3. RequestStatus with polling, then stopped-polling explicit
RequestStatusBits and RequestStatus with0.5s waits; all8192/0x2000, documented
0x1000 clear, KeyEnabledTrue, Closed, AutoToggle, operating0, ready/CommsOK.
Errors[], release COMPLETED/no retained handle. Saved
records/interlock-ab-closed-raw-2026-10-20.json. Unknown0 remains unknown; no
Enable/Open/Close/state/mode/TTL setter or firmware change. All REPLs exited.

Compared E063 open-condition Manual/Inactive0x2000 versus installed-jack Auto/0
0x2000: XOR0x0000, no status-bit difference in measured conditions. User's mode
change means this is not a controlled one-variable experiment. Jack insertion
is human-reported, electrical continuity not independently measured. No proof
that interlock bit tracks either circuit state or is wrongly mapped; do not
invert or relabel it from identical readings. TEST-074 INCONCLUSIVE for physical
interlock diagnosis, capture complete. Summary
records/interlock-ab-summary-2026-10-20.json. Meaningful next experiment holds
mode/key fixed, or independent/vendor evidence verifies reporting. No automatic
motion launch; Stage4 remains BLOCKED.

## E065

2026-10-20; TEST-075 user labels current physical condition "jacked installed.
key unlocked". One passive raw status diagnostic, no other Kinesis/updater owner.
records/interlock-key-unlocked-2026-10-20.json: exact68800777 firmware1.0.7
hardware3, three samples(RequestStatus/polling, stopped-polling RequestStatusBits,
stopped-polling RequestStatus) all8192/0x2000, KeyEnabledTrue, Closed, AutoToggle,
operating0, IsConnectedTrue/CommsStatusOK. No errors, release COMPLETED/no handle.
No output/configuration/update. Baseline capture PASS; key-OFF condition not
captured, physical interlock diagnosis INCONCLUSIVE. Preserve same jack and mode
for any operator key-locked comparison, with source independently blocked.

## E066

2026-10-20; TEST-075 second key condition. User reports jack installed/key locked.
No competing owner found. One passive diagnostic, same requests and0.5s waits as
unlocked baseline, records/interlock-key-locked-2026-10-20.json. All three samples
0x0000, KeyEnabledFalse, Closed/AutoToggle/operating0, IsConnectedTrue/CommsStatusOK,
exact68800777 firmware1.0.7 hardware3. Errors[], release COMPLETED/no handle.
No output/configuration/update. Both REPLs exited normally.

Compared E065 jack-installed/key-unlocked0x2000/True versus now0x0000/False,
Auto mode/Closed/unknown operation0 unchanged. XOR0x2000: observed bit13 and
structured KeyEnabled correlate with human-labelled key change. TEST-075 PASS
for key-state discrimination, not electrical calibration/interlock proof. This
supports status responding to a physical key change; does not establish freshness
of every other cached field. SDK header/GetStatusBits table labels0x2000 unused,
an observed documentation discrepancy worth vendor confirmation; never substitute
it for interlock0x1000 or invert safety interpretation. Key now OFF additionally
blocks motion; unknown0 guard remains. Summary
records/interlock-key-comparison-2026-10-20.json. Physical jack/interlock mapping
still unresolved, no production fix or further motion inferred.

## E067

2026-10-20; TEST-076: user reports jack removed, key locked, Auto mode unchanged
and requests check. One passive SDK cycle, no Kinesis/updater owner found.
records/interlock-jack-removed-key-locked-2026-10-20.json: exact68800777,
firmware1.0.7 hardware3; all three request samples0x0000/KeyEnabledFalse,
Closed/AutoToggle/operating0, IsConnectedTrue/CommsStatusOK. Errors[], release
COMPLETED/no handle. No output/configuration/update. Compared E066 jack installed
with same locked key/Auto mode: identical bits and structured status, XOR0.
PASS capture, no jack-induced bit change observed while key OFF; do not infer
physical continuity or reporting when key ON. Interlock mapping INCONCLUSIVE.

## E068

2026-10-20; TEST-077: user reports jack removed/key unlocked/Auto unchanged.
No Kinesis/updater owner found. One passive SDK capture, three request paths
as E065–067, records/interlock-jack-removed-key-unlocked-2026-10-20.json:
68800777 firmware1.0.7 hardware3; all0x2000/KeyEnabledTrue, Closed/AutoToggle/
operating0, IsConnectedTrue/CommsStatusOK, errors[], release COMPLETED/no handle.
No output/configuration/update. REPL exited normally.

Four Auto-mode conditions now captured: jack installed/unlocked0x2000/True,
installed/locked0/False, removed/locked0/False, removed/unlocked0x2000/True.
Key XOR0x2000 under either jack condition; jack XOR0 under either key condition.
TEST-077 PASS comparative capture; no jack-related bit change observed. This
supports key correlation, not proof of physical interlock state/behavior, correct
interlock mask or cache freshness for every field. No guard removal/substitution
justified. Unknown operation0 also remains a motion gate. Summary
records/interlock-four-state-comparison-2026-10-20.json. Vendor/raw-protocol or
approved electrical evidence needed next; do not repeatedly retry motion.

## E069

2026-10-20 local; TEST-078: explicit user recheck, jack installed/key unlocked.
No competing Kinesis/updater owner found. One passive SDK comparison cycle:
records/interlock-key-unlocked-recheck-2026-10-20.json; three samples0x2000,
KeyEnabledTrue, Closed/AutoToggle/operating0, ready/CommsOK, 68800777 firmware1.0.7
hardware3. Errors[], release COMPLETED/no handle. No output/configuration/update.
Capture PASS, no change to matrix or unresolved interlock/unknown-state motion
gates. No code change or inference that physical jack circuit is disabled.

## E070

2026-10-20; REQ-048 / TEST-079: holistic command review and correction requested.
Downloaded/read official KSC101 manual HA0368T RevD June2023 (45pages), SHA256
b51ac9ca1aa53b02b554dfd5b1c0bd4b99d73e4ba092e47170a64a3f4bab34f5,
tmp/command-review/ksc101-manual.pdf/.txt. Sections3.3.1/3.4.2 (pages13/17)
state no powered jack changes and contact carries solenoid drive current;
4.2/4.3 (pages19/20) separate key and Manual/Single/Auto/Trigger. APT software
portions are legacy. No manual evidence of an independently sensed jack flag.

Cross-read installed .NET KSC101 SolenoidStatus, RequestStatus/RequestStatusBits/
GetStatusBits, operating enums and nativeheader; GetStatusBits0x1000 definition
is documented, but0x2000 unused table conflicts with E065–068 correlation. Read
official Thorlabs Python.NET example downloaded from main, never executed:
Connect/settings/polling/Enable/Manual/Active/Inactive supports method names,
not safe-state proof. Full official protocol URLs returned HTML/DNS/502; only
indexed vendor SOL_STATE excerpt (On1/Off2) available. Do not claim full protocol
or wire-level validation. Source links/limits in docs/COMMAND_REVIEW.md.

Supported correction: interlock_enabled True for documented positive0x1000,
None when clear/unverified rather than claim physical disabled; raw status_bits
added on healthy snapshots. Open/Arm error says key/interlock not confirmed
enabled, GUI naturally shows unknown/disables them. No interlock override or
key substitution. Fault snapshots retain unknown values. Tests cover raw0/0x2000,
positive0x3000, no output on Open/Arm refusal, GUI unknown and both controls
disabled. Existing changed-during-request test expects unknown after clear bit.
RequestStatus unchanged because direct comparison did not differ. Unknown
operating0 remains error; not relabeled Inactive. Existing verified preparation
Inactive -> Closed/Inactive -> Manual -> verified Manual and cleanup retained.

410 offline tests PASS in1.13s, live SDK test excluded; scoped Ruff/format and
diff checks PASS. Source SHA256
8ff3c5d8d48abc9901993a4e4b860a931817aea7aaebbbf3a74e98504a9d589b.
No hardware/device access, actuation, configuration or firmware change. Current
source physical validation UNTESTED; retain historical records without claiming
they validate revised semantics. Firmware/SDK status reporting and operating0
remain unresolved; no automatically launched bench test. TEST-079 PASS review/
software scope. Prior Stage3 baseline did not demonstrate a closing transition;
no completed10s Open cycle exists. No contacts/messages sent externally.

## D017

2026-10-20; REQ-048, E070: represent clear/unverified interlock indication as
unknown, retain raw SDK bits and all output refusal gates. This corrects the
unsupported inference of physical disabled circuit while preserving safety and
diagnostic evidence. Positive bit remains a vendor-defined reported indication,
not independent continuity proof. Do not infer0x2000 interlock from key correlation,
do not normalize undefined operating0 or force SDK connection state. Physical
acceptance requires supported reporting contract plus fresh independent evidence.

## E071

2026-10-20; TEST-080: user requests Stage3/4 hardware runs. Under existing
status-first and stage-review constraints, attempted Stage3 first using the
reviewed protected REPL procedure, distinct evidence path; no preflight fabrication
or guard override. No Kinesis/updater owner found. Production source SHA256
8ff3c5d8d48abc9901993a4e4b860a931817aea7aaebbbf3a74e98504a9d589b.
records/stage3-reviewed-source-2026-10-20.json: discovery68800777; Connect error
Unknown operating feedback state0/modeauto. verified false, no Close/Open/Enable
or mode/TTL/update command, passive release COMPLETED/no handle,4.125s. REPL
exited normally. Stage3 attempt FAIL at feedback prerequisite, physical motion
UNTESTED; Stage4 BLOCKED/not launched. No automatic repeat or state0 alias.
This establishes current-source production refusal, not fresh interlock data or
physical controller fault. Auto operation0 and interlock reporting require
supported resolution before progression; prior source/configuration evidence
does not validate this failed run. No code or firmware modification.

## E072

2026-10-20; REQ-049 / TEST-081: user explicitly removes Stage7 as unnecessary
after extensive testing. Removed its dedicated twenty-cycle-per-pair procedure
and threshold from docs/HARDWARE_VALIDATION.md, updated REQ004/005 stage mappings,
Stage4 follow-up wording and Stage9/10 prerequisites to0–6 plus8. Kept stage numbers
8–10 stable and historical records intact. PROJECT.md records accepted scope
change; not a physical PASS or claim that prior passive reads prove repeatability.
Remaining functional/shutdown/GUI/fault/multi-pair criteria unchanged. Static
reference review and git diff --check; no software test needed for prose-only
scope revision. No hardware access/code change. E071 blockers remain unresolved.

## E073

2026-10-20; TEST-082: user resets test status and requests Stage3/4 hardware
runs. Assumed reset scope current Stage3/4 results; no deletion of evidence,
factory reset, firmware/configuration change or safeguard override. Created
records/current-hardware-tests.json with UNTESTED before fresh attempt and
updated it from observed result. Stage7 remains REMOVED_BY_USER.

Reconciled prior deliberate interruption before device access: no Kinesis/
updater or shutter-run Python process found; PID45780 is VSCode isort LSP, not
controller owner. No Stage5/6 command was launched by resumed task. One actual
Stage3 status-first attempt, current production SHA256
8ff3c5d8d48abc9901993a4e4b860a931817aea7aaebbbf3a74e98504a9d589b,
saved records/stage3-reset-run-2026-10-20.json. Discovery68800777; Connect fails
Unknown operating feedback state0/modeauto. No verified output authorization,
Close/Open/Enable/state/mode/TTL setter not issued. Passive release COMPLETED,
no handle,4.109s, REPL exited normally. Stage3 FAIL at prerequisite, physical
motion UNTESTED; Stage4 BLOCKED/not launched. No automatic retry or guessed0
mapping. Reset bookkeeping completed; requested motion remains unfulfilled due
to unresolved real feedback, not stale test status. No code change; static JSON
and diff checks only, no new software test needed for records.

## E074

2026-10-20; TEST-083: user says Auto is Auto, asks testing other commands and
states device fine; then explicitly confirms physical interlock enabled. Record
that as human-reported condition; no longer describe physical circuit disabled.
No assumption of independently validated SDK bit, hidden override or motion-ready
state0. This steering authorizes alternative official SDK reads and previously
authorized Close/Inactive/Manual diagnostic, not a production acceptance shortcut.

AST-checked ignored tmp/other_commands_close.py uses exact FTDI68800777, verifies
GetDeviceInfo serial/model KSC101, initialization/ready/CommsOK and captures
pre-command raw feedback. Performs Request/GetCycleParams and Request/GetTrigger-
ConfigParams only, then explicit Inactive, polls at250ms up to5s for Closed/
Inactive; only after that selects Manual and verifies Closed/Inactive/Manual.
On failure after Close attempt, guarded Inactive cleanup; always release. No
Enable/Active/Open or trigger/persistent/firmware setter. Existing independent
source-block conditions and Close launch authority retained.

records/sdk-other-commands-close-2026-10-20.json: identity68800777 firmware1.0.7
hardware3. Before Closed/AutoToggle/operation0/keyTrue/bits8192/ready/CommsOK.
Cycle params5cycles, OpenTime2000/ClosedTime2000 vendor millisecond values;
TRIG1 input/high TRIG2 output/high. After Inactive Closed/Inactive/AutoToggle;
after Manual Closed/Inactive/Manual. Bits8192/keyTrue unchanged. Errors[],
release COMPLETED/no retained handle; REPL exited normally.
TEST-083 PASS for SDK read/Close commands and reported feedback only. Already
Closed does not show physical closing transition; no full production stage-helper
PASS, Stage4 or actual Open cycle. Production source/guards unchanged. State0
not reinterpreted: command establishes defined Inactive. Auto is supported and
this does not establish hardware fault. Preserve separate diagnostic evidence in
current-hardware-tests.json; stop for stage review, no automatic Open sequence.

## E075

2026-10-20; TEST-084: user requests Stage3/4 again after E074 Close result and
then "control the shutter". Physical interlock enabled confirmation and
independent source block retained. User replaces prior10s pair with explicit
Open2s/Close2s five cycles. Automatic approval review rejected old10s CreateProcess
because it materially differed from latest operation; no process started or old
result file created. Reported rejection to user. Did not reroute old operation;
corrected concrete script to new exact authorized sequence before retrying.

Ignored tmp/sdk_five_cycle_run.py: verify exact FTDI68800777/KSC101/hardware3/
firmware1.0.7, fresh ready/CommsOK/key/known shutter/mode. Explicit Inactive,
confirm Closed/Inactive, then Manual and confirm. Before each Open require
Closed/Inactive/Manual/keyTrue. Enable once,5 requested Active/Inactive pairs,
each waited for Open/Active and Closed/Inactive feedback, then2s added hold.
Stop on first failure; guarded Inactive cleanup and release, no failed-cycle
retry. Direct official SDK bench run relies on explicitly human-confirmed
physical interlock, not an assertion that unverified SDK bit is enabled. No
hardware interlock alteration or production-code guard change.

Software-only check of exact generated script via fake SDK: healthy5Active
requests/ten2s sleeps/final Closed/released; Open-feedback failure stops after
one Active with cleanup; interrupted hold closes/releases before propagation.
All3 fake scenarios PASS. Then corrected physical operation approved/executed
once. No competing Kinesis/updater process found.

Raw records/sdk-five-cycles-2s-2026-10-20.json: Stage3 readbackPASS; every cycle
Open/Active/Manual bits8193 (0x2001) then Closed/Inactive/Manual bits8192 (0x2000),
keyTrue, ready/CommsOK. Open added holds2.000–2.016s, Closed added holds2.000s
by host monotonic measurement. Command-to-feedback waits/polling mean these
are not calibrated blade/exposure times. Completed5cycles, errors[], cleanup
Closed/Inactive/Manual, release COMPLETED/no retained handle. REPL exited.
No trigger/cycle-parameter/persistent setting/firmware changes. Runtime Manual
selection and Enable/Active/Inactive were explicitly authorized for this run.

User subsequently: "confirmed the shutter followed the sequence." Saved separate
records/sdk-five-cycles-observation-2026-10-20.json; do not mutate raw pre-observation
trace. TEST-084 PASS for requested SDK hardware functionality plus human-observed
sequence. Stage3 Close baseline/Stage4 five-cycle functional results updated in
current-hardware-tests.json; historical production failure preserved. This does
not qualify production class/GUI interlock interpretation or physical-loss
timing. Stage7 stays removed; no automatic subsequent stage/repeat. No pending
owner or operation, final reported state Closed/Inactive/Manual.

## D018 / E076 — TEST-085 (software)

2026-10-20: user explicitly removes GUI/hardware holds while requesting autonomous
Stage5/6. Use earlier physical interlock/source protection confirmation for exact
68800777 as session-only readiness evidence when SDK interlock remains unknown.
No physical interlock command, bit substitution or false enabled readback. Added
confirm_interlock(serial) before connection, selected-serial/object scope, cleared
on retarget; CLI --verified-interlock requires matching --serial. GUI shows
unknown (operator verified). Known negative/key/connection/identity faults remain
blocking. Default startup/passive discovery unchanged. Removed unconditional
administrative holds from Stage0–2 CLI; physical-record prerequisites stay factual.
432 offline tests PASS; tests cover confirmation scope, passive startup, raw unknown,
known negative, key/communication failure, GUI Open and CLI selection validation.

Initial baseline records/stage5-production-hardware-2026-10-20.json: two Closed/
reconnect shutdown cases pass, unconfirmed Open refused, cleanup/release completed.
records/stage6-gui-hardware-2026-10-20.json: actual server closed lifecycle pass,
Open disabled and not forced. Normal PTY Ctrl+C stopped server, exit1 (not clean
exit0 evidence); next real connection must verify release. Historical baseline
preserved. Current source change invalidates production qualification until new
live tests; next records will capture confirmed-session USB runs. No human action
requested; no new independent blade observation inferred.

## E077 / TEST-086 — Stage5/6 actual production USB checks

REQ-050 (derived from PROJECT.md Stage5/6 request), REQ-051 (latest GUI/hardware
hold removal): software/readback criteria PASS. 437 offline tests and scoped Ruff
PASS. Latest source hashes/configuration captured in stage5-stage6-summary-2026-10-20.json.

Stage5 confirmed session: Closed shutdown, reconnect shutdown and Open with2s
added hold followed by safe_shutdown itself closing all READBACK_PASS/errors[].
Shutdown calls1.140/1.141/1.140s; release COMPLETED/no handle, process exit0.
Fresh initial connection also confirms the earlier closed-GUI Ctrl+C released its
handle. Baseline inhibited Open remains preserved separately, not overwritten.

Stage6 real production CLI/Dash HTTP callbacks on USB68800777: passive startup,
unused slots disconnected, discovery/identity, Close, refresh, release/reconnect
and actual enabled Open2s/Close all READBACK_PASS. Browser reload visibly showed
Connected, Closed, Keyenabled, Interlockunknown(operatorverified), enabled Open.
No disabled Open forced. Refresh retained Closed, no extra Open calls. A second
GUI Open held2s after feedback, then one normal PTY Ctrl+C delivered immediately
by the orchestrator; production CLI finally invoked hub.safe_shutdown. Log-only
wrappers captured Closed/Inactive/Manual during shutdown, completed1.094s,
all3 handles released, main returned0. Outer PowerShell/PTY exits1; cause of outer
status not established, do not call this OS exit0. No forced termination/repeated
interrupt. Fresh separate passive owner reconnects, identity68800777 and Closed/
Inactive/Manual confirmed; releases passively, no errors, process exit0.

Evidence: stage5-confirmed-hardware-2026-10-20.json;
stage6-confirmed-gui-2026-10-20.json; stage6-before-ctrl-c-2026-10-20.json;
stage6-confirmed-server-2026-10-20.json; stage6-post-shutdown-2026-10-20.json.
Raw records retained; aggregate supplies final interpretation and hashes.
No new human blade observation/calibrated timing; physical Stage5/6 acceptance
criteria remain distinct. No firmware, hardware interlock, trigger parameters,
TTL arm or physical loss injection. Stage7 stays removed. Normal production GUI
restarted intentionally for user handoff at8050/session53364; no automated cycle
left running. Pending final passive connection/browser check, recorded below.

E077 handoff completed: normal production CLI session53364 on127.0.0.1:8050,
real browser Connect (passive), final GUI visibly Connected68800777, Closed,
manual/inactive, keyenabled, Interlockunknown(operatorverified), Open enabled;
slots2/3 Disconnected. Screenshot gui-enabled-usb-2026-10-20.png and
records/gui-handoff-2026-10-20.json. One intentional idle GUI owner retained;
prior test owners released. No automatic sequence/pending hardware command.
Browser tab preserved/opened for user. Current Stage5/6/hold-removal request done;
broader unmet physical/multi-pair/TTL/fault criteria remain visible, not COMPLETE.

## E078 / TEST-087 - Actual browser/hardware UX and focused GUI redesign

2026-10-20; REQ-052 derived from user request in PROJECT.md. User authorizes
actual GUI actions on safe hardware without human supervision. Existing source
block/normal interlock retained, USB68800777 only,2s added Open hold. Driver and
CLI unchanged (hashes checked against E077); gui.py/CSS and3 meaningful callback
regression tests changed.440 offline tests PASS, Ruff/format checks PASS.

Baseline browser Close/release verified before normal Ctrl+C of session53364.
New test server29503 uses production CLI with log-only wrappers. Actual browser:
Discover, empty slot Connect gives inline error without hardware access, selected
Connect68800777 reports Closed, expand trigger settings, passive Read TTL settings,
collapse by Enter, Open visible ->2.015s added hold ->Close visible. Open shown
amber, Closed green; raw feedback/normal guards remain. Three ordinary refreshes
and later actions do not replay Open; trace records exactly one public Open.
Close&disconnect, reconnect Closed, reload and global Close&disconnect all pass.
No configure_triggers/arm_triggers calls, all recorded method results OK. Normal
Ctrl+C after release: test application main0, outer PTY1 (not called OS exit0).

Reload exposed misleading initial Select/Connect text on an already connected
view. Corrected default feedback to No action yet in this view; improved discovery
grammar/summary spacing and aria-busy. These final copy/accessibility changes
leave command/guard paths unchanged. Final version passively reconnected on new
normal production CLI session8424 and reloaded: Connected68800777, Closed/manual/
inactive, keyenabled, interlockunknown(operatorverified), correct default message,
Open/Close enabled, other slots Disconnected. One locator wait anomaly claimed
timeout while its diagnostics already showed Connected/visible; fresh AX confirmed
success and no second Connect was issued.

Actual viewport912x956 has no horizontal overflow; Open and Close46px high and
fully visible at608.6-654.6px. Trigger settings collapsed and keyboard operable.
Screenshot gui-ux-final-2026-10-20.png; Open screenshot gui-ux-open-2026-10-20.png.
Summary gui-ux-summary-2026-10-20.json links raw events, browser motion timings,
layout and final source hashes. No new independent physical observation or
calibrated blade/exposure timing. New GUI intentionally remains connected/Closed
for user handoff; no test loop or pending action. Broader acceptance is unchanged.
