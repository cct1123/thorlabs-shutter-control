# KEH3 / KSC101 Ethernet discovery failure — support evidence

Prepared 2026-10-20 for owner review; not sent to Thorlabs or anyone else.

An [update procedure for review](../docs/KSC101_FIRMWARE_UPDATE_REVIEW.md) is now
prepared. Before execution, please confirm reliable updater target selection
despite the erroneous serial, exact 1.0.7 payload, the supported USB update route
for a hub-docked hardware-3 KSC101, no-auto-flash detection behavior and recovery
after interruption. No firmware update or updater installation is authorized yet.

## Question for Thorlabs

New official evidence: the firmware utility history lists KSC101 **1.0.7** fixing
incorrect hardware-info serial reporting (utility release 1.14.62, 2025-07-24).
Please confirm whether this update is required for Ethernet discovery with
KEH3 **1.1.2**, and whether the observed serial 26000000 can cause the hub to
suppress the cube endpoint. The published note does not explicitly establish
that Ethernet consequence; no firmware update has been performed. See
[firmware sources and scope](../docs/ethernet-assessment.md#official-firmware-findings-e047-2026-10-20).

Which supported compatibility checks and non-actuating diagnostic procedure
should be used when a KEH3 is reachable over Ethernet but its powered left-bay
KSC101 is absent in both Kinesis discovery and SDK discovery? Could the cube's
reported hardware-info serial disagreement explain this? Please specify whether
a firmware compatibility requirement applies to these exact versions before any
update is considered. No firmware or physical intervention has been authorized.

## Configuration and authority

- KEH3 serial 120100261, firmware 1.1.2, hardware 1; MAC D8:47:8F:93:68:CB.
- Tested DHCP/LAN endpoint 192.168.1.19; host IPv4 192.168.1.201.
  Hub settings screenshot also displays static 192.168.0.200; no IP was changed.
- KSC101 selected/USB descriptor serial 68800777, firmware 1.0.6, hardware 3;
  human confirms left bay. SH05R manually controllable, cube display powered,
  no bay LED observed (human reports). Supply model/rating not yet captured.
- Windows x64, Python 3.12.7, official Kinesis assemblies 1.14.60.27990,
  USB FTDIBUS 2.12.28.1. Existing installation was repaired before these tests.
- USB IN disconnected and no direct cube USB connection, human-confirmed;
  Windows USB inventory subsequently no longer listed cube 68800777.
- SDK tests ran with Kinesis closed. All SDK handles/sockets were released before
  the separate vendor-GUI discovery comparison. No output, Enable, mode, TTL,
  firmware, persistent IP, power-cycle or docking changes were made by the agent.

## Reproducible observations

1. Activate existing local TCPIP entries 192.168.1.19:40303 through :40307 with
   DeviceManagerCLI.CreateManualDeviceEntry, then BuildDeviceList/GetDeviceList.
   Only serial 120100261 appears; GetTransportInfo reports TCPIP / :40303.
   Existing manual-entry lists are unchanged before/after the test.
2. Hub Connect/GetDeviceInfo returns matching serial/model/firmware. Read-only
   RequestEthernetInfo/GetEthernetInfo reports matching MAC and status 141/0x8D.
   Generic RequestStatus is not implemented; it is not used as hub health proof.
3. Holding a hub session, then fully initializing settings and polling at 250 ms,
   does not reveal the cube. GetBaysCount is 4 (SDK result, not interpreted as four physical cube bays). Generic GetConnectionState remains
   Connecting although IsConnected is true and identity/Ethernet reads succeed.
4. Independent, identical APT MGMSG_HW_REQ_INFO bytes `05 00 00 00 50 01`:
   TCP 192.168.1.19:40303 returns 90 bytes, message 0x0006/payload 84, model KEH3,
   serial 120100261. TCP :40304 accepts but returns zero bytes before a 2 s recv
   timeout. Context-managed sockets released. This is not a shutter command.
5. Human then performs Kinesis -> Connect -> Find device -> Known IP 192.168.1.19
   -> Scan with USB still absent, stopping before Connect/output controls:
   result reported **only hub 120100261**, no KSC101.
   A later GUI session connected the hub passively, displaying firmware 1.1.2;
   no cube was available to select. Human took over and repeated discovery,
   again reporting only the hub. The GUI may remain connected to the hub.
6. Earlier USB passive diagnostic: TLI_GetDeviceInfo descriptor selects 68800777,
   but .NET GetDeviceInfo SerialNumberText/OriginalSerialNumber consistently
   reports 26000000, model KSC101. The application rejects the mismatch; no alias
   or firmware write is used. USB raw feedback included AutoToggle/state 0;
   numeric 0 is not treated as valid Inactive. These USB observations predate
   the explicit operating-feedback request revision and need revalidation.

## Evidence files

- [Fresh discovery](ethernet-resolution-discovery-2026-10-20.json)
- [Hub held during discovery](ethernet-resolution-hub-session-2026-10-20.json)
- [Initialized/polling hub](ethernet-resolution-hub-initialized-2026-10-20.json)
- [Paired raw hardware-info responses](ethernet-resolution-paired-hwinfo-2026-10-20.json)
- [Application endpoint guard result](ethernet-resolution-controller-2026-10-20.json)
- [Earlier USB hardware identity](usb-identity-detail-2026-10-20.json)

Minimal application endpoint selection is software-tested, including rejection
of USB fallback, wrong bay, serial mismatch and competing serial ownership.
It cannot resolve a cube that does not answer vendor discovery or a passive
hardware-info request. Physical cube Ethernet communication remains BLOCKED.
