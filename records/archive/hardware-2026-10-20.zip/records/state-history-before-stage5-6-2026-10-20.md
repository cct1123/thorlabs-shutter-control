# Engineering state

## Active E076: GUI/hardware holds lifted; live Stage5/6 qualification

Latest user permits GUI/hardware and removes administrative holds. Added explicit
session/selected-serial confirm_interlock and CLI --verified-interlock SERIAL.
SDK clear-bit stays unknown; physical circuit is not altered; known negative/key/
communication faults still refuse Open. Retarget clears confirmation. Startup
remains passive; user/automation explicitly Connect/Open. 432 offline tests PASS.
Stage0/1/2 hardcoded hold responses removed; offline default remains passive;
explicit discovery/connection are available with actual record prerequisites.

Initial unconfirmed Stage5 Closed and reconnect shutdown readbacks PASS; Open
correctly refused unknown interlock. Initial GUI closed lifecycle PASS, disabled
Open respected. Normal terminal Ctrl+C returned exit1, no cleanup exception
printed; do not infer clean exit0. Server no longer running; next Stage5 fresh
connection verifies release, followed by confirmed Open2s->safe_shutdown cases.
Stage5 confirmed-session run completed all3 cases READBACK_PASS, release complete,
process exit0; records/stage5-confirmed-hardware-2026-10-20.json. Next real GUI
lifecycle and normal terminal Ctrl+C from Open, tracing cleanup.
No Kinesis/updater or shutter test Python owner found. Preserve earlier JSON.
Current last readback Closed/Inactive/Manual; recheck before each output.


## Stage5/6 implementation and autonomous launch in progress

User authorizes Stage5/6 hardware with no human involvement. Implemented
stage_5.shutdown_case and stage_6 callback payload/closed-GUI lifecycle helpers;
424 offline tests PASS. No production source/guard change. Next actual production
cases: Closed shutdown, reconnect shutdown, then2s Open->safe_shutdown if guard
permits. Stop first failure, preserve same controller. Then independent GUI
closed-state checks and normal Ctrl+C, with no forced Open through disabled UI.
No additional human prompt, no independent blade observation invented.

## Stage3/4 SDK bench sequence PASS â€” E075 / TEST-084

2026-10-20: user explicitly requests control after E074 Close result, then
changes sequence to Open2s/Close2s for5cycles. Completed verified Stage3 Close/
Manual preparation and all5 SDK Open/Close cycles, every Open/Active and
Closed/Inactive readback passed. Final Closed/Inactive/Manual, errors[], release
COMPLETED/no handle. User confirms "the shutter followed the sequence";
physical functional observation PASS for this requested run.

Evidence records/sdk-five-cycles-2s-2026-10-20.json (raw trace preserved) and
records/sdk-five-cycles-observation-2026-10-20.json (human observation).
Added Open holds2.000â€“2.016s, Closed holds2.000s by host monotonic clock;
these are feedback-based software waits, not calibrated blade/exposure timing.
This was a direct official SDK bench run using human-confirmed physical
interlock/source block, exact68800777 firmware1.0.7 hardware3, fresh key/status
checks. No hardware interlock setting, trigger config or firmware changed.

Scope: Stage3/4 hardware functionality demonstrated by SDK+human observation;
production class/GUI safeguard qualification remains separate and unresolved.
Production guards unchanged, raw interlock bit still unverified. Stage7 remains
removed, no Stage5/6/8/9/10 launch or automatic repeat. No pending operation.
Earlier10s process never started: auto-review rejected its mismatch with latest
request. Corrected5x2s plan was software-checked then approved/executed.

## Independent SDK reads and Close succeed â€” E074 / TEST-083

User requests other commands and explicitly confirms physical interlock enabled.
Accept that as human-reported physical condition, not evidence SDK bit is valid.
One direct official SDK diagnostic: exact68800777/KSC101/firmware1.0.7, ready/
CommsOK verified, current Closed/AutoToggle/operating0 read before output. Read
cycle parameters (5cycles, OpenTime2000/ClosedTime2000 vendor ms) and trigger
params input/high, output/high. Explicit authorized Inactive then fresh feedback
Closed/Inactive in Auto; only then Manual -> Closed/Inactive/Manual.
No errors, release COMPLETED/no handle. records/sdk-other-commands-close-2026-10-20.json.

TEST-083 PASS for independent SDK read/Close command and feedback. This is not
production stage-helper PASS, physical closing-transition proof or Stage4.
No Enable/Active/Open/TTL configuration/update. Raw0x2000 unchanged. Initial0
was not relabeled; explicit command establishes documented Inactive. Auto is
valid, and this result does not indicate a faulty controller. Production source
unchanged. SDK Close functional evidence available for review; physical final
Closed confirmation still independent, Stage4 remains held for stage review
and its production safeguard/readiness contract. No repeated failure loop.

## Fresh run after status reset â€” E073 / TEST-082

2026-10-20: user reset request applied to current Stage3/4 attempt statuses only;
historical logs/Stage7 removal/safeguards preserved. Fresh actual USB68800777
Stage3 attempt fails Connect: Unknown operating feedback state0/modeauto.
verified false, no Close/Enable/Open or configuration command. Release COMPLETED,
no handle,4.109s; REPL exited. records/stage3-reset-run-2026-10-20.json.
records/current-hardware-tests.json now Stage3 FAIL at prerequisite, physical
UNTESTED; Stage4 BLOCKED/physical UNTESTED. No device reset or pending operation.

Interruption reconciliation found no Kinesis/updater or shutter-run Python owner;
only VSCode isort LSP in shutter environment. Earlier interrupted Stage5/6 request
not launched. Current source8ff3c5d... unchanged. Resetting test bookkeeping did
not resolve actual unknown Auto feedback or interlock reporting. Stop without
automatic retry/guard bypass; supported operating-feedback resolution required.

## Stage 7 removed by user â€” E072 / TEST-081

REQ-049 (derived, remove Stage7): PASS for plan revision. Removed dedicated
twenty-cycle repeatability stage and count criterion; updated requirement mapping
and Stage9 prerequisites to stages0â€“6 plus8. Retained numbering8â€“10 and historical
evidence. Removed is a scope decision, not tested/PASS physical repeatability.
No code/device operation or change to remaining stage criteria. Current Stage3
feedback failure/Stage4 block remains E071; removal does not resolve those gates.

## Reviewed-source Stage 3 attempt fails feedback gate â€” E071 / TEST-080

2026-10-20: user requests Stage3/4 hardware runs. No Kinesis/updater owner found.
Attempted Stage3 status-first on E070 source8ff3c5d...; USB68800777 discovered,
Connect fails Unknown operating feedback state0/modeauto. No output authorized,
Close/Open/Enable not sent; passive release COMPLETED/no handle,4.125s.
records/stage3-reviewed-source-2026-10-20.json. Stage3 functional attempt FAIL
at prerequisite, physical motion UNTESTED; Stage4 BLOCKED/not run.

Do not map0 to Inactive or claim new interlock evidence: connection fails before
fresh public status. Known unresolved items are Auto operating0 and independent
interlock readiness/reporting contract. Stop without retry/automatic progression.
Current-source passive acceptance still incomplete; historical Stage3 baseline
is not a PASS for this source/configuration. No software or firmware change.

## Command/manual review corrected interpretation â€” E070 / TEST-079

REQ-048 (derived, holistic command/manual review): PASS for review and software
correction. Read official KSC101 HA0368T RevD manual sections3â€“4, installed
KSC101-specific .NET/C API and official Python.NET example (not executed).
docs/COMMAND_REVIEW.md details findings, sources/hashes and limits. Manual
describes a current-carrying physical interlock and separate key, not independent
software jack continuity. Header's0x2000 unused claim conflicts with key matrix;
no evidence establishes why0x1000 stays clear or permits mask substitution.

Corrected clear-bit interpretation to interlock_enabled=None (unverified),
retained documented positive-bit True, added raw status_bits. GUI now shows
unknown and Open/Arm remain blocked. Error wording says not confirmed enabled.
No change to RequestStatus, unknown operating0 refusal, identity, USB health,
Close/Inactive/verify/Manual sequencing, or cleanup. No timing or mapping guesses.

410 offline tests PASS in1.13s; scoped Ruff/format and diff checks PASS. Source
SHA256 8ff3c5d8d48abc9901993a4e4b860a931817aea7aaebbbf3a74e98504a9d589b.
No hardware accessed; affected current-source physical validation UNTESTED.
Prior readings remain historical evidence, not validation of revised semantics.
Stages3â€“4 not newly passed; interlock reporting and Auto operation0 unresolved.
Next action requires supported interlock-reporting contract/independent evidence
and known feedback before passive revalidation/motion; no identical retries.

## Jack-installed/unlocked recheck â€” E069 / TEST-078

2026-10-20 local: user reports jack installed/key unlocked again. Three passive
samples still0x2000/KeyEnabledTrue, Closed/AutoToggle/operating0, ready/CommsOK.
No errors, release COMPLETED/no handle; no output/configuration/update.
records/interlock-key-unlocked-recheck-2026-10-20.json. Earlier matrix unchanged;
physical interlock mapping remains unresolved, motion not authorized by readback.

## Four-state jack/key matrix captured â€” E068 / TEST-077

Jack removed/key unlocked/Auto unchanged now reads0x2000/KeyEnabledTrue,
Closed/AutoToggle/operating0 in all three request paths. Errors[], release
COMPLETED/no handle. records/interlock-jack-removed-key-unlocked-2026-10-20.json.
All four Auto conditions: installed+unlocked0x2000/True; installed+locked0/False;
removed+locked0/False; removed+unlocked0x2000/True. Key XOR0x2000, jack XOR0.
No jack-related bit change observed. Summary
records/interlock-four-state-comparison-2026-10-20.json.
TEST-077 PASS for readback capture, physical interlock reporting unresolved.
No output/configuration/update or mask change; unknown operation0 and unresolved
interlock prevent motion. Next evidence: vendor/raw-protocol confirmation or
approved independent circuit measurement, not more identical reads.

## Jack comparison with key locked â€” E067 / TEST-076

2026-10-20: human reports jack removed/key locked/Auto unchanged. Three passive
samples all0x0000/KeyEnabledFalse/Closed/AutoToggle/operation0, ready/CommsOK,
errors[], release COMPLETED/no handle. Same as E066 jack installed/key locked:
XOR0x0000. No observable jack-related bit change with key OFF. Does not establish
how interlock reports with key ON or physical continuity. No output/configuration.
records/interlock-jack-removed-key-locked-2026-10-20.json. Safeguards unchanged,
motion blocked. TEST-076 PASS capture; physical interlock mapping INCONCLUSIVE.

## Key A/B shows responsive status â€” E066 / TEST-075

User now reports jack installed/key locked. Same passive requests and Auto mode:
all samples bits0x0000/KeyEnabledFalse versus unlocked0x2000/True. XOR0x2000;
Closed/AutoToggle/operating0 unchanged, ready/CommsOK. No errors, release
COMPLETED/no handle. records/interlock-key-locked-2026-10-20.json and
records/interlock-key-comparison-2026-10-20.json.

TEST-075 PASS for observed key-state discrimination only. Status is not wholly
stuck: key change is reflected. Installed SDK labels0x2000 unused, but observed
bit13 follows key in this pair. Do not relabel it interlock or infer jack circuit
readiness. Interlock-bit0x1000 remains clear in both. Production guards unchanged;
current key OFF and unknown operating0 preclude motion. No output/configuration.

## Key-unlocked baseline â€” E065 / TEST-075

User reports jack installed, key unlocked. Passive raw SDK comparison captures
all samples0x2000, KeyEnabledTrue, Closed/AutoToggle/operating0, ready/CommsOK.
Identity68800777 firmware1.0.7 hardware3, no errors; release COMPLETED/no handle.
records/interlock-key-unlocked-2026-10-20.json. No output/configuration/update.
This establishes human-labelled key-unlocked baseline, not an independent
interlock circuit measurement. Key-locked comparison remains pending; hold mode
Auto and jack installed unchanged. Unknown0 and interlock-bit clear still block
production motion; no flags changed or mask interpretation inferred.

## Interlock comparison captured; mode confounded â€” E064 / TEST-074

User reports jack installed and then clarifies "I changed to automode".
Open baseline Manual/Inactive, closed condition AutoToggle/state0: all samples
0x2000/key true/Closed/communications OK. XOR0x0000, no observed interlock-bit
change. Not controlled single-variable A/B: mode changed too, circuit continuity
unmeasured, cache freshness unproven. Comparison INCONCLUSIVE for physical
interlock mapping/driver fix; no mask change or inversion justified.

Production closed-condition attempt correctly refused unknown operation0 and
released. Subsequent SDK read-only diagnostic captured bits without interpreting
0 as Inactive or allowing output. Both releases COMPLETED/no handle. Evidence
records/interlock-ab-closed-2026-10-20.json (production refusal),
records/interlock-ab-closed-raw-2026-10-20.json and
records/interlock-ab-summary-2026-10-20.json. No shutter/mode/TTL/update commands.
Next meaningful experiment holds mode/key/other conditions fixed while comparing
normal open/closed interlock circuits under operator-approved power procedure,
or obtains independent/vendor-confirmed reporting evidence. Stage4 BLOCKED.

## Interlock A/B comparison: open baseline captured â€” E063 / TEST-074

User explicitly requests comparison: without3.5mm jack circuit open, withjack
circuit closed; reports current circuit open. One passive open baseline:
records/interlock-ab-open-2026-10-20.json. All three request samples0x2000,
KeyEnabledTrue, Closed/Inactive/Manual, ready/CommsOK; no errors, release
COMPLETED/no handle. No shutter/configuration command or firmware update.

Human action required: with independent source block, follow manufacturer-approved
power-down procedure to install the normal interlock jack (no powered connector
change), restore power, report "jack installed, powered". Software cannot change
this physical condition. Then capture the same passive measurements to a distinct
closed-condition record, compute bit differences; no actuation or mask change.
TEST-074 comparison PENDING, baseline captured only.

## Status-command audit â€” E062 / TEST-073

User suspects command error. Compared RequestStatus with polling, explicit
RequestStatusBits with polling stopped, then explicit RequestStatus with polling
stopped; 0.5 s after each explicit request. All report8192/0x2000, KeyEnabled
true, Closed/Inactive/Manual, IsConnected true, CommsStatus OK. No request errors,
passive release COMPLETED/no handle. records/status-request-comparison-2026-10-20.json.
Installed KSC101 .NET API and native header both document interlock mask0x1000;
SolenoidStatus has KeyEnabled but no separate interlock property. Different
request method did not resolve discrepancy. No proven production command defect
or justified fix; physical wiring/firmware/SDK reporting remains INCONCLUSIVE.

Correct wording: reported interlock bit clear, not independently proven physical
interlock circuit disabled. No mask inversion, use of key as interlock, Enable
experiment or actuation. No source change. Stage4 remains BLOCKED. Next useful
validation requires independent physical/vendor evidence of this firmware's
interlock status reporting, not further identical reads.

## Latest requested recheck â€” E061 / TEST-072

2026-10-20: explicit "check again", one passive USB cycle. Both samples still
Closed/Inactive/manual, key true, interlock false; 68800777 / firmware1.0.7.
No errors, passive release COMPLETED/no handle, 4.313 s.
records/interlock-status-check-3-2026-10-20.json. No shutter commands; Open blocked.

## Latest requested recheck â€” E060 / TEST-071

2026-10-20: another explicit "check again", passive USB only. Both fresh status
samples still Closed/Inactive/manual, key true, interlock false; identity68800777,
firmware1.0.7. No errors, passive release COMPLETED/no handle, 4.171 s.
records/interlock-status-check-2-2026-10-20.json. No output or automatic retry;
Open remains blocked pending diagnosis/change of actual interlock condition.

## Latest passive interlock check â€” E059 / TEST-070

2026-10-20, user "check again": one passive USB cycle, no output commands.
68800777 / firmware1.0.7, Closed/Inactive/manual, key true, interlock false in
both fresh status samples. No errors, release COMPLETED/no handle, 4.313 s.
records/interlock-status-check-2026-10-20.json. Open/sequence remains blocked;
no source change or automatic retry. Diagnose physical/readback disagreement.

## Reported interlock change not reflected in readback â€” E058 / TEST-069

User says "interlock abled". One fresh guarded attempt still reads key true /
interlock false, Closed/Inactive/manual, correct 68800777 / firmware1.0.7.
Stopped before every output, passive release COMPLETED/no handle, 4.328 s;
records/stage4-interlock-recheck-2026-10-20.json. Approved 10 s hold not reached.
No repeat pending actual change/diagnostic evidence; next work is distinguish
physical normal-interlock condition from vendor status/reporting discrepancy,
not another identical sequence attempt or flag override. Stage 4 BLOCKED.

## Interlock recheck still blocks sequence â€” E057 / TEST-068

Human replied "abled" to normal interlock check; exact physical change unknown.
Reread under the approved single 10 s Open/Close sequence, with both safeguard
flags mandatory before ANY output (including initial Close). Fresh hardware
still key true / interlock false, Closed/Inactive/manual. Stopped before verified
output authorization, no Close/Enable/Open/mode/TTL command. Passive release
COMPLETED/no handle, 4.297 s. records/stage4-hardware-2026-10-20.json.
Sequence physical UNTESTED/BLOCKED, no automatic repeat or safeguard override.
Next external dependency remains actual normal interlock condition/diagnosis;
human report does not replace contradictory electronic feedback.

## Open/Close sequence blocked by interlock â€” E056 / TEST-067

User requests one sequence and approves 10 s added Open hold after feedback.
Fresh USB production read 68800777 / firmware1.0.7: Closed/Inactive/manual,
key true, interlock false in both status samples. No errors, passive release
COMPLETED, no handle, 4.328 s. records/sequence-precheck-2026-10-20.json.
No Enable/Open/state/mode/TTL setter issued. Stage 4 BLOCKED before actuation.
Installed official KSC101 header lines 639â€“640 explicitly defines 0x1000 as
interlock 1=Enabled/0=Disabled; 0x2000 not used. No supported basis to invert
or substitute key state. Ten seconds is added hold, not maximum exposure bound.

Human action required: normal interlock condition must be checked/restored under
manufacturer-approved bench procedure; never bypass or change connections while
powered. Return resulting interlock condition. Software cannot establish wiring
or restore this physical circuit. Then reread safeguards before any Open; retain
stage review and independent physical observations. Stage-3 physical observation
request remains unanswered; electronic Close baseline is E055.

## Stage 3 Close executed; review pending â€” E055 / TEST-066

2026-10-20: user's "do hardware run" authorizes one Stage-3 status-then-Close
cycle. Actual USB 68800777 / firmware1.0.7, exact identity and fresh full status
verified before output. Pre-motion Closed/Inactive/single; Close returns and
final full status confirms Closed/Inactive/manual. Key true, interlock false;
TRIG1 input/high, TRIG2 output/high unchanged. No errors, guarded cleanup Close
and communication release COMPLETED, no retained handle, 5.985 s.

Evidence records/stage3-hardware-2026-10-20.json. Production unchanged, no
Enable/Open/TTL/firmware update. Executed reviewed protected REPL procedure,
not the complete-bench helper: bench record remains incomplete, no fields
invented or preflight marked PASS. This is functional Close/readback evidence,
not full physical acceptance. Already Closed does not prove closing transition.

TEST-066 PASS for command/readback/release only; physical observation/review
PENDING. Human action: report independently observed final Closed and any
unexpected motion. Record response, then review Stage 3; Stage 4 stays held and
Open remains blocked by reported interlock false. No automatic next stage.

## Stage 3 order confirmed â€” E054 / TEST-065

User specifies status read first, then motion control. Existing helper does
Connect/identity -> fresh pre_motion status -> Close -> final status -> guarded
cleanup. Added explicit pre-motion status error phase and two regressions:
Close requires fresh read; failed fresh read releases passively with no output.
37 motion-helper software cases PASS, scoped Ruff PASS. No hardware accessed;
physical Stage 3/4 remain unexecuted, E053's USB fix remains unchanged.

## USB health resolved passively â€” E053 / TEST-064, 2026-10-20

REQ-047 (derived, USB health correction): PASS for focused fix and actual passive
production cycle. Installed vendor API documents IsConnected as ready for
commands and CommsStatus OK as working communication. Driver accepts USB
Connected/Connecting only with both checks satisfied; explicit Disconnected,
unknown state, not-ready, non-OK and request failures still fault. No internal
state setter or identity override. Root of the SDK enum remaining Connecting
is not established; it is no longer misclassified alone as a lost USB channel.

404 offline tests PASS in 0.94 s, six new health/loss cases; scoped Ruff PASS.
Source SHA256 1d1914a72e5c742a858ca25d2557099b995b2645dcddadcc08d5f4304d56ae5b.
Actual production passive cycle: 68800777, firmware 1.0.7 / hardware 3,
Closed/Inactive/single, key true, interlock false, TRIG1 input/high and TRIG2
output/high, unchanged feedback. No errors, release COMPLETED, no handle;
4.312 s. records/usb-health-fix-passive-2026-10-20.json.

No shutter/configuration/update command. Physical blade/loss timing remain
unqualified; three reviewed cycles not claimed. Stage 3/4 physical UNTESTED.
Open still blocked by reported interlock false. No automatic motion launch;
reconcile actual bench/recovery before Close and interlock before Open.

## Hardware precheck; Stage 3 blocked â€” E052 / TEST-063, 2026-10-20

User authorizes hardware tests and requests electronic status reads. No Kinesis/
updater process found before one passive diagnostic. SDK FTDI discovery finds
68800777; firmware 1.0.7 / hardware 3 / all serial fields 68800777. IsConnected
true, CommsStatus OK, but USBConnected and GetConnectionState both Connecting
immediately after Connect and after 0.5 s polling. This explains which production
USB-health comparison rejects the session; it does not establish why that SDK
state persists or validate changing the guard.

Reported Closed / Inactive / SingleToggle, key true, bits 8192 (driver interlock
mask 0x1000 clear). No independent blade/wiring or shutdown procedure inferred.
Passive release COMPLETED, diagnostic process exited, no handle remains. Raw
evidence records/usb-health-diagnostic-2026-10-20.json. No source change, firmware
update, output/configuration command, Stage-3 Close or Stage-4 Open issued.

TEST-063 PASS for passive diagnostic capture only. Stage 3 BLOCKED by unresolved
production connection prerequisite; Stage 4 UNTESTED pending Stage 3 physical
PASS/review. Stop at the failed prerequisite; next engineering action is SDK
health-semantics/timing diagnosis and revalidation, preserving identity and
communication-loss safeguards. No automatic retry or bypass.

## Stage 3/4 implementation ready for review â€” E051 / TEST-062, 2026-10-20

REQ-046 (derived, implement stages 3 and 4): PASS for software preparation only.
User says "stage 2 passed"; recorded as human-reported PASS, not a new measured
production result. TEST-061's USB health failure remains conflicting evidence;
no replacement production artifact/independent observation supplied. Do not
silently reinterpret that failure as PASS. No hardware access this turn.

Implemented docs/hardware_tests/stage_3.py first_close and stage_4.py
open_close_pair; shared verified-target cleanup, complete bench/previous-stage
review gates, explicit finite positive added hold, no prompt/retry/advancement.
Success records feedback only with physical UNTESTED. Identity/unknown feedback
failures get passive release only; verified-target cleanup may Close. Combined
operation/cleanup failures preserved; interrupts propagate after cleanup.
Caller retains controller for diagnosis; no SDK/controller created automatically.

TEST-062: 35 new software-device cases PASS; full offline suite excluding live
SDK test 398 PASS in 1.26 s; scoped Ruff PASS. Production source unchanged.
Stage 3 physical UNTESTED / awaiting review; Stage 4 physical UNTESTED and gated
on Stage 3 physical PASS/review. Actuation remains held under implementation-only
scope. Before live launch reconcile USB health evidence and current bench facts;
then authorize and execute Stage 3 alone, observe closure/release, stop for review.

### Human action required â€” next physical launch

Known: firmware/serial repair passed TEST-060; human reports Stage 2 PASS, but
last production USB test failed TEST-061. No software-only test can resolve actual
USB health or independently observe the blade. Return the current Stage-2 PASS
evidence/conditions and current bench record before launch, then explicit
Stage-3 Close/Manual/cleanup authority. Review artifacts are implemented below;
Stage 4 separately requires Stage-3 observations and approved Open hold in seconds.

## Firmware updated; USB identity repaired â€” E050, 2026-10-20

REQ-045 (derived, newest KSC101 firmware request) / TEST-060: PASS for update and
USB firmware/identity readback. Hardware 3 cube 68800777 now runs 1.0.7, latest
KSC101 version in official utility 1.14.76 history. Hardware SerialNumberText,
SerialNumber and OriginalSerialNumber all now 68800777. Passive SDK reports
Closed / Inactive / SingleToggle, key true, bits 8192, CommsStatus OK; these are
controller feedback, not independent blade observation. User confirmed source
block, stable USB/power, acceptable reset effects and printed serial.

Updater completed once and rediscovery confirms 1.0.7. No manual power cycle,
hub update, source change or identity workaround. Actual Flash Firmware button
starts programming immediately without the confirmation described in CHM;
payload version was not exposed beforehand, resulting version verified afterward.

TEST-061: unchanged production driver passes identity then FAILS its separate
USB connection-health guard. Passive release completed with no retained handle;
both diagnostic processes exited. No automatic retry. Stage 2 still FAIL/stopped
for review; Stages 3â€“4 and actuation held. Ethernet not retested on new firmware.
Next: investigate actual IsConnected/USBConnected feedback and SDK timing;
do not weaken the guard based only on a successful raw cycle.

Evidence: records/firmware-post-usb-2026-10-20.json and
records/firmware-post-production-usb-2026-10-20.json, updater completion/version
screenshots and text. No pending update, owner or recovery operation.

## USB-only resumption â€” E049 / TEST-059, 2026-10-20

User reports USB-only hub wiring and requests continued USB hardware tests;
then confirms Kinesis closed. Process recheck found no Kinesis owner. Windows
reports APT USB Device 68800777, status OK; SDK discovery identifies FTDI USB
68800777. Production Connect FAILS its identity guard: selected 68800777,
hardware-info serial 26000000. No identity override or automatic retry.

Communication-only release COMPLETED, no device handle retained; diagnostic
process exited normally. Cycle elapsed 3.484 s. Evidence:
records/usb-resume-2026-10-20.json. Source SHA256
304deeaf7c94abf2c12ed1678f3821a87a2783ff3018db845b4963d947358d03.
Firmware/status reads after Connect were not reached; 1.0.6 remains historical
firmware evidence, not a fresh read. No independent blade observation supplied
for this cycle. No production code changed, output command or updater issued.

Stage 2 remains FAIL / stopped for human review; Stages 3â€“4 and shutter actuation
remain held. USB enumeration alone does not pass controller communication.
Firmware preparation below remains review-only; this USB request did not approve
an update. Next useful recovery depends on the documented vendor identification/
update gates or manufacturer guidance. Do not bypass the guard or repeat the
same failed bench cycle without a changed condition and reviewed next step.

## Update procedure prepared â€” E048 / TEST-058, 2026-10-20

REQ-044 (derived, latest PROJECT.md preparation request): PASS for procedure
preparation only. Review docs/KSC101_FIRMWARE_UPDATE_REVIEW.md. Target KSC101
1.0.6 -> 1.0.7; retain KEH3 1.1.2 and existing SDK/source. Covers official x64
utility/hash, target identification despite wrong hardware-info serial, capture
of settings/ownership/power/observation/recovery, programming hold point, passive
USB first then Ethernet, and separate outcomes for USB serial repair versus
Ethernet discovery. No updater downloaded/installed/run; no hardware accessed,
firmware/power/docking changed or shutter command issued in this preparation.

Preparation validation: 3 Python blocks compile; 16 fake-device USB/Ethernet
cases PASS with no output writes; PowerShell hash/signature block parses without
execution. Package integrity values are vendor-published, not locally verified
installer/image hashes. The actual 1.0.7 payload and vendor UI/recovery sequence
remain unverified; official web README did not expose a readable document here.

### Review / resumption gates

Review the prepared procedure before scheduling anything. Before a future
programming approval, obtain reliable vendor-supported identification for this
hardware-3 cube despite serial 26000000, confirm exact KSC101 1.0.7 selection,
approved USB update path, utility no-auto-flash behavior and interruption recovery.
Record independent protection/current physical state and approval for required
reset/output-state consequences. Then stage/verify package and prepare actual
target/version screenshot for explicit programming approval. No guessed
bootloader sequence, unsupported downgrade or automatic settings restore.
Post-update passive checks are prepared, NOT executed or newly authorized by
this review request. Actuation remains held even if communication later passes.
REQ-043 remains BLOCKED; no physical gate advances from this procedure.

## Firmware evidence and Kinesis handoff â€” E047 / TEST-057

2026-10-20: official Thorlabs Firmware Update Utility history, version 1.14.62
(2025-07-24), lists KSC101 device firmware **1.0.7** fixing incorrect product
serial numbers in hardware-info messages. This closely matches E040's 68800777
USB descriptor versus 26000000 hardware-info serial on firmware 1.0.6. It is a
documented relevant defect/fix, not proof that it causes the silent Ethernet bay.
KEH3 official history lists **1.1.2** fixing static-IP startup; it is also the
version offered on the official firmware page. No exact 1.0.6/1.1.2 compatibility
matrix or explicit note connecting this pair to Ethernet discovery failure was
found. Kinesis history adds KEH support in 1.14.55; installed 1.14.60 is later.

GUI work used the computer-use skill: Kinesis discovery showed only hub
120100261, and its passive hub connection displayed FW 1.1.2 / Connected. No
KSC101 entry was available to connect. Evidence screenshot:
records/kinesis-ethernet-hub-only-2026-10-20.jpg. User stopped computer control
with Escape and took over. The requested manual discovery was then answered
**"only hub"** again. No further automated UI input is authorized by that reply;
the hub may remain connected in Kinesis. No firmware update or actuation occurred.

Research result: known KSC serial-reporting bug is the leading documented lead;
Ethernet causality remains INCONCLUSIVE and REQ-043 remains BLOCKED. Next external
question is whether Thorlabs requires KSC101 1.0.7 for KEH3 1.1.2 discovery and
whether its serial fix addresses this bay symptom. Support packet updated, not
sent. Do not perform an update to test the hypothesis without explicit authority.

## Current Ethernet resolution â€” E045/E046, 2026-10-20

REQ-043 (derived, latest PROJECT.md Ethernet resolution request): **BLOCKED for
actual cube communication; software transport implemented.** Explicit
KCubeShutter(ethernet_endpoint="192.168.1.19:40304") activates that local SDK
manual entry and accepts only matching TCPIP serials. No USB fallback, no serial
alias. Shared ownership and USB health guards remain. Ethernet uses IsConnected,
CommsStatus and exact transport descriptor: generic GetConnectionState remained
Connecting even during successful live hub reads, so it is not used as proof of
transport health. Physical loss timing/freshness remain unqualified.

TEST-055 / E045: **363 offline tests PASS** (346 prior +17 Ethernet checks),
scoped lint/format PASS. No dependency, CLI or GUI change. Actual passive tests
TEST-056 / E046 after user closed Kinesis still enumerate only hub 120100261 at
192.168.1.19:40303. Holding an initialized/polling hub session does not expose the
cube. Hub MAC matches D8:47:8F:93:68:CB; Ethernet status 141 / 0x8D (no setup-error
bit). GetBaysCount returns 4; do not call this four physical cube bays.

Human confirmed **left bay**, matching port 40304. Paired identical documented
hardware-info requests: hub returns 90 bytes, serial 120100261/model KEH3;
left bay returns 0 bytes and times out at 2 s. New production path correctly
blocks absent 68800777 before factory/Connect; no cube handle opened. This is NOT
resolved by the code change. No shutter/Enable/mode/TTL/firmware/IP/power/docking
commands were sent. All our handles/sockets released; polling stopped.

### Human action required â€” manufacturer-supported diagnosis

The independent comparison is complete: human reports Kinesis discovery with
USB absent also lists **only hub 120100261** (E046). Correct-bay SDK discovery,
raw hardware-info read and vendor discovery all fail to expose the cube; powered
display/manual operation do not prove the bay's data connection. Root cause
among docking/data interface, hub bridge or firmware compatibility is unproven.

Useful passive/software isolation is exhausted for this session. Review the
prepared records/ethernet-support-case-2026-10-20.md with Thorlabs and obtain a
model/version-specific diagnostic/recovery procedure. This packet has NOT been
sent externally. Return their recommended procedure/compatibility finding; any
power/docking/firmware intervention needs approval and its own physical-state/
recovery conditions before execution. Then recheck ownership (Kinesis may remain
open after discovery), repeat only the affected passive gate and keep motion held.
No further blind retries, serial aliasing, firmware or network writes.

## Latest plan revision â€” E044 / TEST-054, 2026-10-20

REQ-042 (derived, actual-hardware plan revision): PASS for procedure scope.
Updated docs/HARDWARE_VALIDATION.md around real E040/E041 failures, human E042
observations and E043 controller revision. Next bench path is refreshed session
facts -> operator restores USB IN -> one current-source passive cycle -> stop on
identity/status failure and diagnose. Only three reviewed passive passes unlock
Stage-3 launch consideration; Stage 4 additionally needs Stage-3 PASS/review and
approved Enable/Open/Close, hold/limits and recovery. Ethernet is separate and
does not block a separately validated USB path. No hardware ran in this revision.

Motion acceptance blocks now verify target/feedback before enabling cleanup
Close; failed/unverified connections use passive release. They retain primary
and cleanup failures, check final Closed/Inactive/Manual status and require
independent observations. 5 Python document blocks compile; assembled Stage 4
and 8 software-device lifecycle/error/interruption cases PASS (TEST-054).
No production/test/dependency change; E043's 346-test evidence remains current
software scope. Physical Stage 2 remains BLOCKED; Stage 3/4 not launched.

## Latest software revision â€” E043 / TEST-053, 2026-10-20

REQ-041 (derived from latest minimal controller-revision request): PASS for
software-only handling improvements. Controller now prevents changing serial
selection while a handle is retained, explicitly requests operating mode/state
before cached reads, normalizes documented SingleToggle/AutoToggle names and
faults unknown operating feedback. Identity matching, USB health, interlock,
closure ordering and retained ownership guards remain intact. Scope is one
production module, fixture/regressions and contract/checkpoint documentation;
no dependency, GUI or transport implementation change.

Validation: **346 offline tests PASS** in 1.52 s (331 existing + 15 regressions),
scoped Ruff lint/format PASS. This revalidates affected software checks on the
new source, not physical behavior. No SDK loaded or hardware accessed. E040/E041
are historical measurements of the previous source and remain unresolved;
new source requires separately authorized passive revalidation. No claim that
requesting mode/state fixes the actual operating-state 0 or serial mismatch.
Stage 3/4 hardware execution remains BLOCKED. Next: review this focused change,
then diagnose the identity mismatch without aliasing/bypassing it; pass Stage 2
on the selected transport before motion. No physical action is requested now.

## Current checkpoint â€” passive bench tests, 2026-10-20

**BLOCKED for physical Stage-2 acceptance; stop before Stage 3.** This section
supersedes older connection holds and unknown-IP statements below. The user
authorized passive USB then Ethernet testing, confirmed safe conditions, closed
Kinesis and confirmed USB unplugged. Actuation, Enable, mode/TTL/network settings
and firmware writes remain held. No production source or guard was changed.

- TEST-050 / E040: USB enumerates 68800777, but connected hardware information
  consistently returns 26000000. The production identity guard correctly rejects
  connection; communication-only release completed. Raw diagnostic reads are
  evidence of the discrepancy, not a passing production connection. Reported
  Closed/AutoToggle/operation 0 is not independent physical state confirmation.
- TEST-051 / E041: hub 120100261 is confirmed TCPIP at 192.168.1.19:40303;
  passive connection reads matching identity, firmware 1.1.2, hardware 1 and
  releases successfully. Generic RequestStatus is unsupported. Host LAN is
  192.168.1.201; screenshot static hub IP 192.168.0.200 is not the tested endpoint.
- Final USB inventory is empty for 68800777, resolving earlier stale/present
  observations. Final SDK discovery lists only the Ethernet hub. TCP 40304 accepts
  connection but one documented passive hardware-info request times out without
  bytes. Ports 40305â€“40307 time out. Cube Ethernet communication is UNPROVEN.
- Final diagnostic handles/sockets released; no background polling retained.
  Stage-2 software evidence remains E039 (331 offline tests); no source changed.

### Human action required now

The observation request was answered: human reports cube connected to the bank,
display powered, SH05R manually controllable, and no bay LED (E042). Exact bay
position remains unspecified. Manual control is human-reported functionality;
it does not validate SDK identity, normalized feedback or Ethernet routing.
No further hardware action is requested by this readiness review. Leave the
setup unchanged. Capture bay identity if Ethernet diagnosis resumes; do not
repeat the already answered power/cable questions or infer a docking fault from
the LED observation alone.

### Stage 3 / 4 readiness review â€” E042 / TEST-052

**Offline implementation is technically feasible; live execution is NOT READY.**
The current user request is examination, not approval to implement both stages
or actuate. Preserve one-stage implementation/review sequencing.

Stage 3 requires passing passive identity/status/release on the chosen transport,
physical target mapping, known safeguards/recovery and explicit authority for
Close, Manual selection and cleanup Close. Stage 4 additionally requires Stage-3
PASS with independent Closed observation, explicit Enable/Open authority, an
approved added Open hold and applicable duty/recovery limits. The proposed 1 s
is not an approved operating limit. Ethernet acceptance is not required for a
separately validated USB-only launch; each receipt must name its transport.

Highest-priority engineering gap: resolve USB serial 68800777 versus hardware
26000000 and feedback AutoToggle/operation 0 without weakening identity or state
guards, then revalidate Stage 2. Do not send Close/Open to diagnose these issues.
For eventual Stage-3 offline tooling, cover refusal before output on missing/
failed prerequisites, ordered Inactive/Closed/Manual verification, retained
primary and cleanup failures, interruption handling and independent observation
recording. Review Stage 3 before implementing Stage 4; Stage-4 tooling must add
finite positive approved hold validation, one pair only, and best-effort cleanup
without claiming a maximum exposure guarantee. No Stage-3/4 code or live test
was executed during this review.

## Earlier checkpoints (historical where superseded above)

Current staged checkpoint, 2026-10-20: **STAGES 0â€“1 ACCEPTED FOR IMPLEMENTATION;
STAGE 2 IMPLEMENTED â€” AWAITING HUMAN REVIEW**. The user requested Stage-1
closeout/Stage-2 implementation and SDK resolution. Authentic x64 Kinesis was
installed and actual SDK discovery returns **68800777** (E038 / TEST-048).
Assemblies: 1.14.60.27990 in C:/Program Files/Thorlabs/Kinesis. Windows driver
FTDIBUS 2.12.28.1, oem187.inf, ProblemCode 0 / OK; no COM assignment for this
controller. E037's Code 28/missing-install observations are superseded by
[SDK repair evidence](records/sdk-repair-2026-10-20.json), not deleted.
Stage 2 has offline preparation, a held Connect CLI and one-cycle lifecycle
logic validated only with software controllers (E039 / TEST-049). 30 new checks
and all **331** software tests PASS. No real Connect, polling, Enable, state/mode,
TTL or firmware command, package build, commit/push or reboot was performed.
Stop before Stage 3 for review. Full physical acceptance remains BLOCKED; the
bench record, physical label/cable mapping and passive-connection authority are
still missing. Installer UI msiexec 58668 / InstallShield Wizard was last observed
open after installation; it was not forcibly terminated. Recheck before any
further installer action; SDK files/driver and actual enumeration already work.

Review checkpoint: **HOLISTIC REVIEW AND DEVELOPMENT PLAN DELIVERED**, 2026-10-20,
REQ-040 / TEST-045 / E035. See [development plan](docs/DEVELOPMENT_PLAN.md).
The existing compact architecture is retained as the recommended foundation.
Software-only probes reproduce stale Open-event acceptance after Close and
writable serial/status identity divergence. Priority proposals: command ordering,
shutdown without preflight status reads, stable identity, feedback provenance and
responsive SDK ownership; then gated bench acceptance and release engineering.
No production source was changed. Review baseline: 279 offline tests PASS in
0.65 s; scoped lint/format PASS. Concurrent Stage-1 work is outside this review's
validated snapshot; its stage checkpoint/review authority is maintained separately.
This plan grants no implementation/launch approval and preserves B001/B002 gates
unless separately resolved by the human. Next review action is to select the
first focused hardening change; no feature implementation is pending in this task.

Historical Stage-0 checkpoint: **IMPLEMENTED; NOW APPROVED BY HUMAN**,
2026-10-20, E029 / TEST-039. The user's current instruction requires review after
each implemented stage and keeps hardware access on hold. Stage 0 provides
[bench record](records/hardware-bench.json), [read-only checker](docs/hardware_tests/stage_0.py)
and [guide](docs/hardware_tests/README.md). Known topology is human-reported;
actual pair count and missing bench conditions stay unknown. The supplied record
correctly reports INCOMPLETE. 36 new checks and all 279 software tests PASS.
The subsequent human approval authorized Stage-1 implementation, now E036.
Stage 2â€“10 tooling remains unimplemented; connection/actuation remain on hold.
Physical REQ-003â€“008/023/031 remain BLOCKED under B001. E028 / TEST-038 remains
the reviewed procedure evidence; the only plan change is a Stage-0 tooling link.

Checkpoint: beginner hardware tutorials **VALIDATED (SOFTWARE ONLY)**, 2026-10-20.
Intent: [PROJECT.md](PROJECT.md), example-folder rewrite.
Five numbered hardware lessons and the beginner guide are complete under
[docs/examples](docs/examples/README.md); developer simulation moved to tests.
Current tutorial/package evidence: E026 / TEST-037. Production code is unchanged.
Current evidence: E024 / TEST-035; prior TTL evidence E023 is historical after
these changes. **AWAITING_HUMAN_REVIEW** remains the hardware status. No SDK load,
device discovery/connection, actuation, electrical test or firmware change is authorized.
Physical acceptance remains **BLOCKED**; software success is not overall completion.

## Requirements

Full criteria and sources are in PROJECT.md. REQ-019â€“031 track the successive
three-shutter, naming/simplification, Ethernet research and TTL requests;
REQ-032â€“033 track the latest consistency review and publication request.
Earlier scoped evidence remains historical. Current regressions revalidate
unchanged behavior; physical criteria remain blocked under B001.

| ID | Short criterion | Validation / evidence | Status |
| --- | --- | --- | --- |
| REQ-044 | Prepare KSC101 1.0.7 update procedure with passive USB/Ethernet checks (derived, latest PROJECT.md request) | TEST-058 / E048; review document, snippet syntax and 16 software-device cases | PASS (preparation only; update held) |
| REQ-043 | Resolve KSC101 through KEH3 Ethernet with minimal code and passive tests (derived, latest PROJECT.md request) | TEST-055 / E045 software path PASS; TEST-056 / E046 hub PASS, confirmed left cube bay silent; human vendor-GUI comparison also hub only | BLOCKED (physical communication) |
| REQ-042 | Revise actual-hardware acceptance procedure (derived, latest PROJECT.md request) | TEST-054 / E044; current evidence reconciliation, snippet compilation and 8 software-device cases | PASS (plan only) |
| REQ-041 | Minimal controller hardware-handling revision (derived, latest PROJECT.md request) | TEST-053 / E043; 346 offline tests and scoped lint/format; actual SDK/bench revalidation pending | PASS (software only) |
| REQ-040 | Holistic review and comprehensive package development plan (derived, latest review request in PROJECT.md) | TEST-045 / E035; source/docs review, two software reproductions, 279-test baseline and prioritized roadmap | PASS (review/planning only) |
| REQ-001 | Python, uv, packaging and lock | TEST-001/025; locked setup, build/package checks, E024 | PASS |
| REQ-002 | Reusable controller, separate GUI | TEST-002/022â€“024; current software tests, E024 | PASS |
| REQ-003 | Physical discovery/identity/connect/reconnect | E038 enumerates 68800777; TEST-050 / E040 production Connect fails hardware serial mismatch 26000000; TEST-051 / E041 hub Ethernet identity succeeds, cube absent | BLOCKED |
| REQ-004 | Physical opening/closure/repetition | TEST-004; no independent physical observations | BLOCKED |
| REQ-005 | Feedback agrees with physical state | TEST-005; real sensor/cache behavior unknown | BLOCKED |
| REQ-006 | Physical error handling/recovery | TEST-006; real USB/hub/device loss pending | BLOCKED |
| REQ-007 | Physical safe shutdown | TEST-007; per-shutter closure/latency unverified | BLOCKED |
| REQ-008 | GUI on physical hardware | TEST-008; only simulated GUI validated | BLOCKED |
| REQ-009 | Setup/troubleshooting documentation | TEST-009/025; updated guides and references, E026 | PASS |
| REQ-010 | Accurate API/architecture/integration/simulation | TEST-010/025; examples/demo/review, E026 | PASS |
| REQ-011 | Actual simulated screenshot, editable diagrams | Historical E016/E023 screenshots; unchanged GUI/diagrams, TEST-035 E024 | PASS |
| REQ-012 | Reproducible documentation workflow | TEST-012/025; demo, references, E026 | PASS |
| REQ-013 | Honest prior documentation delivery | TEST-013; historical scoped E007/E008 | PASS |
| REQ-014 | Focused prior simplification (derived) | TEST-014; historical scoped E009 | PASS |
| REQ-015 | Validate current package (derived) | TEST-015/025; software suite/build, E024 supersedes E009 for changed source | PASS |
| REQ-016 | Explain architecture and retained complexity (derived) | TEST-016/025; current report E024, historical E009 | PASS |
| REQ-017 | Simple hardware-focused visual README (derived) | TEST-018/020/025; updated README E024, diagram E014 | PASS |
| REQ-018 | Multiple-controller/KEH3 compatibility review (derived) | TEST-021; source assessment E015 only | PASS |
| REQ-019 | Three independent GUI panels (derived) | TEST-022; distinct fake devices, HTTP/browser lifecycle, E024 | PASS (software) |
| REQ-020 | Exclusive ownership and cleanup all slots (derived) | TEST-023; duplicate/race/failure/interrupt tests, E024 | PASS (software) |
| REQ-021 | Passive startup, CLI serials, hardware hold (derived) | TEST-024; fake launch/argument tests, E024 | PASS (software) |
| REQ-022 | Reproducible package and operating docs (derived) | TEST-025; tests/lint/build/examples/visual review, E026 | PASS (software) |
| REQ-023 | Three KSC101s through actual KEH3 USB (derived physical scope) | TEST-026 / physical TEST-003â€“008; prepared procedure stage 9 | BLOCKED |
| REQ-024 | Rename driver, merge hub module and prune (derived) | TEST-027; 99 tests, package, docs and layout parity, E017 | PASS (software) |
| REQ-025 | Rename ShutterHub, centralize construction and prune (derived) | TEST-029; 107 source/package tests, examples and layout parity, E019 | PASS (software) |
| REQ-026 | Simplify GUI construction, preserve independent controls (derived) | TEST-030 historical E020; current TEST-035 regression E024 | PASS (software) |
| REQ-027 | Assess KEH3 Ethernet SDK support and changes (derived) | TEST-032; official documentation/static SDK/source review, E022 | PASS (research only) |
| REQ-028 | TTL configuration/readback and explicit arm/disarm (derived) | TEST-033; static official contract, distinct software devices, E024 | PASS (software) |
| REQ-029 | Independent TTL GUI controls and draft/readback separation (derived) | TEST-033; HTTP/browser checks, E024 | PASS (software) |
| REQ-030 | TTL shutdown and package regression (derived) | TEST-033; failure/interrupt/all-slot tests and wheel, E024 | PASS (software) |
| REQ-031 | Physical TTL configuration/priming/disarm across three shutters (derived) | TEST-034; stage 10, no SDK/physical execution | BLOCKED |
| REQ-032 | Consistency review, focused fixes and pruning (derived) | TEST-035; 211 source/wheel tests, E024 | PASS (software) |
| REQ-033 | Commit and push reviewed changes | TEST-036; implementation 2bce513 pushed and remote verified, E025 | PASS |
| REQ-034 | Five beginner hardware-only tutorial scripts (derived) | TEST-037; five hardware scripts/guide, 243 source/wheel tests, E026 | PASS (software) |
| REQ-035 | Reviewed staged hardware plan (derived, final-plan request in PROJECT.md) | TEST-038; source/procedure review, syntax and six software-device cases, E028 | PASS (documentation only) |
| REQ-036 | Implement stages individually with human review and scoped authority (derived, latest PROJECT.md requests) | Stages 0â€“1 accepted; SDK repair/discovery E038; TEST-049 / E039 validates Stage 2; Stage-2 review pending; stages 3â€“10 pending | IN PROGRESS |

## Staged implementation checkpoint

| Stage | Implementation / software evidence | Human review | Physical execution |
| --- | --- | --- | --- |
| 0 | Bench JSON, passive checker and guide; TEST-039 / E029 PASS (software) | APPROVED by user | Bench record incomplete; OS USB identity only established in E037 |
| 1 | Offline metadata/record checks, held CLI and injected enumeration checks; TEST-046 / E036 PASS (software) | Accepted by request to finish Stage 1 and implement Stage 2 | SDK repaired; actual enumeration returns 68800777, E038. Physical count/mapping unverified |
| 2 | Offline serial preparation and single passive-cycle helper; TEST-049 / E039 PASS (software) | Passive execution authorized; stop before Stage 3 | TEST-050 / E040 fails USB identity guard; TEST-051 / E041 confirms Ethernet hub only; physical acceptance BLOCKED |
| 3â€“10 | Not implemented as staged tooling; prior tutorials/procedures remain reference only | Wait for preceding stage review | Actuation ON HOLD |

## Human review required now / B002

Stage-1 software closeout and actual SDK setup/discovery are recorded in E038.
Review docs/hardware_tests/stage_2.py, its guide and tests/test_hardware_stage_2.py
(E039), then approve Stage 2 or request changes. After implementation approval,
implement Stage 3 and stop for review. No real passive connection/actuation is
authorized by this review; unknown physical facts may remain unknown while
reviewing software. The last observed installer wizard may still need manual
dismissal; do not launch a competing installer based on the earlier missing-path
diagnosis. It does not block SDK enumeration, which already succeeded.

## Current architecture and configuration

GUI/CLI -> ShutterHub -> up to three independent KCubeShutter objects -> lazy
Kinesis .NET/Python.NET -> KEH3 USB serial identities. Default GUI has three
passive slots. No new dependency or lockfile change. One serialized GUI callback
keeps per-panel settings drafts, Apply/Read/Arm/Disarm and readback independent.
Connect/refresh never configure or arm. Manual Open refuses Triggered mode.

Connection verifies the returned serial. Full status samples operating feedback
after requesting TTL settings; Open/Close/Disarm waits read operating feedback
alone, allowing disarm after settings errors. Faults stay latched until successful
disconnect/reconnect. Command snapshots may omit trigger_config; use get_status()
for full readback. Apply requires Closed/Inactive/Manual and matching settings.
Arm requires healthy feedback, key/interlock and an input; uses reported settings.

Close requires Closed/Inactive before Manual, then Closed/Inactive/Manual. Release
attempts Disconnect after StopPolling errors or interruptions; failed release
retains its handle/serial claim. Hub/CLI attempts every slot, preserves faults and
interrupts. Open recovery interruption also leaves a fault. No persistent-settings
or firmware commands. Port settings remain; prior Triggered mode is not restored.

Default polling 250 ms, GUI interval 1 s. Full three-slot status adds at least
750 ms of settings waits plus SDK latency. Feedback timeout is 5 s per stage:
two for Close/Disarm, three for Open/Arm including preparation. SDK calls and
sequential shutdown have no total latency bound. No calibrated pin-level or
precise exposure timing API is provided.

Current staged source suite: 331 tests PASS (E039), including 30 Stage-2, 22 Stage-1
and 36 Stage-0 checks. E029's earlier 279-test baseline includes Stage-0 preparation
checks. Prior tutorial/package evidence E026 has 243 source and 243 rebuilt-wheel
tests PASS, including 32 hardware-tutorial checks using software devices. No new
package build is claimed for this preparation tool. Imports and all five --help
entry points are passive; actuation examples require finite positive, explicit
dwell values. Lint/format/build and 112 documentation link/anchor checks PASS.
The moved internal simulator completes its three-device API walkthrough.
Current tutorial/wheel hashes and conditions: E026. E024's review manifest is
historical for the earlier full tree; its production Python remains unchanged.
GUI/CSS and prior simulated captures are unchanged. Environment: Windows x64,
CPython 3.12.7, Dash 4.4.1, Python.NET 3.1.0, unchanged uv.lock.

Ethernet assessment [E022](records/RECORDS.md#e022) remains research only; Kinesis
KEH3 Ethernet is documented, XA Python discovery details unresolved, no backend
implemented. See [assessment](docs/ethernet-assessment.md). Actual installed SDK,
physical topology, feedback/cache age, electrical behavior, persistence and
closure/latency remain unvalidated. No simulator or hardware handle is pending.

## Tutorials, prior publication and next action

Five standalone hardware lessons: discovery, passive status, manual actuation,
three-shutter sequential control and TTL. Begin at docs/examples/README.md.
All actuation scripts use explicit try/finally cleanup; the passive status lesson
intentionally uses disconnect(close_shutter=False) and explains its limits.
The examples folder has no simulation entry point or test-fixture dependency.
Developer simulation remains at tests/simulated_demo.py for internal verification.

The earlier implementation/publication remains recorded by E024/E025 and commits
2bce513/0833e84 on origin/main. This new tutorial request changes examples/docs/tests
only; no new commit/push is part of its execution. Tutorial software work is complete;
staged-tool implementation now waits at Stage-2 review B002. Future physical work
depends on B001. Discovery/COM inspection and SDK repair have subsequent authority;
connection and actuation remain on hold. Forced termination,
power/USB loss or a hung SDK call can prevent closure and later cleanup attempts.

## Human action required for future hardware validation / B001

1. Known: E038 resolves E037's missing driver/SDK: Kinesis x64 installed, Windows
   ProblemCode 0, actual enumeration 68800777. No COM assigned in current inventory.
2. Blocker: bench power/physical mapping, initial shutter state, safeguards,
   observation/recovery and actual passive-connection authority remain unresolved.
   SDK discovery alone cannot supply or validate those conditions.
3. Before physical Stage 2, provide the dependent Stage-0 bench fields and explicitly
   authorize passive Connect/settings initialization/polling/status/release only.
   Return independent per-cycle physical observations; review each of three cycles
   before repeating. Actual motion remains a separate later authorization.
4. Return installed count, actual serial(s)/firmware, KEH3 supply and USB/cable
   mapping, SDK path/version/bitness, initial physical/mode/safeguard/trigger states,
   independent source disable/block, observation and exact recovery procedure.
   Add approved Open/Closed dwell in seconds and duty/combined limits before motion;
   add TTL source/wiring/levels/polarities/load before that separate stage.
5. Recheck transient state and execute only approved gates; save per-test/serial
   observations. Missing prerequisites block their dependent stages, not unrelated
   preparation. SDK installation/discovery occurred in E038; connection/actuation
   were not attempted.
