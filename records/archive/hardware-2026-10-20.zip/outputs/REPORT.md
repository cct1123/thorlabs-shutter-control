# Package review and development report

## Actual GUI experience and design improved

E078 / TEST-087: redesigned gui.py/CSS around everyday shutter control. Compact
cards put reported state, prominent Close, readiness hints and action/error
feedback together. Connection badges/count show ownership; trigger controls are
collapsed by default, keyboard operable. Busy indication is delayed to reduce
polling flicker; Close remains available during communication. Fixed misleading
Connect instructions when reloading an already connected view.

Actual USB68800777 browser checks passed: discovery, empty-slot error, Connect,
passive trigger read, keyboard collapse, Open ->2.015s added visible hold ->Close,
release/reconnect, connected reload and global shutdown. No TTL Apply/Arm or
firmware. Driver/CLI unchanged;440 offline tests PASS, Ruff PASS. New independent
physical observation/calibrated timing remains unperformed. Final GUI is running,
Connected/Closed, controls ready; no automated sequence.

[Evidence and source hashes](../records/gui-ux-summary-2026-10-20.json).

![Improved GUI with actual USB controller reporting Closed](../records/gui-ux-final-2026-10-20.png)


## Stage5/6 production USB checks passed; GUI/hardware enabled

User removed administrative holds. Added minimal session/selected-serial physical
interlock confirmation for SDK unknown readiness, preserving raw readback and
key/identity/communication/known-negative checks. No hardware interlock setting
changed. Startup remains passive.437 offline tests and Ruff checks PASS.

Actual68800777: Stage5 Closed shutdown/reconnect/Open2s->safe_shutdown passed.
Stage6 real GUI Open2s/Close, refresh, release/reconnect and terminal Ctrl+C from
Open passed electronic readback. Cleanup captured Closed/Inactive/Manual and
released every handle in1.094s host call duration. Application main returned0;
outer PTY exit1 is explicitly recorded. Fresh passive connection verified final
Closed/Inactive/Manual and release. No new independent blade observation or
calibrated timing; broader physical shutdown criteria stay partially unverified.

[Combined evidence/configuration/hashes](../records/stage5-stage6-summary-2026-10-20.json),
[current stage results](../records/current-hardware-tests.json),
[current state](../STATE.md). Normal GUI restarted for user handoff at
[localhost:8050](http://127.0.0.1:8050/); no automated sequence left running.
No new firmware/TTL/loss-injection run. Stage7 remains removed.

Earlier sections below are historical checkpoints, superseded where the current
result differs. The overall multi-device/TTL/fault/calibration project is not
marked complete by this scoped run.


## Stage3/4 SDK hardware sequence passed; human confirmed

E075 / TEST-084: verified Close/Manual preparation, then5 cycles of Open2s/
Close2s. All readbacks passed, errors[], final Closed/Inactive/Manual, release
completed/no handle. User confirms the shutter physically followed the sequence.
This demonstrates requested SDK bench functionality, not production class/GUI
safeguard qualification or calibrated exposure timing. Production guards and
physical interlock configuration unchanged; no further stage automatically run.
[Raw trace](../records/sdk-five-cycles-2s-2026-10-20.json),
[human observation](../records/sdk-five-cycles-observation-2026-10-20.json).

## Other SDK commands and Close succeed

E074 / TEST-083: identity/cycle/trigger reads succeeded on68800777. Explicit
Inactive produced Closed/Inactive; subsequent Manual selection produced
Closed/Inactive/Manual. No errors, connection released. Physical interlock
enabled is human-reported; SDK bit remains unverified. No Enable/Open sent,
no production guard change. Auto is a valid mode; undefined initial0 was not
treated as proof of hardware failure. [Evidence](../records/sdk-other-commands-close-2026-10-20.json).

## Test status reset; fresh Stage 3 still fails prerequisite

E073 / TEST-082: reset current Stage3/4 statuses, preserving old evidence. Fresh
USB68800777 Connect still rejects Auto/state0 before output; release completed,
no handle. Stage3 FAIL at status prerequisite, physical motion UNTESTED; Stage4
BLOCKED/not run. No device reset, output command or source modification.
[Current statuses](../records/current-hardware-tests.json),
[fresh run](../records/stage3-reset-run-2026-10-20.json).

## Test-plan scope revision: Stage 7 removed

E072 / TEST-081: at the user's request, removed the dedicated twenty-cycle
repeatability stage/count threshold. Remaining stage criteria and historical
results retained; stages8â€“10 keep their numbers. No hardware run or physical
repeatability PASS inferred from this scope change.

## Reviewed-source Stage 3 attempt stops before motion

E071 / TEST-080: actual USB68800777 discovered, Connect rejects operating0 in
Auto before motion. Passive release completed/no handle,4.125s. No Close/Open/
Enable sent, Stage4 not run. Undefined operating feedback and unverified interlock
remain unresolved. [Run evidence](../records/stage3-reviewed-source-2026-10-20.json).

## Command/manual review: unknown interlock corrected

E070 / TEST-079: reviewed official KSC101 manual, installed SDK and official
Python.NET example. Corrected clear0x1000 from a claimed physical Disabled state
to unverified/None; preserve raw status_bits. GUI shows unknown; Open/Arm stay
blocked. Key readback, jack continuity and operating state are distinct.
No request-method or0-to-Inactive fix supported. Existing Close preparation and
guarded cleanup retained. 410 software tests PASS, scoped Ruff/format PASS.
No hardware operation; revised source physical validation remains UNTESTED.
[Full review and sources](../docs/COMMAND_REVIEW.md).

## Four-state key/jack comparison complete

E068 / TEST-077: with Auto unchanged, jack installed/removed both give0x2000
when key unlocked and0x0000 when locked. KeyEnabled follows key; no bit change
tracks jack presence. Physical interlock behavior remains unverified. No source
change or actuation; all releases completed.
[Four-state evidence](../records/interlock-four-state-comparison-2026-10-20.json).

## Controlled key comparison responds correctly

E066 / TEST-075: jack installed, Auto mode unchanged: key unlocked gives
0x2000/KeyEnabledTrue; key locked gives0x0000/KeyEnabledFalse. Thus key readback
responds and the entire status is not stuck. Interlock mapping/circuit remains
unverified; do not use key bit as interlock. No output commanded, all handles
released. [Comparison](../records/interlock-key-comparison-2026-10-20.json).

## Interlock jack comparison: no observed status-bit difference

E064 / TEST-074: jack removed in Manual/Inactive and jack installed in Auto/state0
both read0x2000 with key enabled and shutter reported Closed. User confirms
changing to Auto. XOR0; mode change confounds the comparison, and circuit
continuity is unmeasured. Physical interpretation INCONCLUSIVE; no code fix or
mask override justified. Production correctly refuses unknown state0; passive
SDK diagnostic released all handles. No output/configuration/update commands.
[Comparison summary](../records/interlock-ab-summary-2026-10-20.json).

## Status request audit: no request-method difference found

E062 / TEST-073: RequestStatus and explicit RequestStatusBits (polling stopped)
both return0x2000, ready/communications OK. SDK documents0x1000 for interlock,
but the physical condition is unverified; earlier "interlock disabled" wording
means reported bit clear. Reporting discrepancy remains inconclusive, no
supported code fix or actuation. [Comparison](../records/status-request-comparison-2026-10-20.json).

E058 / TEST-069: another human-reported interlock change was checked once;
readback still disabled. Sequence refused before all output, passive release
completed. [Latest evidence](../records/stage4-interlock-recheck-2026-10-20.json).

## Sequence remains blocked after interlock recheck

E057 / TEST-068: after human interlock reply, fresh controller feedback still
reports key true / interlock false. Guarded 10-second sequence stopped before
all output; no Open or hold executed. Reported Closed/Inactive/manual, passive
release completed. [Result](../records/stage4-hardware-2026-10-20.json).

## Requested 10-second Open/Close blocked before output

E056 / TEST-067: fresh USB status Closed/Inactive/manual, key enabled but
interlock disabled. Installed official header confirms the bit interpretation.
No Enable/Open sent; passive release completed. Operator interlock check required
before retrying the approved single pair. [Precheck](../records/sequence-precheck-2026-10-20.json).

## Stage 3 hardware Close completed; physical review pending

E055 / TEST-066: USB 68800777 verified, fresh status read before output.
Closed/Inactive/single -> Close -> Closed/Inactive/manual. No errors; guarded
cleanup/release completed, no retained handle. No Enable/Open or Stage-4 run.
Already Closed establishes a baseline, not an observed closing transition;
independent physical confirmation and complete bench acceptance remain pending.
[Run evidence](../records/stage3-hardware-2026-10-20.json).

## USB health discrepancy resolved (2026-10-20)

E053 / TEST-064: guard accepts headless Connecting only with documented
ready-for-commands IsConnected and CommsStatus OK. Disconnected/unknown,
non-ready, communication errors and request failures still fault. 404 software
tests PASS; actual production USB passive connection/identity/status/release
PASS, 68800777 / firmware 1.0.7. No actuation/configuration/update.
[Result](../records/usb-health-fix-passive-2026-10-20.json).
Reported interlock false still blocks Open; physical Stage 3/4 not executed.

## Actual hardware precheck blocks motion (2026-10-20)

E052 / TEST-063: authorized passive USB reads identify 68800777 / firmware 1.0.7.
IsConnected true and communications OK coexist with USBConnected Connecting
after Connect and polling; the latter fails the production health guard.
Controller reports Closed / Inactive / SingleToggle, key enabled, bits 8192.
These are electronic feedback only. Passive release completed, no handle retained.

Stage 3 BLOCKED before output; Stage 4 not run. No source change, actuation,
firmware update or guard bypass. [Diagnostic](../records/usb-health-diagnostic-2026-10-20.json).

## Stage 3 and 4 helpers implemented; physical tests pending (2026-10-20)

E051 / TEST-062: first-Close and single Open/Close helpers now require reviewed
prior-stage evidence, verify target/status before motion, validate added hold and
perform guarded cleanup while preserving combined failures/interrupts. No live
CLI or automatic progression. Software results never assign physical PASS.

35 new software-device cases PASS; 398 offline tests PASS (live SDK test excluded),
scoped Ruff PASS. No production source change or hardware access. Human reports
Stage 2 PASS; conflicting recorded USB failure remains visible. Both live stages
remain unexecuted, with review after Stage 3 before Stage 4. Actuation held.

## KSC101 updated to 1.0.7; serial mismatch fixed (2026-10-20)

E050 / TEST-060: authorized update completed using installed official utility
1.14.76.28950. Rediscovery and passive USB readback verify firmware 1.0.7 and
hardware serial 68800777, correcting 26000000. Controller reports Closed /
Inactive / SingleToggle, communications OK. No production code change, hub
update or deliberate shutter command. Both passive handles released.

TEST-061: unchanged production connection still fails its separate USB health
guard. Stage 2 remains blocked pending diagnosis/review; Ethernet has not been
retested. [Readback](../records/firmware-post-usb-2026-10-20.json),
[production result](../records/firmware-post-production-usb-2026-10-20.json).
Actual utility starts programming immediately on Flash Firmware, without the
extra confirmation described in its help; treat that button as programming.

## USB-only test remains blocked by identity mismatch (2026-10-20)

E049 / TEST-059: after the user confirmed Kinesis closed, actual USB discovery
found FTDI controller 68800777. Production Connect rejected hardware-info serial
26000000. Passive release completed, no handle remained, and the diagnostic
process exited normally. [Raw result](../records/usb-resume-2026-10-20.json).

Stage 2 FAIL; Stages 3â€“4 remain held. Firmware/status reads beyond Connect were
not reached and no independent blade observation was supplied. No shutter
actuation, firmware update, production source change or automatic retry occurred.
The earlier firmware procedure remains prepared for review only.

## KSC101 firmware update procedure prepared for review (2026-10-20)

E048 / TEST-058: [review procedure](../docs/KSC101_FIRMWARE_UPDATE_REVIEW.md)
targets KSC101 1.0.7 only, retains hub/SDK/source and separates staging,
identification/recovery review, explicit programming approval and subsequent
passive USB/Ethernet acceptance. It includes passive-only error cleanup and
keeps motion held after communication checks. The exact payload, target-identify
method and vendor programming/recovery workflow must be verified before flashing.

3 Python blocks compile, 16 software-device cases PASS and the PowerShell
integrity block parses. No firmware utility downloaded/installed/run and no
hardware operation occurred. This is preparation, not update approval or physical
acceptance. Published package hash is recorded; no local installer verification
or firmware backup/rollback capability is claimed.

## Firmware investigation (E047, 2026-10-20)

Official Thorlabs history documents KSC101 1.0.7 fixing incorrect serial numbers
in hardware-info replies, closely matching our 1.0.6 serial discrepancy. KEH3
1.1.2 is the offered hub firmware and its change note concerns static-IP startup.
No exact-version incompatibility statement or demonstrated cause of the silent
Ethernet bay was established. The documented serial fix is a strong lead;
firmware causality for Ethernet remains INCONCLUSIVE.

Kinesis GUI connected the hub, but no cube was available. After taking over,
the human again reported only the hub. No firmware update or actuation occurred.
Sources and limits: [firmware findings](../docs/ethernet-assessment.md#official-firmware-findings-e047-2026-10-20).
REQ-043 remains BLOCKED pending manufacturer confirmation and any separately
approved recovery action; the support packet now asks about the specific fix.

## Ethernet transport added; cube communication still blocked (2026-10-20)

E045/E046: minimal explicit endpoint support is implemented in the Python
controller; exact TCPIP provider/endpoint is required and USB fallback is refused.
Identity, ownership and USB checks remain. **363 offline tests PASS**, scoped
lint/format PASS. No CLI/GUI/dependency extension.

Actual passive discovery after Kinesis closure still finds only hub 120100261.
Human confirmed the left bay (40304). With the same read-only hardware-info
request, hub port 40303 returns 90 bytes identifying KEH3; cube port 40304 returns
zero bytes before timeout. Hub initialization/polling does not change discovery.
The revised controller refuses to open a handle for the absent cube. Thus the
software gap is addressed, but the requested physical communication is unresolved.

All our handles/sockets released and polling stopped; no actuation or configuration
writes. Human reports independent Kinesis discovery with USB absent also lists
only the hub. Physical communication remains BLOCKED pending a manufacturer-
supported diagnosis of the bay/data interface or firmware compatibility; no root
cause among these has been proven. The [support packet](../records/ethernet-support-case-2026-10-20.md)
is prepared, not sent. Details are in [STATE.md](../STATE.md) and E046 in
[records](../records/RECORDS.md#e046).

## Actual-hardware test plan revised (2026-10-20)

E044 / TEST-054: [bench plan](../docs/HARDWARE_VALIDATION.md) now starts from the
measured identity/Ethernet failures and revised controller. It gives a USB-first
passive revalidation path, a stop-and-diagnose branch, separate Ethernet gates,
and first Close/Open acceptance with verified-target cleanup and independent
observations. Each numbered stage stops for human review. Three current passive
passes are needed before Stage 3; Stage 4 also needs Stage-3 PASS and approved
motion/hold conditions. Failed connections never authorize cleanup Close.

5 Python blocks compile and 8 software-device procedure cases PASS. No hardware
access, production change or motion approval resulted from this revision;
physical acceptance remains blocked. The next actual test is one passive USB
cycle after the operator restores that cable path and session prerequisites.

## Minimal controller revision (2026-10-20)

E043 / TEST-053: serial selection is validated and cannot change while an SDK
handle is retained. Status now explicitly requests operating mode/state before
cached getters, normalizes SingleToggle/AutoToggle and rejects unknown operating
values. No identity, USB-health or interlock guard was weakened; close ordering
and communication release remain. Requests/waits do not prove fresh feedback.

**346 offline tests PASS**, including 15 new regressions; scoped Ruff lint/format
PASS. No hardware accessed, dependency changed, firmware written or Ethernet
backend added. Actual serial mismatch and cube Ethernet failure remain unresolved;
the revised source has not been physically revalidated. Stage 3/4 live tests remain
blocked. Review [controller.py](../src/thorlabs_shutter_control/controller.py) and
[API contract](../docs/python-api.md) before the next passive diagnostic.

## Stage 3 / 4 readiness review (2026-10-20)

E042 / TEST-052: offline test-tool implementation is feasible, but hardware
execution is **NOT READY**. Stage 3 intentionally commands Inactive/Close and
Manual mode; Stage 4 additionally enables and opens. Stage 2 has not passed
identity/status acceptance. USB serial disagreement and unresolved feedback
must be diagnosed before actuation. Ethernet need not gate a separately validated
USB-only test, but no working cube transport is currently demonstrated through
the production controller.

Human now reports a powered cube display, manual SH05R operation and no bay LED.
This supports local functionality, not SDK identity, routing or independent
software-command acceptance. Exact bay position remains unspecified; no docking
fault is inferred. Stage 4 also needs Stage-3 PASS, explicit motion authority and
approved hold/duty/recovery conditions. Prepare and review Stage 3 before Stage 4;
this examination implements neither stage and performs no hardware operations.

## Actual passive USB and Ethernet results (2026-10-20)

**Physical Stage 2 is blocked. No shutter actuation was commanded.** E040 /
TEST-050 records USB discovery of 68800777 but connected hardware serial
26000000. The production identity guard refused connection and passive release
completed. Separate read-only diagnostics reproduced the discrepancy; the guard
was preserved. Returned Closed/AutoToggle/operation 0 does not establish physical
blade state or valid normalized status.

E041 / TEST-051 confirms Ethernet hub **120100261**, firmware **1.1.2**, at
**192.168.1.19:40303**, with matching identity and successful passive release.
Generic hub RequestStatus reports unsupported. After USB unplugging was confirmed
and Windows no longer listed the cube, SDK enumeration found only this hub.
Port 40304 accepts TCP but a single documented hardware-info request returned no
bytes before timeout; the cube has not passed Ethernet communication. Other bay
ports timed out. No IP, firmware, output or mode configuration was changed.

Raw evidence: [USB guard failure](../records/passive-usb-2026-10-20.json),
[USB identity details](../records/usb-identity-detail-2026-10-20.json),
[final Ethernet discovery](../records/ethernet-recheck-2026-10-20.json),
[hub connection](../records/ethernet-hub-passive-2026-10-20.json), and
[cube hardware-info timeout](../records/ethernet-cube-hwinfo-2026-10-20.json).
All diagnostic owners were released. Await the cube's bay, display power and LED
observation before selecting the next passive test; stop before Stage 3.
Production code and dependencies remain unchanged; E039's 331 offline tests
remain software-only evidence. Earlier hold statements below are historical.

## SDK repaired; Stage 2 ready for implementation review (2026-10-20)

The user's SDK-repair request authorized installation of the authentic signed
Thorlabs Kinesis x64 package. E038 / TEST-048 and the
[repair snapshot](../records/sdk-repair-2026-10-20.json) establish installed
assemblies 1.14.60.27990, healthy FTDIBUS driver 2.12.28.1 / ProblemCode 0,
and actual application discovery returning **68800777**. No COM is assigned to
this controller in the present inventory. Earlier Code-28/missing-SDK findings
below are historical. No Connect, polling, Enable, shutter/TTL command, firmware
change or reboot was performed. An installer wizard was last observed open;
it was not forcibly terminated or counted as installation proof.

Stage 1 is closed out in software with actual SDK enumeration verified; physical
label/cable mapping and broader TEST-003 acceptance remain pending. Stage 2 now
has [offline preparation and a passive-cycle helper](../docs/hardware_tests/stage_2.py).
It checks prerequisites/serial/identity/feedback, captures one cycle at a time and
attempts communication-only release after errors/interrupts without requesting
closure. A failed release retains the caller's object for diagnosis; no retry
or post-error SDK read is added. Actual --connect stays blocked.

E039 / TEST-049: 30 new Stage-2 cases and **331 full software tests PASS**;
scoped lint/format PASS. The official Thorlabs KSC101 Python.NET example was read
as reference, not executed. Stage 2 awaits human review before Stage 3; actual
connection and actuation remain on hold. Production source/dependencies unchanged.

## Earlier Stage-1 preparation and initial Windows discovery (2026-10-20)

Stage 0 is approved. [Stage-1 tooling](../docs/hardware_tests/README.md) implements
offline record/Python metadata checks, a held discovery CLI and an injected
enumeration comparator. E036 / TEST-046: 22 new guarded checks and 301 full
software tests PASS; no production-source/dependency change. Stage 1 is awaiting
human review before Stage 2.

The user's subsequent actual-discovery request authorizes read-only device/COM
inspection. E037 / TEST-047 and the [snapshot](../records/device-discovery-2026-10-20.json)
identify Windows-present Kinesis Solenoid Controller **68800777**, Code 28 with
no selected driver, and no assigned COM in the current inventory. COM3 and COM7
are other FTDI devices; COM6 is Windfreak. The default Kinesis folder is absent.
No SDK enumeration, controller connection, polling, output/TTL command, driver
installation or firmware operation occurred. A working official driver/SDK is
needed before Kinesis enumeration; OS visibility is not physical acceptance.

## Holistic review and development plan (2026-10-20)

The compact USB/Kinesis controller and three-panel GUI are a useful foundation;
physical qualification and several reliability gaps remain. The
[development plan](../docs/DEVELOPMENT_PLAN.md) prioritizes command ordering,
shutdown without preliminary status calls, stable connected identity, feedback
provenance and responsive execution before more device features. Later milestones
cover separately approved bench acceptance, reproducible releases and conditional
timed-mode/Ethernet/integration extensions.

E035 / TEST-045 records two software-only reproductions: the same Open event is
accepted after Close, and assigning serial_number while connected can mislabel
status. Review baseline: 279 offline tests PASS; scoped Ruff checks PASS.
No production change, hardware operation, feature implementation or publication
was performed for this review. Concurrent stage tooling retains its own review
checkpoint; this plan does not approve a stage or lift the hardware hold.

## Beginner hardware tutorials

## Stage-0 test preparation (2026-10-20)

The latest request requires implementation one stage at a time with human review
between stages. Stage 0 now has a [manual bench record](../records/hardware-bench.json),
[read-only checker](../docs/hardware_tests/stage_0.py) and
[guide](../docs/hardware_tests/README.md). It checks record completeness and basic
identity/mapping consistency without importing the controller/vendor SDK. Unknown
facts stay empty; the current record reports INCOMPLETE as expected. Even a
complete record grants no launch authority and proves no physical operation.

E029 / TEST-039: 36 new guarded checks and all 279 software tests PASS; scoped
Ruff lint/format PASS. SDK/device access remains on hold. Stage-0 implementation
is AWAITING HUMAN REVIEW; Stage 1â€“10 tooling has not been implemented in this pass.
Production controller/GUI/CLI, dependencies and lockfile remain unchanged.

## Final hardware-plan review (2026-10-20)

The [hardware acceptance plan](../docs/HARDWARE_VALIDATION.md) is reviewed for
the reported computer -> USB -> KEH3 -> KSC101 -> SH05R chain. It now has one
numbered execution sequence, requirement-linked evidence, protected motion
cleanup, a shutdown-from-Open case, realistic USB-loss timing, and correctly
ordered TTL refusal/Disarm checks. One-pair acceptance comes first; three-pair
and electrical/TTL tests retain separate prerequisites and approval gates.

E028 / TEST-038: three Python and six PowerShell blocks parse; six lifecycle/error
cases pass with software devices. No production source was changed or real SDK
loaded. E026 below remains evidence for its named software/package artifacts;
this documentation pass did not rebuild them. Physical acceptance remains
BLOCKED and device access AWAITING_HUMAN_REVIEW. Before execution, supply the
stage-0 bench record and approve named initial stages; planning is not a launch.

Five numbered tutorials now live in [docs/examples](../docs/examples/README.md).
Each is a complete hardware-only program with beginner comments, explicit
configuration and cleanup. Evidence: [E026](../records/RECORDS.md#e026) / TEST-037.
The hardware hold and all physical acceptance blockers remain in force.

| Script | Lesson |
| --- | --- |
| [01_discover.py](../docs/examples/01_discover.py) | Find USB serials without connecting |
| [02_connect_and_read_status.py](../docs/examples/02_connect_and_read_status.py) | Connect, identify, read feedback and deliberately release without output writes |
| [03_open_close.py](../docs/examples/03_open_close.py) | Establish Closed, Open for an approved hold, Close and release |
| [04_three_shutters.py](../docs/examples/04_three_shutters.py) | Connect/close all three, operate one at a time, always attempt all-slot cleanup |
| [05_ttl_control.py](../docs/examples/05_ttl_control.py) | Apply/read TRIG1 input-high and TRIG2 disabled, Arm, Disarm and release |

The guide explains installation, serial mapping, reported feedback, Manual versus
TTL operation, operator-approved dwell values, try/finally and recovery limits.
No real serial, assumed safe dwell or simulation switch is embedded in the lessons.
All support hardware-free --help; actuation waits require finite positive values.
Waits add time and do not establish precise timing or a maximum physical dwell.

The simulation helper moved to tests/simulated_demo.py; its fixture lookup and
current documentation links are updated. It remains an internal developer tool.
Removed the duplicate interactive README program in favor of the numbered lessons.
Production controller/GUI/CLI, dependencies and lockfile are unchanged.

Validation: **243 source and 243 rebuilt-wheel tests PASS**, including 32 tutorial
checks with software devices. They cover passive imports/help, output-free status
release, independent sequential control, TTL configuration/arming, invalid dwell,
duplicate serials, actuation errors and interruption cleanup. Actual --help entry
points also pass with SDK loading forbidden. Ruff lint/format, build and 112 local
link/anchor checks pass. The sdist contains all five lessons/guide and the moved
simulator; the old simulation-example path is absent. Packaged Python matches
unchanged source. Internal simulated three-device API walkthrough passes.

No real SDK loading, USB/network discovery, connection, actuation, electrical test
or firmware operation occurred. Physical behavior/limits remain unvalidated.
The previous review/publication is E024/E025; these tutorial changes are local.
See [STATE.md](../STATE.md) for the unchanged future bench-validation dependency.
