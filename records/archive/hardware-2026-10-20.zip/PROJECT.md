# thorlabs-shutter-control

### Actual GUI experience and focused design improvement (2026-10-20)

User requests actual browser actions with the USB hardware, without human
supervision, and improved UX/design in gui.py. Authorizes focused GUI/CSS changes,
software checks and real browser discovery/connect/Close/read/release/reconnect
and guarded Open with established2s added hold, finishing Closed. Hardware is
human-reported safe to test; source block/normal interlock and existing identity/
key/comms checks remain. No firmware, wiring, TTL Arm/Apply or fault injection
needed for this UX scope. Record browser/readback evidence separately from new
independent physical observation or calibrated timing.


### GUI and hardware enabled (2026-10-20)

User: "allow gui allow hardware remove any onhold". Supersedes prior administrative
holds for the present USB controller 68800777 and requested Stage5/6 tests. Use
recorded normal interlock/source-block confirmation as explicit session readiness
when SDK interlock feedback is unknown. Preserve raw unknown feedback, known
negative/key/identity/communication checks and actual physical interlock. Enable
production GUI Open through this documented confirmation, not a forced disabled
callback. No firmware change or physical fault injection inferred. Stage7 removed.


### Stage 5/6 implementation and hardware launch (2026-10-20)

User: "implement the stage 5, 6 with the hardware. no human involvement."
Implement and autonomously exercise shutdown/reconnect and GUI/normal terminal
Ctrl+C using actual USB68800777. Retain confirmed source block, physical interlock
and2s added hold, production guards and stop/cleanup on failure. No extra human
prompt/observation is required for available automated checks; absent new physical
observation remains unverified rather than fabricated. Do not bypass GUI/driver
Open inhibition or claim direct SDK evidence qualifies production acceptance.

### Five-cycle SDK bench sequence (2026-10-20)

After reviewing E074 Close and confirming physical interlock enabled, user
requests Stage3/4 control and replaces earlier10s pair with Open2s/Close2s,
five cycles. Authorize that exact direct official SDK sequence under prior
source-block conditions, fresh identity/key/status checks and guarded closure.
This does not authorize changing production safeguards or hardware interlock.
User subsequently confirms the shutter followed the sequence. Record hardware
functional result separately from production-controller/GUI acceptance and
calibrated timing. No further stages or automatic repeat inferred.

### Test independent SDK commands and Close (2026-10-20)

User clarifies Auto is a valid mode and asks to test other commands, then
confirms physical interlock enabled. Record physical confirmation as human
evidence separately from unverified SDK bit. Test independent official SDK
reads and existing authorized Close/Inactive/verified Manual sequence without
calling Enable/Open or changing production guards. No device fault inferred
from mode Auto or undefined initial operating0.

### Reset current test results and rerun (2026-10-20)

User: "reset the test status. perform the hardware runs in stage 3 and 4".
Reset current Stage3/4 attempt statuses and run fresh prerequisites; preserve
historical evidence, accepted Stage7 removal and device/output safeguards.
No factory/device reset, status fabrication or guard bypass inferred. Earlier
interrupted Stage5/6 request is not launched by this resumed Stage3/4 task.

### Remove dedicated repeatability stage (2026-10-20)

User: "remove stage 7. unnecessary. we tested a lot." Remove the dedicated
twenty-cycle-per-pair Stage 7 and its acceptance threshold. Retain existing
evidence and all other functional, shutdown, GUI, fault and multi-pair criteria.
Stage 7 is removed by scope change, not recorded as a demonstrated PASS.

### Reviewed-source stage hardware request (2026-10-20)

User requests "perform the hardware runs in stage 3 and 4". Attempt Stage 3
on current reviewed source with status-first and prerequisite checks; preserve
one-stage/review sequencing and existing Open safeguard/10s hold limits. No
guard override, inferred operating0 mapping or automatic Stage-4 progression.

### Holistic command/manual review (2026-10-20)

User: "holistic review of the command. read the manual. revise any wrong
interpretation". Authorize official-source review and focused corrections to
status/command interpretation, documentation and software tests. No new hardware
actuation, firmware or physical configuration work as part of the review.

### One Open/Close sequence request (2026-10-20)

User requests "control the shutter. open, close, sequence" and specifies 10 s
added Open hold after feedback. Prepare one Open/Close pair under existing
independent source block/observation, current identity and safeguard checks.
No repeated loop, interlock bypass, firmware or wiring change authority inferred.

### Stage 3 hardware execution (2026-10-20)

User: "do hardware run", following explicit Stage-3 status-then-motion sequence.
Launch one USB Stage-3 Close/Inactive, Manual and guarded Close/release cycle;
no Enable/Open, automatic retry or Stage-4 advancement. Preserve prior independent
source-block/observation conditions; request physical observation for review.

### USB health correction (2026-10-20)

User: "quick resolve the USB health discrepancy". Authorize focused driver
correction, software regression and passive actual USB validation. No output,
configuration, firmware update or implicit stage advancement.

### Hardware launch request (2026-10-20)

User: "test with hardware", followed by "read from status. do the hardware
tests". Authorizes actual test work; preserve prior one-stage/review sequencing
and prerequisite/failure gates. Read available electronic state rather than
requesting the same reported fields from the human. Electronic status does not
establish independent blade position, wiring, supply or physical recovery.

### Stage 3 and 4 implementation (2026-10-20)

User: "stage 2 passed. implement stage 3 and 4". Record Stage 2 as human-reported
PASS, preserving the conflicting TEST-061 production USB failure and missing
new physical evidence. Implement first-Close and one Open/Close acceptance
helpers with software validation. No live launch inferred from implementation;
preserve separate human review after each stage and current actuation hold.

### KSC101 firmware update execution (2026-10-20)

User: "update the KCS101 firmware to the newest" (KSC101 in this bench).
Supersedes the firmware hold for this cube only. User confirms independent
source block, stable power/USB, acceptable reset/output consequences and printed
serial 68800777. Use official vendor utility/latest compatible KSC101 payload;
retain hub firmware and production source. Deliberate shutter actuation stays
held. Verify USB identity/firmware/status passively afterward; no blind recovery.

Human-authored project definition.

### Holistic package review and development plan (2026-10-20)

User: "holistic review. development plan for comprehensive shutter controller package".
Review the existing package and prepare a prioritized, evidence-based development
plan covering controller/GUI behavior, hardware interfaces, testing, operation
and release readiness. This request authorizes review and planning, not feature
implementation, hardware access or publication. Preserve the separately gated
stage-by-stage test work and its review/launch boundaries. The proposed roadmap
is in [docs/DEVELOPMENT_PLAN.md](docs/DEVELOPMENT_PLAN.md); proposals are not new
demonstrated capabilities or waived physical acceptance criteria.

## Engineering objective

Develop a reliable Python control program for a Thorlabs KSC101 K-Cube Solenoid
Controller and connected optical shutter. Provide a simple reusable controller
class, reliable open/close control, connection and status handling, and a
lightweight Plotly Dash GUI for manual control. Keep the structure clean for
later integration into larger laboratory-control software.

## Requirements / acceptance criteria

### Controller

- Support connect, disconnect, device identification, shutter open/close,
  state/status queries where available, safe shutdown, and clear communication
  error handling.
- Refine the exact internal API after studying the KSC101 interface.

### GUI

- Show connection status, device identity / serial number, shutter state where
  available, Open and Close buttons, and status/error messages.
- Keep the GUI simple and functional; all hardware control goes through the
  controller class, with no Thorlabs-specific control logic in the GUI.

### Validation

- Ultimately validate on physical hardware: discovery/connection, open, close,
  repeated open/close operation, disconnect/reconnect, error handling, defined
  shutdown behavior, and GUI operation through the controller class.
- Successful software calls alone do not prove physical shutter operation.

## Constraints

- Use Python, `uv` for environment and dependency management, `pyproject.toml`,
  and `uv.lock`.
- Use Plotly Dash for the GUI and keep the hardware interface behind a simple
  controller class.
- Prefer official Thorlabs-supported APIs/libraries where practical. Keep the
  implementation minimal and avoid unnecessary abstractions.
- When implementation begins, research official Thorlabs documentation and
  supported software interfaces autonomously; make routine reversible
  engineering decisions autonomously.
- Do not invent missing hardware details or bypass hardware interlocks or safety
  mechanisms.
- Do not modify firmware without explicit approval.

## Available system

On 2026-10-20 the user reports the current chain as computer -> USB -> KEH3 ->
KSC101 -> SH05R and requests a refined hardware testing plan. This establishes
the reported model/transport topology, not inspected device state or authorization
to operate it. Installed cube count, serials, supply, firmware/SDK and operating
conditions still require confirmation. Start acceptance with one actual pair
through KEH3 USB, then extend to three installed pairs and separately approved TTL.

- Known, as supplied: Thorlabs KSC101, compatible Thorlabs optical shutter, and
  USB-connected control computer.
- Unknown until discovered or supplied: device serial number, power
  configuration, installed Kinesis version, and current device /
  shutter state. Hardware has not been inspected or validated.

## Current scope

Autonomous implementation was followed by a user-requested hardware-readiness
audit on 2026-09-09. Finish software review and preparation, then stop at
AWAITING_HUMAN_REVIEW. Do not communicate with or actuate the physical KSC101
until the user approves the staged hardware-validation launch. Requirements and
the engineering constraints above remain unchanged.

### Documentation follow-up

The user's subsequent documentation-only request in [prompt log.txt](prompt%20log.txt)
authorizes a polished README, supporting user guides, actual simulated GUI
screenshots, editable architecture/workflow diagrams, verified examples and
troubleshooting. Base every claim on implementation and recorded evidence. Keep
simulation prominent and physical validation pending. No hardware development,
device access, physical validation, architectural redesign or unrelated features
are in scope. Documentation examples and a source-checkout screenshot/demo harness
may reuse the existing test fixture; production behavior remains unchanged.
The earlier hardware-review hold remains in force after this documentation pass.

On 2026-09-15, the user requested a simple first-time-user README, then asked for
more focus on real-hardware use. For the README, prioritize installation, bench
setup, discovery, connection, operation and shutdown; keep simulation as an
optional workflow and label its evidence clearly. This changes documentation
emphasis only; the hardware-review hold and physical criteria remain unchanged.

### Code simplification follow-up

The user's subsequent cleanup request authorizes incremental code and documentation
simplification: remove redundant structure and configuration while preserving
required behavior, used public APIs, hardware boundaries, safety/error handling,
meaningful tests, packaging and reproducibility. Validate reductions with affected
tests, then the full software suite, lint/format and package checks. Report the
resulting architecture, removals, size changes and intentionally retained complexity.
This supersedes the documentation-only restriction on local implementation changes;
the hardware-review hold and physical acceptance criteria remain in force.

### Three-shutter KEH3 USB follow-up (2026-10-20)

The user requests: "Implement support for three KSC101 shutters through KEH3 USB
in one GUI, with independent controls and safe shutdown for all connected shutters.
Keep hardware access on hold."

- Provide three independent serial selections, connection/status/error displays,
  Open, Close, and Close & disconnect controls in one local GUI.
- Use one controller object per shutter, prevent competing ownership of the same
  serial within this process, and preserve per-device safeguards and fault handling.
- Provide Close & disconnect all and server-exit cleanup that attempt every slot
  even if another slot fails, with identified errors. Cleanup is sequential and
  best effort; it does not guarantee physical closure or bound hung vendor calls.
- Keep startup passive and preserve single-controller Python usage. Allow up to
  three distinct CLI serial preselection arguments without automatic connection.
- Validate using three distinct software devices, independent state/faults,
  duplicate protection and failure/interrupt cleanup. Document reproducible use.
- Intended hardware transport is KEH3 USB to individual KSC101 serial identities;
  Ethernet and synchronized actuation are outside this change. Physical hub/SDK
  enumeration, channel mapping, feedback and closure still require bench acceptance.

This authorizes local implementation and software-only validation. It does not
authorize SDK/device discovery, connection, actuation or firmware writes. The
hardware-review hold remains in force.

### Controller rename and simplification follow-up (2026-10-20)

The user requests: "rename KSC101Controller to KCubeShutter. combine the bank.py
into the controller.py. prune and simplify".

Rename the public class and current imports/examples to `KCubeShutter`, without
a legacy alias. Place `ShutterBank` alongside the driver in `controller.py` and
remove `bank.py`. Prune redundant code while retaining the three independent
GUI slots, atomic serial ownership, per-device safeguards/faults, complete
best-effort cleanup and passive startup. Validate affected behavior with
software-only regressions, packaging and current documentation. The intentional
public class rename supersedes earlier preservation of that class name;
hardware access remains on hold.

### ShutterHub construction and controller review (2026-10-20)

The user requests: "CHANGE ShutterBank to ShutterHub. simplify the construction.
review controller.py. remove any unnecessary scaffolding".

Rename the hub class and current exports/callers/documentation to `ShutterHub`
without an old-name alias. Construct the three slots directly from an optional
serial list, centralizing preselection/padding and validation. Keep explicit
controller injection for integrations and software tests. Remove unused support
code and redundant validation while preserving passive startup, independent
controls, atomic ownership, safeguards, latched faults and all-shutter cleanup.
Validate source, packaging, examples and GUI behavior using software only.
The hardware hold remains unchanged.

### GUI construction cleanup (2026-10-20)

The user requests: "review gui.py and simplify the GUI construction. remove
unnecessary scaffolding while preserving the three independent shutter controls.
keep hardware access on hold."

Simplify panel construction, component binding and callback setup while retaining
three independent serial selections/controls/status/errors, shared discovery and
all-shutter shutdown. Preserve passive startup, supported injected views, fault
and safeguard gating, retained identity, message persistence and serialized
controller access. Use software-only regression, layout and packaging checks;
the hardware hold remains in force.


### Ethernet SDK assessment request (2026-10-20)

User: "Check whether the official Kinesis or XA SDK supports controlling three
KSC101s through KEH3 Ethernet, and what code changes would be needed. Keep hardware
access on hold." Scope is research and a source-based change assessment; this
does not authorize implementation, SDK/device discovery or hardware operations.
The delivered production transport remains USB.

### TRIG1/TRIG2 TTL support (2026-10-20)

User: "Add TRIG1/TRIG2 TTL configuration, readback, and arm/disarm support to
KCubeShutter and the GUI. Keep it simple, preserve safe shutdown for all three
shutters, and keep hardware access on hold."

- Expose each port's Disabled/Input/Output mode and High/Low active polarity,
  validated against the KSC101-specific official Kinesis API.
- Separate settings drafts, explicit Apply, actual vendor readback and explicit
  Arm/Disarm. Connect and refresh must not configure or arm. Report priming
  separately from shutter position; no pin-voltage measurement is implied.
- Apply only when reported Closed/Inactive/Manual. Arm requires healthy feedback,
  enabled key/interlock and an input port; use device settings, not GUI drafts.
  Active input or active-low with a disconnected LOW input may open immediately.
- Close/Disarm/default disconnect/server exit must request Inactive, confirm
  Closed/Inactive before selecting Manual, and preserve cleanup of every slot
  after errors or interruptions. Do not restore
  Triggered mode. Do not issue persistent-settings or firmware commands.
- Validate independent settings/control, refusals, readback/failure/interrupt
  paths, GUI and packaging using software only. Prepare physical TTL acceptance
  separately. No SDK loading, device access, electrical testing or actuation is
  authorized; the hardware hold remains in force.

### Consistency review and publication (2026-10-20)

User: "review check consistency. prune and fix. commit and push".
Review and simplify the accumulated three-shutter/TTL changes, fix supported
defects, align documentation and validation evidence, then commit and push to the
configured remote. Use software-only validation and preserve the hardware hold.

### Beginner hardware tutorials (2026-10-20)

User: "rewrite the scripts in example folder. the 4 to 5 example scripts,
tutorial like. easy to follow. for hardware only. explain to beginners."
Replace the example-folder simulation with five short, numbered hardware
tutorials and a beginner guide. Cover discovery, passive connection/status,
manual Open/Close, three-shutter hub use and TTL configuration/arming/disarming.
Explain configuration, commands, feedback and cleanup; require actual serials
and operator-approved dwell times. Keep the simulator as an internal testing
utility outside examples and update existing documentation links. Validate only
with imports/help, software devices and static checks; hardware access stays on hold.
This request does not authorize new device operations or automatic publication.

### Final hardware-plan review (2026-10-20)

User: "final review and revise of the hardware test plan before implementation".
Review the prepared procedure against the current controller/GUI/CLI and
authoritative hardware information; correct actionable sequencing, cleanup,
failure-handling and acceptance-evidence gaps. Deliver one reviewed procedure
for the reported computer -> USB -> KEH3 -> KSC101 -> SH05R chain, starting
with one pair and retaining full three-pair and TTL acceptance as separate gates.
This authorizes plan/documentation revision and software-only verification;
it does not authorize device operations or lift the hardware-review hold.

### Stage-by-stage hardware-test implementation (2026-10-20)

User: "implement the reviewed hardware test plan stage by stage. each stage wait
for human review. keep hardware access on hold".
Implement preparation/test tooling for one numbered stage at a time, beginning
with Stage 0, validate with software only, and stop for explicit human review
before implementing the next stage. Keep actual SDK loading, discovery,
connection, actuation and electrical tests on hold. Approval to implement another
stage is not hardware launch authority. Unknown bench facts must remain unknown;
local preparation and structural checks cannot pass physical requirements.

### Stage-0 approval and Stage-1 implementation (2026-10-20)

User: "Stage 0 approved. Implement Stage 1, keep hardware access on hold, and
stop for human review."
Stage-0 implementation review is approved; its missing physical facts remain
unknown. Implement Stage-1 offline software/environment preflight and serial-list
validation using software devices. Keep live discovery blocked, leave the existing
controller interface intact, and stop for Stage-1 human review before Stage 2.
No real SDK loading, discovery, connection or actuation is authorized.

### Actual discovery request (2026-10-20)

User: "discover the actual device. determine the COM".
This subsequently authorizes actual USB enumeration and read-only Windows
device/COM inventory to identify the attached controller(s). It supersedes the
hold only for that discovery scope, including necessary SDK loading. It does
not authorize Connect, polling, shutter/TTL configuration, actuation or firmware
writes. Stage-1 implementation still requires human review before Stage 2.

### Stage-1 closeout, Stage-2 implementation and SDK repair (2026-10-20)

User: "finish up stage 1. implement stage 2", then "resolve the SDK issues".
Proceed from Stage-1 software review to Stage-2 implementation and validate with
software devices; stop for review before Stage 3. Physical Stage-1 completion
still requires actual SDK enumeration. Resolve the missing SDK/USB-driver setup
using the authentic official matching x64 Kinesis package, verify installation
and actual discovery, and preserve the existing discovery-only device scope.
This authorizes necessary SDK/driver installation and diagnosis, not controller
Connect/polling, shutter/TTL commands, firmware changes or an automatic reboot.

### Actual passive USB and Ethernet testing (2026-10-20)

User: "finish up the stage 2 with USB connection. then test with the ethernet
communication. the device is connected to the LAN". After the request for bench
safety/ownership/observation confirmation, the user replied "safe to test with
the hardware". This authorizes actual passive connection, settings initialization,
polling, identity/status reads and communication-only release, USB first then
Ethernet, plus necessary local transport setup. No shutter/TTL output, Enable,
mode change, persistent hub/network configuration or firmware write is authorized.
Record unprovided physical facts as unknown and distinguish returned device
feedback from independent physical observation. Use one owner/transport at a time;
USB/LAN cable transitions require the operator, not power/docking changes.

### Minimal controller hardware-handling revision (2026-10-20)

User: "examine the controller code. minimal modification. improve the hardware
handling. revise". Authorizes focused controller changes and software-only
regression validation, preserving identity/interlock guards and staged physical
acceptance. No hardware operation is requested for this revision. Scope: prevent
owned-handle serial relabeling, request operating feedback explicitly, normalize
documented mode names and reject unknown operating feedback. Actual serial
disagreement and cube Ethernet failure remain unresolved physical findings.

### Actual-hardware test-plan revision (2026-10-20)

User: "revise the hardware test plan to test with the actual hardware".
Revise the procedure around E040–E043 and the installed one-pair bench, including
current-revision passive revalidation, identity/status failure diagnosis,
separate Ethernet qualification and gated first Close/Open tests. Preserve the
one-stage/human-review sequence and existing authority boundaries. This request
is plan revision, not a new hardware command or motion launch authorization.

### Resolve passive KSC101 Ethernet communication (2026-10-20)

User: "resolve the KSC101 ethernet communication through KEH3. make minimal code
changes and test passive communication. keep shutter actuation on hold".
Authorize focused Ethernet transport changes, software regression checks and
actual passive discovery/identity/status/release. Preserve serial verification,
exclusive ownership and operating-feedback guards. No shutter output, Enable,
mode/TTL, firmware, persistent hub/IP, power or docking changes are authorized.
User subsequently closed Kinesis and confirmed the installed cube is in the left
bay. Existing source-block/safe-observation conditions continue; no independent
blade observation is implied by this passive communication scope.

### Official firmware compatibility investigation and Kinesis handoff

User requested official documentation checks for KSC101 1.0.6 / KEH3 1.1.2,
assessment of the Ethernet discovery failure, and Kinesis discovery/passive
connection, explicitly excluding firmware update and actuation. The user then
stopped automated computer use, took over Kinesis and reported "only hub".
Preserve manual UI ownership; the cube was not available to connect. Investigation
findings belong in E047; no update or output authority is granted.

### Prepare KSC101 firmware update for review (2026-10-20)

User: "prepare the KSC101 1.0.7 firmware update procedure for review, including
passive USB and Ethernet checks afterward. do not update firmware yet. keep
shutter actuation on hold." Prepare the exact-target review procedure, official
package/integrity references, identification/recovery gates and post-update
passive checks. Do not install/run an updater, update any firmware, change power/
wiring or perform hardware verification as part of preparation. Implementation
and launch authority remain separate from review; no rollback is presumed.

### Resume actual USB hardware tests (2026-10-20)

User reports "now the hub is connect with USB only" and requests continuation
with USB communication. Resume actual passive USB discovery, selected-identity/
status reads and communication-only release after exclusive ownership is
established. This does not approve firmware installation/update or shutter
actuation. Stop on mismatch/fault and preserve review after the current stage.
